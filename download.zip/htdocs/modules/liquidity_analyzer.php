<?php
/**
 * 💧 Liquidity Analyzer Module
 * 
 * Tracks Bitcoin and Altcoins liquidity to understand money flow in crypto market
 * 
 * Features:
 * - Bitcoin Dominance tracking
 * - Total market cap analysis
 * - Volume analysis (24h)
 * - Money flow detection (BTC ↔ Altcoins)
 * - Liquidity health assessment
 */

require_once __DIR__ . '/../config/database.php';

class LiquidityAnalyzer {
    
    private $cacheTime = 300; // 5 minutes cache
    
    /**
     * Get comprehensive liquidity analysis
     */
    public function getComprehensiveLiquidity() {
        // Try cache first
        $cached = $this->getCachedData();
        if ($cached) {
            return $cached;
        }
        
        // Fetch fresh data
        $data = $this->fetchMarketData();
        
        if (!$data) {
            return $this->getDefaultData();
        }
        
        // Calculate liquidity metrics
        $analysis = [
            'bitcoin' => $this->analyzeBitcoinLiquidity($data),
            'altcoins' => $this->analyzeAltcoinsLiquidity($data),
            'market_overview' => $this->analyzeMarketOverview($data),
            'money_flow' => $this->analyzeMoneyFlow($data),
            'recommendations' => $this->generateRecommendations($data),
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // Cache the results
        $this->cacheData($analysis);
        
        return $analysis;
    }
    
    /**
     * Fetch market data from CoinGecko API
     */
    private function fetchMarketData() {
        try {
            // Get global market data
            $globalUrl = 'https://api.coingecko.com/api/v3/global';
            $globalData = $this->fetchAPI($globalUrl);
            
            // Get Bitcoin specific data
            $btcUrl = 'https://api.coingecko.com/api/v3/coins/bitcoin?localization=false&tickers=false&community_data=false&developer_data=false';
            $btcData = $this->fetchAPI($btcUrl);
            
            // Get top altcoins for volume analysis
            $altcoinsUrl = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false';
            $altcoinsData = $this->fetchAPI($altcoinsUrl);
            
            if (!$globalData || !$btcData || !$altcoinsData) {
                return null;
            }
            
            return [
                'global' => $globalData['data'] ?? $globalData,
                'bitcoin' => $btcData,
                'altcoins' => $altcoinsData
            ];
            
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Analyze Bitcoin liquidity
     */
    private function analyzeBitcoinLiquidity($data) {
        $btc = $data['bitcoin'];
        $global = $data['global'];
        
        $marketCap = $btc['market_data']['market_cap']['usd'] ?? 0;
        $volume24h = $btc['market_data']['total_volume']['usd'] ?? 0;
        $dominance = $global['market_cap_percentage']['btc'] ?? 0;
        
        // Calculate liquidity ratio (volume / market cap)
        $liquidityRatio = $marketCap > 0 ? ($volume24h / $marketCap) * 100 : 0;
        
        // Determine liquidity level
        $liquidityLevel = 'low';
        if ($liquidityRatio > 5) $liquidityLevel = 'high';
        elseif ($liquidityRatio > 2) $liquidityLevel = 'medium';
        
        // Signal based on dominance trend
        $signal = 'neutral';
        if ($dominance > 50) $signal = 'btc_dominance';
        elseif ($dominance < 40) $signal = 'altseason';
        
        return [
            'market_cap' => $marketCap,
            'volume_24h' => $volume24h,
            'dominance' => round($dominance, 2),
            'liquidity_ratio' => round($liquidityRatio, 3),
            'liquidity_level' => $liquidityLevel,
            'signal' => $signal,
            'circulation_supply' => $btc['market_data']['circulating_supply'] ?? 0
        ];
    }
    
    /**
     * Analyze Altcoins liquidity
     */
    private function analyzeAltcoinsLiquidity($data) {
        $global = $data['global'];
        $altcoinsData = $data['altcoins'];
        
        $totalMarketCap = $global['total_market_cap']['usd'] ?? 0;
        $btcMarketCap = $data['bitcoin']['market_data']['market_cap']['usd'] ?? 0;
        $altcoinsMarketCap = $totalMarketCap - $btcMarketCap;
        
        // Calculate total altcoins volume
        $altcoinsVolume = 0;
        foreach ($altcoinsData as $coin) {
            if ($coin['id'] !== 'bitcoin') {
                $altcoinsVolume += $coin['total_volume'] ?? 0;
            }
        }
        
        // Calculate liquidity ratio
        $liquidityRatio = $altcoinsMarketCap > 0 ? ($altcoinsVolume / $altcoinsMarketCap) * 100 : 0;
        
        // Determine liquidity level
        $liquidityLevel = 'low';
        if ($liquidityRatio > 8) $liquidityLevel = 'high';
        elseif ($liquidityRatio > 4) $liquidityLevel = 'medium';
        
        // Count active altcoins
        $activeAltcoins = count($altcoinsData) - 1; // Exclude BTC
        
        return [
            'market_cap' => $altcoinsMarketCap,
            'volume_24h' => $altcoinsVolume,
            'liquidity_ratio' => round($liquidityRatio, 3),
            'liquidity_level' => $liquidityLevel,
            'active_coins' => $activeAltcoins,
            'dominance' => round(($altcoinsMarketCap / $totalMarketCap) * 100, 2)
        ];
    }
    
    /**
     * Analyze market overview
     */
    private function analyzeMarketOverview($data) {
        $global = $data['global'];
        
        $totalMarketCap = $global['total_market_cap']['usd'] ?? 0;
        $totalVolume = $global['total_volume']['usd'] ?? 0;
        $marketCapChange24h = $global['market_cap_change_percentage_24h_usd'] ?? 0;
        
        // Calculate overall liquidity
        $overallLiquidity = $totalMarketCap > 0 ? ($totalVolume / $totalMarketCap) * 100 : 0;
        
        // Market health based on multiple factors
        $health = 'normal';
        if ($overallLiquidity > 6 && $marketCapChange24h > 0) $health = 'excellent';
        elseif ($overallLiquidity < 3 && $marketCapChange24h < -2) $health = 'poor';
        
        return [
            'total_market_cap' => $totalMarketCap,
            'total_volume_24h' => $totalVolume,
            'market_cap_change_24h' => round($marketCapChange24h, 2),
            'overall_liquidity' => round($overallLiquidity, 3),
            'active_cryptocurrencies' => $global['active_cryptocurrencies'] ?? 0,
            'markets' => $global['markets'] ?? 0,
            'market_health' => $health
        ];
    }
    
    /**
     * Analyze money flow between BTC and Altcoins
     */
    private function analyzeMoneyFlow($data) {
        $btc = $data['bitcoin'];
        $global = $data['global'];
        
        $btcDominance = $global['market_cap_percentage']['btc'] ?? 50;
        $btcPriceChange24h = $btc['market_data']['price_change_percentage_24h'] ?? 0;
        $marketCapChange24h = $global['market_cap_change_percentage_24h_usd'] ?? 0;
        
        // Detect money flow direction
        $flow = 'neutral';
        $flowStrength = 'weak';
        
        if ($btcPriceChange24h > 2 && $marketCapChange24h > 0) {
            $flow = 'into_btc';
            $flowStrength = abs($btcPriceChange24h) > 5 ? 'strong' : 'medium';
        } elseif ($btcPriceChange24h < -2 && $marketCapChange24h > 0) {
            $flow = 'into_altcoins';
            $flowStrength = abs($btcPriceChange24h) > 5 ? 'strong' : 'medium';
        } elseif ($marketCapChange24h < -2) {
            $flow = 'outflow';
            $flowStrength = abs($marketCapChange24h) > 5 ? 'strong' : 'medium';
        }
        
        // Calculate flow index (-100 to +100)
        // Positive = Money flowing into BTC
        // Negative = Money flowing into Altcoins
        $flowIndex = ($btcDominance - 45) * 2; // Normalize around 45% dominance
        
        return [
            'direction' => $flow,
            'strength' => $flowStrength,
            'flow_index' => round($flowIndex, 1),
            'btc_dominance' => round($btcDominance, 2),
            'btc_price_change_24h' => round($btcPriceChange24h, 2),
            'market_change_24h' => round($marketCapChange24h, 2)
        ];
    }
    
    /**
     * Generate recommendations based on liquidity analysis
     */
    private function generateRecommendations($data) {
        $recommendations = [];
        $isRTL = isset($_COOKIE['lang']) && $_COOKIE['lang'] === 'ar';
        
        $btcLiq = $this->analyzeBitcoinLiquidity($data);
        $altLiq = $this->analyzeAltcoinsLiquidity($data);
        $flow = $this->analyzeMoneyFlow($data);
        
        // Bitcoin Dominance Recommendation
        if ($btcLiq['dominance'] > 55) {
            $recommendations[] = [
                'type' => 'btc_dominance',
                'priority' => 'high',
                'message_en' => '🔶 Bitcoin dominance is high (' . $btcLiq['dominance'] . '%). Focus on BTC trading.',
                'message_ar' => '🔶 هيمنة البتكوين عالية (' . $btcLiq['dominance'] . '%). ركز على تداول BTC.'
            ];
        } elseif ($btcLiq['dominance'] < 40) {
            $recommendations[] = [
                'type' => 'altseason',
                'priority' => 'high',
                'message_en' => '🎯 Alt season signal! Bitcoin dominance is low (' . $btcLiq['dominance'] . '%). Consider altcoins.',
                'message_ar' => '🎯 إشارة موسم العملات البديلة! هيمنة البتكوين منخفضة (' . $btcLiq['dominance'] . '%). فكر في العملات البديلة.'
            ];
        }
        
        // Money Flow Recommendation
        if ($flow['direction'] === 'into_btc' && $flow['strength'] !== 'weak') {
            $recommendations[] = [
                'type' => 'money_flow',
                'priority' => 'medium',
                'message_en' => '💰 Money is flowing into Bitcoin. BTC may outperform altcoins.',
                'message_ar' => '💰 الأموال تتدفق إلى البتكوين. BTC قد يتفوق على العملات البديلة.'
            ];
        } elseif ($flow['direction'] === 'into_altcoins' && $flow['strength'] !== 'weak') {
            $recommendations[] = [
                'type' => 'money_flow',
                'priority' => 'medium',
                'message_en' => '💸 Money is flowing into altcoins. Watch for altcoin opportunities.',
                'message_ar' => '💸 الأموال تتدفق إلى العملات البديلة. راقب فرص العملات البديلة.'
            ];
        } elseif ($flow['direction'] === 'outflow') {
            $recommendations[] = [
                'type' => 'warning',
                'priority' => 'high',
                'message_en' => '⚠️ Money is leaving the market. Exercise caution.',
                'message_ar' => '⚠️ الأموال تغادر السوق. توخى الحذر.'
            ];
        }
        
        // Liquidity Health Recommendation
        if ($btcLiq['liquidity_level'] === 'low' && $altLiq['liquidity_level'] === 'low') {
            $recommendations[] = [
                'type' => 'liquidity',
                'priority' => 'high',
                'message_en' => '🚨 Low liquidity across the market. Be cautious with large trades.',
                'message_ar' => '🚨 سيولة منخفضة في السوق. كن حذراً مع الصفقات الكبيرة.'
            ];
        } elseif ($btcLiq['liquidity_level'] === 'high' || $altLiq['liquidity_level'] === 'high') {
            $recommendations[] = [
                'type' => 'liquidity',
                'priority' => 'low',
                'message_en' => '✅ Good liquidity levels. Market is active and healthy.',
                'message_ar' => '✅ مستويات سيولة جيدة. السوق نشط وصحي.'
            ];
        }
        
        return $recommendations;
    }
    
    /**
     * Fetch data from API
     */
    private function fetchAPI($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && $response) {
            return json_decode($response, true);
        }
        
        return null;
    }
    
    /**
     * Cache data in database
     */
    private function cacheData($data) {
        try {
            $sql = "INSERT INTO liquidity_cache (cache_key, cache_data, created_at)
                    VALUES ('liquidity_analysis', ?, NOW())
                    ON DUPLICATE KEY UPDATE cache_data = VALUES(cache_data), created_at = NOW()";
            
            executeQuery($sql, [json_encode($data)]);
        } catch (Exception $e) {
            // Cache table might not exist - ignore
        }
    }
    
    /**
     * Get cached data
     */
    private function getCachedData() {
        try {
            $sql = "SELECT cache_data, created_at FROM liquidity_cache 
                    WHERE cache_key = 'liquidity_analysis' 
                    AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)";
            
            $result = fetchOne($sql, [$this->cacheTime]);
            
            if ($result) {
                return json_decode($result['cache_data'], true);
            }
        } catch (Exception $e) {
            // Cache table might not exist
        }
        
        return null;
    }
    
    /**
     * Get default data when API fails
     */
    private function getDefaultData() {
        return [
            'bitcoin' => [
                'market_cap' => 0,
                'volume_24h' => 0,
                'dominance' => 50,
                'liquidity_ratio' => 0,
                'liquidity_level' => 'unknown',
                'signal' => 'neutral',
                'circulation_supply' => 0
            ],
            'altcoins' => [
                'market_cap' => 0,
                'volume_24h' => 0,
                'liquidity_ratio' => 0,
                'liquidity_level' => 'unknown',
                'active_coins' => 0,
                'dominance' => 50
            ],
            'market_overview' => [
                'total_market_cap' => 0,
                'total_volume_24h' => 0,
                'market_cap_change_24h' => 0,
                'overall_liquidity' => 0,
                'active_cryptocurrencies' => 0,
                'markets' => 0,
                'market_health' => 'unknown'
            ],
            'money_flow' => [
                'direction' => 'neutral',
                'strength' => 'weak',
                'flow_index' => 0,
                'btc_dominance' => 50,
                'btc_price_change_24h' => 0,
                'market_change_24h' => 0
            ],
            'recommendations' => [],
            'timestamp' => date('Y-m-d H:i:s'),
            'error' => 'Unable to fetch liquidity data'
        ];
    }
}
?>

