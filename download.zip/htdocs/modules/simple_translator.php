<?php
/**
 * Simple Unified Translation System
 * نظام ترجمة موحد وبسيط
 * 
 * All-in-one translation solution with caching
 */

require_once __DIR__ . '/../config/database.php';

class SimpleTranslator {
    
    private static $cache = [];
    
    /**
     * Translate text (with automatic caching)
     */
    public static function translate($text, $from = 'en', $to = 'ar') {
        if (empty($text)) return $text;
        
        $text = trim($text);
        $cacheKey = md5($text . $from . $to);
        
        // Check memory cache first
        if (isset(self::$cache[$cacheKey])) {
            return self::$cache[$cacheKey];
        }
        
        // Check database cache
        $cached = self::getFromCache($cacheKey);
        if ($cached) {
            self::$cache[$cacheKey] = $cached;
            return $cached;
        }
        
        // Translate via API
        $translated = self::translateViaAPI($text, $from, $to);
        
        if ($translated) {
            // Save to cache
            self::saveToCache($text, $translated, $cacheKey, $from, $to);
            self::$cache[$cacheKey] = $translated;
            return $translated;
        }
        
        return $text;
    }
    
    /**
     * Translate via multiple APIs (with fallback system)
     */
    private static function translateViaAPI($text, $from, $to) {
        if (strlen($text) > 500) {
            $text = substr($text, 0, 500);
        }
        
        // Always do basic translation first (instant and reliable)
        $basicTranslated = self::basicTranslation($text, $from, $to);
        
        // Try API 1: MyMemory
        $result = self::tryMyMemory($text, $from, $to);
        if ($result && !self::isErrorMessage($result)) return $result;
        
        // Try API 2: LibreTranslate (fallback)
        $result = self::tryLibreTranslate($text, $from, $to);
        if ($result && !self::isErrorMessage($result)) return $result;
        
        // Return at least basic translation
        return $basicTranslated;
    }
    
    /**
     * Check if translation result is an error message
     */
    private static function isErrorMessage($text) {
        $errorIndicators = ['WARNING', 'LIMIT', 'ERROR', 'MYMEMORY'];
        foreach ($errorIndicators as $indicator) {
            if (stripos($text, $indicator) !== false) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Try MyMemory API
     */
    private static function tryMyMemory($text, $from, $to) {
        try {
            $url = "https://api.mymemory.translated.net/get?q=" . urlencode($text) . "&langpair={$from}|{$to}";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            curl_close($ch);
            
            if ($response) {
                $data = json_decode($response, true);
                if (isset($data['responseData']['translatedText'])) {
                    return $data['responseData']['translatedText'];
                }
            }
            
            return null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Try LibreTranslate (public instance)
     */
    private static function tryLibreTranslate($text, $from, $to) {
        try {
            $url = "https://translate.argosopentech.com/translate";
            
            $postData = json_encode([
                'q' => $text,
                'source' => $from,
                'target' => $to,
                'format' => 'text'
            ]);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($postData)
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($response && $httpCode == 200) {
                $data = json_decode($response, true);
                if (isset($data['translatedText'])) {
                    return $data['translatedText'];
                }
            }
            
            return null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Basic translation (fallback - common crypto terms)
     * Enhanced with more terms
     */
    private static function basicTranslation($text, $from, $to) {
        if ($to !== 'ar') return $text;
        
        $terms = [
            // Cryptocurrencies
            'Bitcoin' => 'بيتكوين', 'BTC' => 'بيتكوين',
            'Ethereum' => 'إيثيريوم', 'ETH' => 'إيثيريوم',
            'Binance' => 'بينانس', 'BNB' => 'بينانس',
            'Solana' => 'سولانا', 'SOL' => 'سولانا',
            'Cardano' => 'كاردانو', 'ADA' => 'كاردانو',
            'XRP' => 'ريبل', 'Ripple' => 'ريبل',
            'Dogecoin' => 'دوجكوين', 'DOGE' => 'دوجكوين',
            
            // Market terms
            'price' => 'سعر', 'market' => 'سوق', 'trading' => 'تداول',
            'crypto' => 'عملات رقمية', 'cryptocurrency' => 'عملة رقمية',
            'token' => 'رمز', 'coin' => 'عملة', 'blockchain' => 'بلوكتشين',
            
            // Actions
            'surges' => 'يرتفع', 'surge' => 'ارتفاع', 'soars' => 'يحلق',
            'drops' => 'ينخفض', 'drop' => 'انخفاض', 'falls' => 'يهبط',
            'reaches' => 'يصل إلى', 'hits' => 'يصل', 'climbs' => 'يتسلق',
            'declines' => 'ينخفض', 'decline' => 'انخفاض',
            'rises' => 'يرتفع', 'rise' => 'ارتفاع',
            'jumps' => 'يقفز', 'spikes' => 'يرتفع بحدة',
            
            // Trends
            'bullish' => 'صاعد', 'bearish' => 'هابط', 'volatile' => 'متقلب',
            'new high' => 'أعلى مستوى جديد', 'all-time high' => 'أعلى مستوى على الإطلاق',
            'ATH' => 'أعلى مستوى تاريخي',
            'rally' => 'ارتفاع قوي', 'crash' => 'انهيار',
            
            // Other
            'investors' => 'مستثمرون', 'trader' => 'متداول',
            'trading' => 'تداول', 'exchange' => 'منصة تداول',
            'wallet' => 'محفظة', 'mining' => 'تعدين',
            'backed' => 'مدعوم', 'loans' => 'قروض',
            'unlock' => 'فتح', 'selloff' => 'عمليات بيع',
            'equity' => 'حصة', 'tokenize' => 'رمز'
        ];
        
        $translated = $text;
        foreach ($terms as $en => $ar) {
            $translated = str_ireplace($en, $ar, $translated);
        }
        
        return $translated;
    }
    
    /**
     * Get from cache
     */
    private static function getFromCache($hash) {
        try {
            $result = fetchOne("SELECT translated_text FROM translations_cache WHERE text_hash = ? LIMIT 1", [$hash]);
            return $result ? $result['translated_text'] : null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Save to cache
     */
    private static function saveToCache($original, $translated, $hash, $from, $to) {
        try {
            $sql = "INSERT INTO translations_cache (source_text, translated_text, text_hash, source_lang, target_lang)
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE translated_text = VALUES(translated_text)";
            executeQuery($sql, [$original, $translated, $hash, $from, $to]);
        } catch (Exception $e) {
            // Silent fail
        }
    }
    
    /**
     * Auto-translate all news (one function does it all)
     */
    public static function autoTranslateNews() {
        try {
            // Get untranslated news
            $sql = "SELECT id, title, summary FROM news_events 
                    WHERE (title_ar IS NULL OR title_ar = '') 
                    AND date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                    LIMIT 20";
            
            $news = fetchAll($sql);
            $count = 0;
            
            foreach ($news as $item) {
                $titleAr = self::translate($item['title']);
                $summaryAr = self::translate($item['summary']);
                
                executeQuery(
                    "UPDATE news_events SET title_ar = ?, summary_ar = ? WHERE id = ?",
                    [$titleAr, $summaryAr, $item['id']]
                );
                
                $count++;
                usleep(100000); // 0.1s delay
            }
            
            return $count;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    /**
     * Auto-translate all events (one function does it all)
     */
    public static function autoTranslateEvents() {
        try {
            // Get untranslated events
            $sql = "SELECT id, event_title, event_description FROM upcoming_events 
                    WHERE (event_title_ar IS NULL OR event_title_ar = '') 
                    AND event_date > NOW()
                    LIMIT 20";
            
            $events = fetchAll($sql);
            $count = 0;
            
            foreach ($events as $item) {
                $titleAr = self::translate($item['event_title']);
                $descAr = self::translate($item['event_description']);
                
                executeQuery(
                    "UPDATE upcoming_events SET event_title_ar = ?, event_description_ar = ? WHERE id = ?",
                    [$titleAr, $descAr, $item['id']]
                );
                
                $count++;
                usleep(100000); // 0.1s delay
            }
            
            return $count;
        } catch (Exception $e) {
            return 0;
        }
    }
}
?>

