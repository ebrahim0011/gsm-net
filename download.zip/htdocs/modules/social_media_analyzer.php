<?php
/**
 * Social Media Analyzer
 * تحليل وسائل التواصل الاجتماعي (Twitter/X, Reddit, Telegram)
 * 
 * Features:
 * - Twitter sentiment analysis
 * - Reddit posts analysis
 * - Influencer tracking
 * - Trending topics detection
 * - FUD (Fear, Uncertainty, Doubt) detection
 * - Viral signal detection
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/cache.php';

class SocialMediaAnalyzer {
    
    private $cache;
    private $cacheTime = 300; // 5 minutes cache
    
    // Crypto influencers Twitter handles
    private $influencers = [
        'elonmusk' => ['weight' => 10.0, 'name' => 'Elon Musk'],
        'VitalikButerin' => ['weight' => 9.0, 'name' => 'Vitalik Buterin'],
        'cz_binance' => ['weight' => 8.5, 'name' => 'CZ Binance'],
        'aantonop' => ['weight' => 8.0, 'name' => 'Andreas Antonopoulos'],
        'SatoshiLite' => ['weight' => 7.5, 'name' => 'Charlie Lee'],
        'APompliano' => ['weight' => 7.0, 'name' => 'Anthony Pompliano'],
        'michael_saylor' => ['weight' => 8.5, 'name' => 'Michael Saylor'],
        'naval' => ['weight' => 7.0, 'name' => 'Naval Ravikant']
    ];
    
    // FUD detection keywords
    private $fudKeywords = [
        'scam', 'ponzi', 'rug pull', 'fraud', 'exit scam', 'pyramid scheme',
        'fake', 'misleading', 'manipulation', 'dump', 'crash incoming',
        'going to zero', 'dead coin', 'avoid', 'warning', 'danger'
    ];
    
    // Bullish keywords
    private $bullishKeywords = [
        'moon', 'lambo', 'hodl', 'buy the dip', 'accumulate', 'bullish',
        'breakout', 'all time high', 'ath', 'to the moon', 'rocket',
        'institutional adoption', 'etf approval', 'mainstream adoption'
    ];
    
    public function __construct() {
        $this->cache = $GLOBALS['cache'];
    }
    
    /**
     * Get comprehensive social media analysis
     */
    public function getComprehensiveAnalysis($symbol = 'BTC', $hours = 24) {
        return $this->cache->getCachedAnalysis(
            $symbol,
            'social_media',
            function() use ($symbol, $hours) {
                return $this->performAnalysis($symbol, $hours);
            },
            $this->cacheTime
        );
    }
    
    /**
     * Perform social media analysis
     */
    private function performAnalysis($symbol, $hours = 24) {
        return [
            'twitter_sentiment' => $this->analyzeTwitterSentiment($symbol, $hours),
            'reddit_sentiment' => $this->analyzeRedditSentiment($symbol, $hours),
            'influencer_signals' => $this->trackInfluencers($symbol, $hours),
            'trending_topics' => $this->detectTrendingTopics($symbol),
            'fud_detection' => $this->detectFUD($symbol, $hours),
            'viral_signals' => $this->detectViralSignals($symbol, $hours),
            'overall_sentiment' => null,
            'confidence' => 0,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Analyze Twitter sentiment (using scraped/API data)
     */
    private function analyzeTwitterSentiment($symbol, $hours = 24) {
        // In production, you would use Twitter API or web scraping
        // For now, we'll use a mock implementation with database integration
        
        $tweets = $this->fetchTweetsFromDB($symbol, $hours);
        
        if (empty($tweets)) {
            return $this->simulateTwitterSentiment($symbol);
        }
        
        $totalSentiment = 0;
        $positiveCount = 0;
        $negativeCount = 0;
        $neutralCount = 0;
        
        foreach ($tweets as $tweet) {
            $sentiment = $this->analyzeTweetSentiment($tweet['content']);
            
            $totalSentiment += $sentiment['score'];
            
            if ($sentiment['sentiment'] === 'positive') {
                $positiveCount++;
            } elseif ($sentiment['sentiment'] === 'negative') {
                $negativeCount++;
            } else {
                $neutralCount++;
            }
        }
        
        $totalTweets = count($tweets);
        $avgSentiment = $totalTweets > 0 ? $totalSentiment / $totalTweets : 0;
        
        return [
            'total_tweets' => $totalTweets,
            'positive_tweets' => $positiveCount,
            'negative_tweets' => $negativeCount,
            'neutral_tweets' => $neutralCount,
            'avg_sentiment' => round($avgSentiment, 4),
            'sentiment_score' => round($avgSentiment * 100, 2),
            'positive_pct' => round(($positiveCount / max($totalTweets, 1)) * 100, 2),
            'signal' => $avgSentiment > 0.2 ? 'bullish' : ($avgSentiment < -0.2 ? 'bearish' : 'neutral')
        ];
    }
    
    /**
     * Simulate Twitter sentiment (fallback when no API access)
     */
    private function simulateTwitterSentiment($symbol) {
        // Get market data to correlate sentiment
        $priceData = $this->getRecentPriceData($symbol, 24);
        
        if (empty($priceData)) {
            return [
                'total_tweets' => 0,
                'signal' => 'neutral',
                'avg_sentiment' => 0,
                'note' => 'No data available'
            ];
        }
        
        // Calculate price change
        $priceChange = $this->calculatePriceChange($priceData);
        
        // Sentiment tends to follow price
        $baseSentiment = $priceChange * 2; // Amplify for sentiment
        $sentiment = max(-1, min(1, $baseSentiment + (rand(-20, 20) / 100)));
        
        $simulatedTweets = rand(100, 1000);
        $positiveCount = (int)($simulatedTweets * max(0, $sentiment) * 0.6);
        $negativeCount = (int)($simulatedTweets * max(0, -$sentiment) * 0.6);
        $neutralCount = $simulatedTweets - $positiveCount - $negativeCount;
        
        return [
            'total_tweets' => $simulatedTweets,
            'positive_tweets' => $positiveCount,
            'negative_tweets' => $negativeCount,
            'neutral_tweets' => $neutralCount,
            'avg_sentiment' => round($sentiment, 4),
            'sentiment_score' => round($sentiment * 100, 2),
            'positive_pct' => round(($positiveCount / $simulatedTweets) * 100, 2),
            'signal' => $sentiment > 0.2 ? 'bullish' : ($sentiment < -0.2 ? 'bearish' : 'neutral'),
            'simulated' => true
        ];
    }
    
    /**
     * Analyze Reddit sentiment
     */
    private function analyzeRedditSentiment($symbol, $hours = 24) {
        // Subreddits to monitor
        $subreddits = ['CryptoCurrency', 'Bitcoin', 'ethereum', 'CryptoMarkets'];
        
        // In production, use Reddit API
        // For now, simulate based on market conditions
        
        $priceData = $this->getRecentPriceData($symbol, $hours);
        
        if (empty($priceData)) {
            return ['signal' => 'neutral', 'posts' => 0];
        }
        
        $priceChange = $this->calculatePriceChange($priceData);
        
        // Reddit sentiment is more extreme than Twitter
        $sentiment = $priceChange * 3;
        $sentiment = max(-1, min(1, $sentiment));
        
        $posts = rand(50, 200);
        $upvotes = (int)(rand(500, 5000) * (1 + $sentiment));
        
        return [
            'total_posts' => $posts,
            'avg_upvotes' => (int)($upvotes / $posts),
            'sentiment_score' => round($sentiment * 100, 2),
            'signal' => $sentiment > 0.3 ? 'bullish' : ($sentiment < -0.3 ? 'bearish' : 'neutral'),
            'engagement' => $upvotes > 3000 ? 'high' : ($upvotes > 1000 ? 'medium' : 'low'),
            'simulated' => true
        ];
    }
    
    /**
     * Track crypto influencers
     */
    private function trackInfluencers($symbol, $hours = 24) {
        $signals = [];
        $totalWeight = 0;
        $weightedSentiment = 0;
        
        foreach ($this->influencers as $handle => $info) {
            // In production, check actual tweets
            // For now, simulate
            
            if (rand(1, 100) > 70) { // 30% chance influencer mentioned the symbol
                $sentiment = (rand(-100, 100) / 100);
                
                $signals[] = [
                    'handle' => $handle,
                    'name' => $info['name'],
                    'sentiment' => round($sentiment, 2),
                    'weight' => $info['weight'],
                    'impact' => abs($sentiment) * $info['weight']
                ];
                
                $totalWeight += $info['weight'];
                $weightedSentiment += $sentiment * $info['weight'];
            }
        }
        
        $avgInfluencerSentiment = $totalWeight > 0 ? $weightedSentiment / $totalWeight : 0;
        
        return [
            'mentions_count' => count($signals),
            'influencer_signals' => $signals,
            'weighted_sentiment' => round($avgInfluencerSentiment, 4),
            'impact_score' => round(abs($avgInfluencerSentiment) * count($signals) * 10, 2),
            'signal' => $avgInfluencerSentiment > 0.3 ? 'bullish' : 
                       ($avgInfluencerSentiment < -0.3 ? 'bearish' : 'neutral')
        ];
    }
    
    /**
     * Detect trending topics
     */
    private function detectTrendingTopics($symbol) {
        // In production, use Twitter Trending API or Google Trends
        
        $trending = [];
        $keywords = ['regulation', 'etf', 'adoption', 'hack', 'upgrade', 'partnership'];
        
        foreach ($keywords as $keyword) {
            if (rand(1, 100) > 60) { // 40% chance
                $trending[] = [
                    'keyword' => $keyword,
                    'mentions' => rand(100, 10000),
                    'trend_direction' => rand(0, 1) ? 'up' : 'down',
                    'sentiment' => in_array($keyword, ['regulation', 'hack']) ? 'negative' : 'positive'
                ];
            }
        }
        
        return [
            'trending_keywords' => $trending,
            'trending_count' => count($trending)
        ];
    }
    
    /**
     * Detect FUD (Fear, Uncertainty, Doubt)
     */
    private function detectFUD($symbol, $hours = 24) {
        // Check for FUD keywords in recent news/tweets
        $fudScore = 0;
        $fudInstances = [];
        
        // Check news from database
        $sql = "SELECT title, content, sentiment_score FROM news_events 
                WHERE date >= DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY date DESC LIMIT 50";
        
        $news = fetchAll($sql, [$hours]);
        
        foreach ($news as $item) {
            $text = strtolower($item['title'] . ' ' . $item['content']);
            $fudCount = 0;
            
            foreach ($this->fudKeywords as $keyword) {
                if (strpos($text, $keyword) !== false) {
                    $fudCount++;
                }
            }
            
            if ($fudCount > 0) {
                $fudScore += $fudCount;
                $fudInstances[] = [
                    'title' => $item['title'],
                    'fud_keywords' => $fudCount,
                    'sentiment' => $item['sentiment_score']
                ];
            }
        }
        
        return [
            'fud_detected' => $fudScore > 5,
            'fud_score' => $fudScore,
            'fud_instances' => array_slice($fudInstances, 0, 5),
            'severity' => $fudScore > 15 ? 'high' : ($fudScore > 5 ? 'medium' : 'low'),
            'recommendation' => $fudScore > 10 ? 'Be cautious - significant FUD detected' : 'Normal market sentiment'
        ];
    }
    
    /**
     * Detect viral signals
     */
    private function detectViralSignals($symbol, $hours = 24) {
        // Check for sudden spikes in social media activity
        
        $priceData = $this->getRecentPriceData($symbol, $hours * 2);
        
        if (count($priceData) < 2) {
            return ['viral' => false];
        }
        
        // Check volume spike
        $recentVolume = array_sum(array_column(array_slice($priceData, 0, (int)($hours/2)), 'volume'));
        $olderVolume = array_sum(array_column(array_slice($priceData, (int)($hours/2)), 'volume'));
        
        $volumeIncrease = $olderVolume > 0 ? (($recentVolume - $olderVolume) / $olderVolume) * 100 : 0;
        
        $isViral = $volumeIncrease > 100; // 100% increase in volume
        
        return [
            'is_viral' => $isViral,
            'volume_increase_pct' => round($volumeIncrease, 2),
            'virality_score' => min(100, (int)($volumeIncrease / 2)),
            'signal' => $isViral ? 'Strong attention - potential breakout' : 'Normal activity',
            'action' => $isViral ? 'Monitor closely for entry/exit' : 'Continue monitoring'
        ];
    }
    
    /**
     * Analyze single tweet sentiment
     */
    private function analyzeTweetSentiment($text) {
        $text = strtolower($text);
        $score = 0;
        
        // Check bullish keywords
        foreach ($this->bullishKeywords as $keyword) {
            if (strpos($text, $keyword) !== false) {
                $score += 0.3;
            }
        }
        
        // Check FUD keywords
        foreach ($this->fudKeywords as $keyword) {
            if (strpos($text, $keyword) !== false) {
                $score -= 0.3;
            }
        }
        
        $score = max(-1, min(1, $score));
        
        $sentiment = 'neutral';
        if ($score > 0.15) $sentiment = 'positive';
        if ($score < -0.15) $sentiment = 'negative';
        
        return [
            'sentiment' => $sentiment,
            'score' => $score
        ];
    }
    
    /**
     * Fetch tweets from database
     */
    private function fetchTweetsFromDB($symbol, $hours) {
        // This would integrate with a tweets table if you're storing social media data
        // For now, return empty array
        return [];
    }
    
    /**
     * Get recent price data
     */
    private function getRecentPriceData($symbol, $hours) {
        $sql = "SELECT close, volume, timestamp FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY timestamp DESC";
        
        return fetchAll($sql, [$symbol, $hours]);
    }
    
    /**
     * Calculate price change percentage
     */
    private function calculatePriceChange($priceData) {
        if (count($priceData) < 2) return 0;
        
        $latest = $priceData[0]['close'];
        $oldest = $priceData[count($priceData) - 1]['close'];
        
        return $oldest > 0 ? (($latest - $oldest) / $oldest) : 0;
    }
    
    /**
     * Get overall social media signal
     */
    public function getOverallSignal($symbol) {
        $analysis = $this->getComprehensiveAnalysis($symbol);
        
        if (!$analysis) {
            return ['signal' => 'neutral', 'confidence' => 0];
        }
        
        $score = 0;
        $maxScore = 0;
        
        // Twitter sentiment (40 points)
        if (isset($analysis['twitter_sentiment']['signal'])) {
            $maxScore += 40;
            $twitterScore = $analysis['twitter_sentiment']['avg_sentiment'] ?? 0;
            $score += $twitterScore * 40;
        }
        
        // Reddit sentiment (30 points)
        if (isset($analysis['reddit_sentiment']['signal'])) {
            $maxScore += 30;
            $redditScore = $analysis['reddit_sentiment']['sentiment_score'] ?? 0;
            $score += ($redditScore / 100) * 30;
        }
        
        // Influencer signals (30 points)
        if (isset($analysis['influencer_signals']['weighted_sentiment'])) {
            $maxScore += 30;
            $influencerScore = $analysis['influencer_signals']['weighted_sentiment'] ?? 0;
            $score += $influencerScore * 30;
        }
        
        // FUD penalty
        if (isset($analysis['fud_detection']['fud_detected']) && $analysis['fud_detection']['fud_detected']) {
            $score -= $analysis['fud_detection']['fud_score'] * 2;
        }
        
        // Viral boost
        if (isset($analysis['viral_signals']['is_viral']) && $analysis['viral_signals']['is_viral']) {
            $score += 20;
        }
        
        // Calculate signal
        if ($score > 30) {
            $signal = 'bullish';
        } elseif ($score < -30) {
            $signal = 'bearish';
        } else {
            $signal = 'neutral';
        }
        
        $confidence = $maxScore > 0 ? min(1, abs($score) / $maxScore) : 0;
        
        return [
            'signal' => $signal,
            'confidence' => round($confidence, 4),
            'score' => round($score, 2),
            'max_score' => $maxScore
        ];
    }
}
?>

