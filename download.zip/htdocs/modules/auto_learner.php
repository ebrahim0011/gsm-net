<?php
/**
 * Auto Learner - نظام التعلم التلقائي
 * يعدّل أوزان العوامل بناءً على الأداء الفعلي
 */

require_once __DIR__ . '/../config/database.php';

class AutoLearner {
    
    /**
     * Get current weights for all factors
     */
    public function getCurrentWeights() {
        try {
            // Check if table exists
            $checkSql = "SHOW TABLES LIKE 'dynamic_weights'";
            $tableExists = fetchOne($checkSql);
            
            if (!$tableExists) {
                // Return default weights if table doesn't exist
                return $this->getDefaultWeights();
            }
            
            $sql = "SELECT factor_name, current_weight FROM dynamic_weights";
            $weights = fetchAll($sql);
            
            // If no weights found, return defaults
            if (empty($weights)) {
                return $this->getDefaultWeights();
            }
            
            $result = [];
            foreach ($weights as $w) {
                $result[$w['factor_name']] = (float)$w['current_weight'];
            }
            
            return $result;
        } catch (Exception $e) {
            // On any error, return default weights
            return $this->getDefaultWeights();
        }
    }
    
    /**
     * Get default weights (fallback)
     */
    private function getDefaultWeights() {
        return [
            'ai_prediction' => 0.25,
            'volume_analysis' => 0.20,
            'fear_greed' => 0.15,
            'technical' => 0.20,
            'sentiment' => 0.15,
            'patterns' => 0.05
        ];
    }
    
    /**
     * Learn from prediction result
     * يُستدعى بعد تقييم كل توقع
     */
    public function learnFromPrediction($predictionData, $wasCorrect) {
        // Extract which factors contributed to this prediction
        $factors = $this->identifyContributingFactors($predictionData);
        
        foreach ($factors as $factor => $contribution) {
            $this->updateFactorWeight($factor, $wasCorrect, $contribution);
        }
    }
    
    /**
     * Update weight for a specific factor
     */
    private function updateFactorWeight($factorName, $wasCorrect, $contribution = 1.0) {
        try {
            // Check if table exists
            $checkSql = "SHOW TABLES LIKE 'dynamic_weights'";
            $tableExists = fetchOne($checkSql);
            
            if (!$tableExists) {
                // Table doesn't exist yet, skip learning
                return;
            }
            
            // Get current stats
            $sql = "SELECT * FROM dynamic_weights WHERE factor_name = ?";
            $factor = fetchOne($sql, [$factorName]);
            
            if (!$factor) return;
            
            // Update counts
            if ($wasCorrect) {
                $newSuccess = $factor['success_count'] + 1;
                $newFailure = $factor['failure_count'];
            } else {
                $newSuccess = $factor['success_count'];
                $newFailure = $factor['failure_count'] + 1;
            }
            
            $totalPredictions = $newSuccess + $newFailure;
            $newAccuracy = $totalPredictions > 0 ? ($newSuccess / $totalPredictions) * 100 : 0;
            
            // Calculate new weight (التعديل التدريجي)
            $currentWeight = (float)$factor['current_weight'];
            $defaultWeight = (float)$factor['default_weight'];
            
            // Learning rate: 0.05 = 5% adjustment per update
            $learningRate = 0.05;
            
            if ($wasCorrect) {
                // Increase weight slightly if prediction was correct
                $newWeight = $currentWeight + ($learningRate * $contribution * 0.01);
            } else {
                // Decrease weight slightly if prediction was wrong
                $newWeight = $currentWeight - ($learningRate * $contribution * 0.01);
            }
            
            // Keep weight within reasonable bounds (50% to 150% of default)
            $minWeight = $defaultWeight * 0.5;
            $maxWeight = $defaultWeight * 1.5;
            $newWeight = max($minWeight, min($maxWeight, $newWeight));
            
            // Update database
            $updateSql = "UPDATE dynamic_weights 
                          SET current_weight = ?,
                              success_count = ?,
                              failure_count = ?,
                              accuracy_rate = ?
                          WHERE factor_name = ?";
            
            executeQuery($updateSql, [
                $newWeight,
                $newSuccess,
                $newFailure,
                $newAccuracy,
                $factorName
            ]);
            
        } catch (Exception $e) {
            // Silent fail - don't break the system
            return;
        }
    }
    
    /**
     * Identify which factors contributed to a prediction
     */
    private function identifyContributingFactors($predictionData) {
        $factors = [];
        
        // This data comes from the prediction features
        if (isset($predictionData['ai_signal'])) {
            $factors['ai_prediction'] = 1.0;
        }
        if (isset($predictionData['volume_score'])) {
            $factors['volume_analysis'] = abs($predictionData['volume_score']) / 100;
        }
        if (isset($predictionData['fear_greed_value'])) {
            $factors['fear_greed'] = 1.0;
        }
        if (isset($predictionData['technical_indicators'])) {
            $factors['technical'] = 1.0;
        }
        if (isset($predictionData['sentiment_score'])) {
            $factors['sentiment'] = abs($predictionData['sentiment_score']);
        }
        if (isset($predictionData['pattern_match'])) {
            $factors['patterns'] = 1.0;
        }
        
        return $factors;
    }
    
    /**
     * Get learning statistics
     */
    public function getLearningStats() {
        try {
            // Check if table exists
            $checkSql = "SHOW TABLES LIKE 'dynamic_weights'";
            $tableExists = fetchOne($checkSql);
            
            if (!$tableExists) {
                return [];
            }
            
            $sql = "SELECT 
                        factor_name,
                        current_weight,
                        default_weight,
                        success_count,
                        failure_count,
                        accuracy_rate,
                        ROUND((current_weight - default_weight) / default_weight * 100, 2) as weight_change_pct
                    FROM dynamic_weights
                    ORDER BY accuracy_rate DESC";
            
            return fetchAll($sql);
        } catch (Exception $e) {
            return [];
        }
    }
    
    /**
     * Reset weights to default (if needed)
     */
    public function resetWeights() {
        try {
            // Check if table exists
            $checkSql = "SHOW TABLES LIKE 'dynamic_weights'";
            $tableExists = fetchOne($checkSql);
            
            if (!$tableExists) {
                return false;
            }
            
            $sql = "UPDATE dynamic_weights 
                    SET current_weight = default_weight,
                        success_count = 0,
                        failure_count = 0,
                        accuracy_rate = 0.00";
            
            return executeQuery($sql);
        } catch (Exception $e) {
            return false;
        }
    }
}

