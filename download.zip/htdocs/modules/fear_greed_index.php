<?php
/**
 * Fear & Greed Index Module
 * مؤشر الخوف والطمع
 * 
 * Fetches real-time Fear & Greed Index from Alternative.me API
 * Index ranges from 0 (Extreme Fear) to 100 (Extreme Greed)
 * 
 * Interpretation:
 * 0-24   : Extreme Fear (Orange) 🟠 - Good buying opportunity
 * 25-44  : Fear (Amber/Yellow) 🟡 - Some fear in market
 * 45-55  : Neutral (Light Green) 🟢 - Balanced market
 * 56-75  : Greed (Light Green) 🟢 - Market is greedy
 * 76-100 : Extreme Greed (Green) 🟢 - Consider taking profits
 */

class FearGreedIndex {
    
    private $apiUrl = 'https://api.alternative.me/fng/';
    private $cacheFile = __DIR__ . '/../data/fear_greed_cache.json';
    private $cacheLifetime = 3600; // 1 hour cache
    
    /**
     * Get current Fear & Greed Index
     */
    public function getCurrentIndex() {
        // Check cache first
        $cached = $this->getFromCache();
        if ($cached) {
            return $cached;
        }
        
        // Fetch from API
        $data = $this->fetchFromAPI();
        
        if ($data) {
            $this->saveToCache($data);
            return $data;
        }
        
        // Return neutral if API fails
        return $this->getNeutralFallback();
    }
    
    /**
     * Fetch from Alternative.me API
     */
    private function fetchFromAPI() {
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->apiUrl . '?limit=1');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 && $response) {
                $json = json_decode($response, true);
                
                if (isset($json['data'][0])) {
                    $data = $json['data'][0];
                    return $this->parseData($data);
                }
            }
        } catch (Exception $e) {
            // Silent fail
        }
        
        return null;
    }
    
    /**
     * Parse API data
     */
    private function parseData($data) {
        $value = (int)$data['value'];
        $classification = $data['value_classification'];
        
        return [
            'value' => $value,
            'classification' => $classification,
            'sentiment' => $this->getSentiment($value),
            'signal' => $this->getSignal($value),
            'color' => $this->getColor($value),
            'emoji' => $this->getEmoji($value),
            'description' => $this->getDescription($value),
            'recommendation' => $this->getRecommendation($value),
            'timestamp' => $data['timestamp'],
            'time_until_update' => isset($data['time_until_update']) ? $data['time_until_update'] : null
        ];
    }
    
    /**
     * Get sentiment from value
     */
    private function getSentiment($value) {
        if ($value <= 24) return 'extreme_fear';
        if ($value <= 44) return 'fear';
        if ($value <= 55) return 'neutral';
        if ($value <= 75) return 'greed';
        return 'extreme_greed';
    }
    
    /**
     * Get trading signal from value
     */
    private function getSignal($value) {
        if ($value <= 20) return 'strong_buy';      // Extreme fear = opportunity
        if ($value <= 35) return 'buy';             // Fear = good entry
        if ($value <= 55) return 'hold';            // Neutral = wait
        if ($value <= 75) return 'consider_sell';   // Greed = be cautious
        return 'strong_sell';                        // Extreme greed = take profits
    }
    
    /**
     * Get color for UI
     */
    private function getColor($value) {
        if ($value <= 24) return '#ea3943'; // Red
        if ($value <= 44) return '#f5a524'; // Orange
        if ($value <= 55) return '#f7ca18'; // Yellow
        if ($value <= 75) return '#93d900'; // Light Green
        return '#16c784';                    // Green
    }
    
    /**
     * Get emoji
     */
    private function getEmoji($value) {
        if ($value <= 24) return '😱'; // Extreme Fear
        if ($value <= 44) return '😨'; // Fear
        if ($value <= 55) return '😐'; // Neutral
        if ($value <= 75) return '😊'; // Greed
        return '🤑';                    // Extreme Greed
    }
    
    /**
     * Get description (bilingual)
     */
    private function getDescription($value) {
        $descriptions = [
            'extreme_fear' => [
                'en' => 'Extreme Fear - Investors are very worried. This could be a buying opportunity.',
                'ar' => 'خوف شديد - المستثمرون قلقون جداً. قد تكون هذه فرصة شراء.'
            ],
            'fear' => [
                'en' => 'Fear - The market is fearful. Good time for contrarian investors.',
                'ar' => 'خوف - السوق خائف. وقت جيد للمستثمرين المعاكسين.'
            ],
            'neutral' => [
                'en' => 'Neutral - Market sentiment is balanced.',
                'ar' => 'محايد - معنويات السوق متوازنة.'
            ],
            'greed' => [
                'en' => 'Greed - Investors are getting greedy. Be cautious.',
                'ar' => 'طمع - المستثمرون يصبحون طماعين. كن حذراً.'
            ],
            'extreme_greed' => [
                'en' => 'Extreme Greed - Too much greed. Consider taking profits.',
                'ar' => 'طمع شديد - طمع مفرط. فكر في جني الأرباح.'
            ]
        ];
        
        return $descriptions[$this->getSentiment($value)];
    }
    
    /**
     * Get recommendation (bilingual)
     */
    private function getRecommendation($value) {
        $recommendations = [
            'extreme_fear' => [
                'en' => 'Strong buying opportunity. Fear creates opportunities.',
                'ar' => 'فرصة شراء قوية. الخوف يخلق الفرص.'
            ],
            'fear' => [
                'en' => 'Good time to accumulate. Others are fearful.',
                'ar' => 'وقت جيد للتراكم. الآخرون خائفون.'
            ],
            'neutral' => [
                'en' => 'Wait for clearer signals. Market is balanced.',
                'ar' => 'انتظر إشارات أوضح. السوق متوازن.'
            ],
            'greed' => [
                'en' => 'Be cautious. Consider reducing positions.',
                'ar' => 'كن حذراً. فكر في تقليل المراكز.'
            ],
            'extreme_greed' => [
                'en' => 'High risk. Consider taking profits off the table.',
                'ar' => 'مخاطرة عالية. فكر في جني الأرباح.'
            ]
        ];
        
        return $recommendations[$this->getSentiment($value)];
    }
    
    /**
     * Get from cache
     */
    private function getFromCache() {
        if (!file_exists($this->cacheFile)) {
            return null;
        }
        
        $cacheData = file_get_contents($this->cacheFile);
        $cache = json_decode($cacheData, true);
        
        if ($cache && isset($cache['timestamp']) && (time() - $cache['timestamp']) < $this->cacheLifetime) {
            return $cache['data'];
        }
        
        return null;
    }
    
    /**
     * Save to cache
     */
    private function saveToCache($data) {
        $cacheData = [
            'timestamp' => time(),
            'data' => $data
        ];
        
        // Ensure data directory exists
        $dataDir = dirname($this->cacheFile);
        if (!is_dir($dataDir)) {
            mkdir($dataDir, 0755, true);
        }
        
        file_put_contents($this->cacheFile, json_encode($cacheData));
    }
    
    /**
     * Get neutral fallback if API fails
     */
    private function getNeutralFallback() {
        return [
            'value' => 50,
            'classification' => 'Neutral',
            'sentiment' => 'neutral',
            'signal' => 'hold',
            'color' => '#f7ca18',
            'emoji' => '😐',
            'description' => 'Market sentiment is balanced (API unavailable).',
            'recommendation' => 'Wait for clearer signals.',
            'timestamp' => time(),
            'time_until_update' => null
        ];
    }
    
    /**
     * Get historical data (last 30 days)
     */
    public function getHistoricalData($limit = 30) {
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->apiUrl . "?limit={$limit}");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 && $response) {
                $json = json_decode($response, true);
                
                if (isset($json['data'])) {
                    return array_map(function($item) {
                        return [
                            'value' => (int)$item['value'],
                            'classification' => $item['value_classification'],
                            'timestamp' => $item['timestamp']
                        ];
                    }, $json['data']);
                }
            }
        } catch (Exception $e) {
            // Silent fail
        }
        
        return [];
    }
}
?>

