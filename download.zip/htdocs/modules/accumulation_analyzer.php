<?php
/**
 * 🐋 Accumulation/Distribution Analyzer
 * 
 * Detects whale accumulation, distribution patterns, and exchange flows
 * 
 * Features:
 * - Accumulation/Distribution Line (A/D Line)
 * - Whale wallet activity detection
 * - Exchange inflow/outflow analysis
 * - HODLer behavior tracking
 * - Smart Money vs Retail detection
 */

require_once __DIR__ . '/../config/database.php';

class AccumulationAnalyzer {
    
    private $cacheTime = 600; // 10 minutes cache
    
    /**
     * Get comprehensive accumulation analysis
     */
    public function getAccumulationAnalysis($symbol = 'BTC') {
        // Try cache first
        $cached = $this->getCachedData($symbol);
        if ($cached) {
            return $cached;
        }
        
        // Calculate accumulation metrics
        $analysis = [
            'ad_line' => $this->calculateADLine($symbol),
            'whale_activity' => $this->detectWhaleActivity($symbol),
            'exchange_flow' => $this->analyzeExchangeFlow($symbol),
            'hodler_strength' => $this->calculateHODLerStrength($symbol),
            'smart_money' => $this->detectSmartMoney($symbol),
            'overall_signal' => null,
            'confidence' => 0,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // Calculate overall signal
        $analysis['overall_signal'] = $this->calculateOverallSignal($analysis);
        $analysis['confidence'] = $this->calculateConfidence($analysis);
        $analysis['recommendations'] = $this->generateRecommendations($analysis);
        
        // Cache the results
        $this->cacheData($symbol, $analysis);
        
        return $analysis;
    }
    
    /**
     * Calculate Accumulation/Distribution Line
     * Based on Money Flow Multiplier and Money Flow Volume
     */
    private function calculateADLine($symbol) {
        // Get recent price data with volume
        $sql = "SELECT timestamp, high, low, close, volume 
                FROM market_prices 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT 50";
        
        $prices = fetchAll($sql, [$symbol]);
        
        if (empty($prices)) {
            return $this->getDefaultADLine();
        }
        
        $adLine = 0;
        $adValues = [];
        
        foreach (array_reverse($prices) as $price) {
            $high = $price['high'];
            $low = $price['low'];
            $close = $price['close'];
            $volume = $price['volume'];
            
            // Money Flow Multiplier = [(Close - Low) - (High - Close)] / (High - Low)
            $range = $high - $low;
            if ($range > 0) {
                $mfm = (($close - $low) - ($high - $close)) / $range;
            } else {
                $mfm = 0;
            }
            
            // Money Flow Volume = MFM × Volume
            $mfv = $mfm * $volume;
            
            // A/D Line = Previous A/D + Current MFV
            $adLine += $mfv;
            $adValues[] = $adLine;
        }
        
        // Analyze trend
        $recentValues = array_slice($adValues, -10);
        $olderValues = array_slice($adValues, -20, 10);
        
        $recentAvg = array_sum($recentValues) / count($recentValues);
        $olderAvg = array_sum($olderValues) / count($olderValues);
        
        $trend = 'neutral';
        $strength = 0;
        
        if ($recentAvg > $olderAvg * 1.05) {
            $trend = 'accumulation';
            $strength = min(100, abs(($recentAvg - $olderAvg) / $olderAvg) * 100);
        } elseif ($recentAvg < $olderAvg * 0.95) {
            $trend = 'distribution';
            $strength = min(100, abs(($recentAvg - $olderAvg) / $olderAvg) * 100);
        }
        
        return [
            'current_value' => end($adValues),
            'trend' => $trend,
            'strength' => round($strength, 2),
            'signal' => $trend === 'accumulation' ? 'bullish' : ($trend === 'distribution' ? 'bearish' : 'neutral'),
            'confidence' => $strength > 30 ? 'high' : ($strength > 15 ? 'medium' : 'low')
        ];
    }
    
    /**
     * Detect whale activity through volume spikes
     */
    private function detectWhaleActivity($symbol) {
        // Get volume data
        $sql = "SELECT timestamp, volume, close 
                FROM market_prices 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT 100";
        
        $prices = fetchAll($sql, [$symbol]);
        
        if (count($prices) < 20) {
            return $this->getDefaultWhaleActivity();
        }
        
        $volumes = array_column($prices, 'volume');
        $avgVolume = array_sum($volumes) / count($volumes);
        $recentVolume = $prices[0]['volume'];
        
        // Calculate volume spike
        $volumeMultiplier = $avgVolume > 0 ? $recentVolume / $avgVolume : 1;
        
        // Detect unusual activity (>2x average = potential whale)
        $isWhaleActive = $volumeMultiplier > 2.0;
        
        // Determine if accumulating or distributing
        $recentPrices = array_slice($prices, 0, 5);
        $priceChange = 0;
        
        if (count($recentPrices) >= 2) {
            $priceChange = (($recentPrices[0]['close'] - $recentPrices[4]['close']) / $recentPrices[4]['close']) * 100;
        }
        
        $whaleAction = 'neutral';
        if ($isWhaleActive) {
            if ($priceChange > 1) {
                $whaleAction = 'accumulating'; // High volume + price up = buying
            } elseif ($priceChange < -1) {
                $whaleAction = 'distributing'; // High volume + price down = selling
            } else {
                $whaleAction = 'active'; // High volume but price stable
            }
        }
        
        return [
            'is_active' => $isWhaleActive,
            'action' => $whaleAction,
            'volume_multiplier' => round($volumeMultiplier, 2),
            'signal' => $whaleAction === 'accumulating' ? 'bullish' : ($whaleAction === 'distributing' ? 'bearish' : 'neutral'),
            'alert_level' => $volumeMultiplier > 3 ? 'high' : ($volumeMultiplier > 2 ? 'medium' : 'low')
        ];
    }
    
    /**
     * Analyze exchange inflow/outflow
     * High outflow = accumulation (moving to cold wallets)
     * High inflow = potential selling
     */
    private function analyzeExchangeFlow($symbol) {
        // Since we don't have real exchange flow data, we estimate based on:
        // - Volume trends
        // - Price action correlation
        // - Market sentiment
        
        $sql = "SELECT volume, close 
                FROM market_prices 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT 30";
        
        $prices = fetchAll($sql, [$symbol]);
        
        if (count($prices) < 10) {
            return $this->getDefaultExchangeFlow();
        }
        
        // Recent vs older volume
        $recentVolumes = array_slice(array_column($prices, 'volume'), 0, 7);
        $olderVolumes = array_slice(array_column($prices, 'volume'), 7, 7);
        
        $recentAvgVol = array_sum($recentVolumes) / count($recentVolumes);
        $olderAvgVol = array_sum($olderVolumes) / count($olderVolumes);
        
        // Price trend
        $recentPrices = array_slice(array_column($prices, 'close'), 0, 7);
        $priceChange = (($recentPrices[0] - $recentPrices[6]) / $recentPrices[6]) * 100;
        
        // Estimate flow based on volume and price correlation
        $flowDirection = 'neutral';
        $flowStrength = 0;
        
        if ($recentAvgVol > $olderAvgVol && $priceChange < -2) {
            $flowDirection = 'inflow'; // Volume up + price down = selling on exchanges
            $flowStrength = min(100, abs($priceChange) * 10);
        } elseif ($recentAvgVol < $olderAvgVol && $priceChange > 2) {
            $flowDirection = 'outflow'; // Volume down + price up = accumulation (off-exchange)
            $flowStrength = min(100, abs($priceChange) * 10);
        }
        
        return [
            'direction' => $flowDirection,
            'strength' => round($flowStrength, 2),
            'signal' => $flowDirection === 'outflow' ? 'bullish' : ($flowDirection === 'inflow' ? 'bearish' : 'neutral'),
            'interpretation' => $this->getFlowInterpretation($flowDirection)
        ];
    }
    
    /**
     * Calculate HODLer strength
     * Based on volume patterns and price stability
     */
    private function calculateHODLerStrength($symbol) {
        $sql = "SELECT volume, close 
                FROM market_prices 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT 60";
        
        $prices = fetchAll($sql, [$symbol]);
        
        if (count($prices) < 30) {
            return $this->getDefaultHODLerStrength();
        }
        
        // Calculate price volatility (lower = stronger HODLing)
        $closes = array_column($prices, 'close');
        $avgPrice = array_sum($closes) / count($closes);
        $variance = 0;
        
        foreach ($closes as $price) {
            $variance += pow($price - $avgPrice, 2);
        }
        $stdDev = sqrt($variance / count($closes));
        $volatility = ($stdDev / $avgPrice) * 100;
        
        // Calculate volume trend (lower = less selling = stronger hands)
        $volumes = array_column($prices, 'volume');
        $recentVol = array_sum(array_slice($volumes, 0, 10)) / 10;
        $olderVol = array_sum(array_slice($volumes, 10, 20)) / 20;
        
        $volumeChange = (($recentVol - $olderVol) / $olderVol) * 100;
        
        // HODLer strength score (0-100)
        // Low volatility + Low volume = Strong HODLers
        $hodlerScore = 50; // Base score
        
        if ($volatility < 3) $hodlerScore += 30;
        elseif ($volatility < 5) $hodlerScore += 20;
        elseif ($volatility < 8) $hodlerScore += 10;
        
        if ($volumeChange < -10) $hodlerScore += 20;
        elseif ($volumeChange < 0) $hodlerScore += 10;
        elseif ($volumeChange > 20) $hodlerScore -= 20;
        
        $hodlerScore = max(0, min(100, $hodlerScore));
        
        $strength = 'weak';
        if ($hodlerScore > 70) $strength = 'strong';
        elseif ($hodlerScore > 50) $strength = 'medium';
        
        return [
            'score' => round($hodlerScore, 2),
            'strength' => $strength,
            'volatility' => round($volatility, 2),
            'signal' => $hodlerScore > 60 ? 'bullish' : ($hodlerScore < 40 ? 'bearish' : 'neutral')
        ];
    }
    
    /**
     * Detect smart money vs retail behavior
     */
    private function detectSmartMoney($symbol) {
        $adLine = $this->calculateADLine($symbol);
        $whale = $this->detectWhaleActivity($symbol);
        $flow = $this->analyzeExchangeFlow($symbol);
        
        // Smart money typically:
        // 1. Accumulates when price is down (divergence)
        // 2. Has whale activity
        // 3. Moves coins off exchanges
        
        $smartMoneyActive = false;
        $action = 'neutral';
        $confidence = 0;
        
        if ($adLine['trend'] === 'accumulation' && $whale['is_active'] && $flow['direction'] === 'outflow') {
            $smartMoneyActive = true;
            $action = 'accumulating';
            $confidence = 75;
        } elseif ($adLine['trend'] === 'distribution' && $whale['is_active'] && $flow['direction'] === 'inflow') {
            $smartMoneyActive = true;
            $action = 'distributing';
            $confidence = 75;
        }
        
        return [
            'is_active' => $smartMoneyActive,
            'action' => $action,
            'confidence' => $confidence,
            'signal' => $action === 'accumulating' ? 'bullish' : ($action === 'distributing' ? 'bearish' : 'neutral')
        ];
    }
    
    /**
     * Calculate overall accumulation signal
     */
    private function calculateOverallSignal($analysis) {
        $signals = [
            $analysis['ad_line']['signal'],
            $analysis['whale_activity']['signal'],
            $analysis['exchange_flow']['signal'],
            $analysis['hodler_strength']['signal'],
            $analysis['smart_money']['signal']
        ];
        
        $bullishCount = count(array_filter($signals, fn($s) => $s === 'bullish'));
        $bearishCount = count(array_filter($signals, fn($s) => $s === 'bearish'));
        
        if ($bullishCount >= 4) return 'strong_accumulation';
        if ($bullishCount >= 3) return 'accumulation';
        if ($bearishCount >= 4) return 'strong_distribution';
        if ($bearishCount >= 3) return 'distribution';
        
        return 'neutral';
    }
    
    /**
     * Calculate confidence level
     */
    private function calculateConfidence($analysis) {
        $score = 0;
        
        // A/D Line confidence
        if ($analysis['ad_line']['confidence'] === 'high') $score += 30;
        elseif ($analysis['ad_line']['confidence'] === 'medium') $score += 20;
        
        // Whale activity
        if ($analysis['whale_activity']['is_active']) $score += 25;
        
        // Exchange flow
        if ($analysis['exchange_flow']['direction'] !== 'neutral') $score += 20;
        
        // HODLer strength
        if ($analysis['hodler_strength']['strength'] === 'strong') $score += 15;
        elseif ($analysis['hodler_strength']['strength'] === 'medium') $score += 10;
        
        // Smart money
        if ($analysis['smart_money']['is_active']) $score += 10;
        
        return min(100, $score);
    }
    
    /**
     * Generate recommendations
     */
    private function generateRecommendations($analysis) {
        $recommendations = [];
        $isRTL = isset($_COOKIE['lang']) && $_COOKIE['lang'] === 'ar';
        
        $signal = $analysis['overall_signal'];
        
        if ($signal === 'strong_accumulation') {
            $recommendations[] = [
                'type' => 'accumulation',
                'priority' => 'high',
                'message_en' => '🐋 Strong accumulation detected! Whales are buying. Consider this a buying opportunity.',
                'message_ar' => '🐋 تراكم قوي! الحيتان تشتري. فكر في هذه فرصة شراء.'
            ];
        } elseif ($signal === 'accumulation') {
            $recommendations[] = [
                'type' => 'accumulation',
                'priority' => 'medium',
                'message_en' => '📈 Accumulation phase. Smart money is entering the market.',
                'message_ar' => '📈 مرحلة تراكم. الأموال الذكية تدخل السوق.'
            ];
        } elseif ($signal === 'strong_distribution') {
            $recommendations[] = [
                'type' => 'distribution',
                'priority' => 'high',
                'message_en' => '⚠️ Strong distribution! Whales are selling. Be cautious.',
                'message_ar' => '⚠️ توزيع قوي! الحيتان تبيع. كن حذراً.'
            ];
        } elseif ($signal === 'distribution') {
            $recommendations[] = [
                'type' => 'distribution',
                'priority' => 'medium',
                'message_en' => '📉 Distribution phase. Consider taking profits or waiting.',
                'message_ar' => '📉 مرحلة توزيع. فكر في جني الأرباح أو الانتظار.'
            ];
        }
        
        // Whale activity alert
        if ($analysis['whale_activity']['is_active'] && $analysis['whale_activity']['alert_level'] === 'high') {
            $recommendations[] = [
                'type' => 'whale',
                'priority' => 'high',
                'message_en' => '🐋 Extreme whale activity detected! Volume is ' . $analysis['whale_activity']['volume_multiplier'] . 'x normal.',
                'message_ar' => '🐋 نشاط حيتان شديد! الحجم ' . $analysis['whale_activity']['volume_multiplier'] . 'x من المعتاد.'
            ];
        }
        
        // Exchange flow recommendation
        if ($analysis['exchange_flow']['direction'] === 'outflow' && $analysis['exchange_flow']['strength'] > 50) {
            $recommendations[] = [
                'type' => 'flow',
                'priority' => 'medium',
                'message_en' => '🔒 Strong outflow from exchanges. Investors are HODLing - bullish signal.',
                'message_ar' => '🔒 تدفق قوي خارج المنصات. المستثمرون يمسكون - إشارة صاعدة.'
            ];
        } elseif ($analysis['exchange_flow']['direction'] === 'inflow' && $analysis['exchange_flow']['strength'] > 50) {
            $recommendations[] = [
                'type' => 'flow',
                'priority' => 'medium',
                'message_en' => '📥 Strong inflow to exchanges. Potential selling pressure ahead.',
                'message_ar' => '📥 تدفق قوي للمنصات. ضغط بيع محتمل قادم.'
            ];
        }
        
        return $recommendations;
    }
    
    /**
     * Default values
     */
    private function getDefaultADLine() {
        return [
            'current_value' => 0,
            'trend' => 'neutral',
            'strength' => 0,
            'signal' => 'neutral',
            'confidence' => 'low'
        ];
    }
    
    private function getDefaultWhaleActivity() {
        return [
            'is_active' => false,
            'action' => 'neutral',
            'volume_multiplier' => 1.0,
            'signal' => 'neutral',
            'alert_level' => 'low'
        ];
    }
    
    private function getDefaultExchangeFlow() {
        return [
            'direction' => 'neutral',
            'strength' => 0,
            'signal' => 'neutral',
            'interpretation' => 'No significant flow detected'
        ];
    }
    
    private function getDefaultHODLerStrength() {
        return [
            'score' => 50,
            'strength' => 'medium',
            'volatility' => 5.0,
            'signal' => 'neutral'
        ];
    }
    
    private function getFlowInterpretation($direction) {
        $isRTL = isset($_COOKIE['lang']) && $_COOKIE['lang'] === 'ar';
        
        $interpretations = [
            'inflow' => [
                'en' => 'Coins moving TO exchanges - potential selling',
                'ar' => 'العملات تنتقل إلى المنصات - بيع محتمل'
            ],
            'outflow' => [
                'en' => 'Coins moving FROM exchanges - accumulation/HODLing',
                'ar' => 'العملات تخرج من المنصات - تراكم/إمساك'
            ],
            'neutral' => [
                'en' => 'Balanced flow - no significant movement',
                'ar' => 'تدفق متوازن - لا حركة ملحوظة'
            ]
        ];
        
        return $isRTL ? $interpretations[$direction]['ar'] : $interpretations[$direction]['en'];
    }
    
    /**
     * Cache management
     */
    private function cacheData($symbol, $data) {
        try {
            $sql = "INSERT INTO liquidity_cache (cache_key, cache_data, created_at)
                    VALUES (?, ?, NOW())
                    ON DUPLICATE KEY UPDATE cache_data = VALUES(cache_data), created_at = NOW()";
            
            executeQuery($sql, ['accumulation_' . $symbol, json_encode($data)]);
        } catch (Exception $e) {
            // Cache table might not exist - ignore
        }
    }
    
    private function getCachedData($symbol) {
        try {
            $sql = "SELECT cache_data FROM liquidity_cache 
                    WHERE cache_key = ? 
                    AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)";
            
            $result = fetchOne($sql, ['accumulation_' . $symbol, $this->cacheTime]);
            
            if ($result) {
                return json_decode($result['cache_data'], true);
            }
        } catch (Exception $e) {
            // Cache table might not exist
        }
        
        return null;
    }
}
?>

