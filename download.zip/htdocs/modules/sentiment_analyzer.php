<?php
/**
 * Sentiment Analyzer Module
 * 
 * Analyzes sentiment of cryptocurrency news articles
 * Uses keyword-based approach with weighted scoring
 */

class SentimentAnalyzer {
    
    // Enhanced positive keywords with weights
    private $positiveWords = [
        // Strong bullish (weight 3.0)
        'moon', 'rocket', 'surge', 'skyrocket', 'breakthrough', 'explosion', 'massive gain',
        'all-time high', 'ath', 'bullish breakout', 'golden cross', 'major rally',
        
        // Medium bullish (weight 2.0)
        'bullish', 'bull', 'rally', 'gain', 'profit', 'growth', 'rise', 'increase',
        'boom', 'success', 'adoption', 'partnership', 'innovation', 'upgrade',
        'positive', 'optimistic', 'strong', 'outperform', 'milestone', 'record',
        'high', 'peak', 'momentum', 'advance', 'boost', 'expansion', 'achievement',
        
        // Mild positive (weight 1.0)
        'opportunity', 'potential', 'promising', 'win', 'support', 'accumulation',
        'buying pressure', 'institutional', 'whale buying', 'hodl', 'diamond hands'
    ];
    
    // Enhanced negative keywords with weights
    private $negativeWords = [
        // Strong bearish (weight 3.0)
        'crash', 'collapse', 'plunge', 'bloodbath', 'capitulation', 'death cross',
        'bear market', 'major sell-off', 'panic selling', 'market crash',
        
        // Medium bearish (weight 2.0)
        'bearish', 'bear', 'drop', 'fall', 'loss', 'decline', 'decrease', 'slump',
        'failure', 'hack', 'scam', 'fraud', 'risk', 'concern', 'warning',
        'negative', 'pessimistic', 'weak', 'underperform', 'crisis', 'low',
        'bottom', 'downturn', 'recession', 'selloff', 'dump', 'panic', 'fear',
        
        // Mild negative (weight 1.0)
        'uncertainty', 'volatility', 'lawsuit', 'regulation', 'ban', 'resistance',
        'selling pressure', 'profit taking', 'correction', 'pullback', 'dip'
    ];
    
    private $strongModifiers = [
        'very', 'extremely', 'highly', 'significantly', 'substantially', 'dramatically',
        'massive', 'huge', 'tremendous', 'exceptional', 'unprecedented'
    ];
    
    // High-impact news keywords (5x weight)
    private $criticalKeywords = [
        'bitcoin etf', 'sec approval', 'federal reserve', 'interest rate', 'inflation',
        'tether', 'usdc', 'binance', 'coinbase', 'ftx', 'blackrock', 'microstrategy',
        'el salvador', 'china ban', 'us regulation', 'fed meeting', 'cpi data'
    ];
    
    /**
     * Enhanced sentiment analysis with contextual understanding
     * Returns: ['sentiment' => 'positive/negative/neutral', 'score' => -1 to 1, 'confidence' => 0 to 1]
     */
    public function analyze($text) {
        $originalText = $text;
        $text = strtolower($text);
        $words = $this->tokenize($text);
        
        $positiveScore = 0;
        $negativeScore = 0;
        $confidenceBoost = 0;
        
        // Check for critical news that affects market strongly
        foreach ($this->criticalKeywords as $keyword) {
            if (strpos($text, $keyword) !== false) {
                $confidenceBoost += 0.3; // Critical news = higher confidence
            }
        }
        
        // Advanced sentiment scoring with context
        foreach ($words as $i => $word) {
            $weight = 1.0;
            $modifierBonus = 1.0;
            
            // Check for modifiers in context
            if (in_array($word, $this->strongModifiers)) {
                $modifierBonus = 2.0; // Stronger modifier impact
                continue;
            }
            
            // Calculate word weight based on position and context
            if ($i < 10) $weight *= 1.5; // Title/beginning words more important
            if ($i > count($words) - 10) $weight *= 1.2; // Conclusion words important
            
            // Score positive words with enhanced logic
            if (in_array($word, $this->positiveWords)) {
                // Determine weight based on word strength
                if (in_array($word, ['moon', 'rocket', 'surge', 'skyrocket', 'breakthrough', 'explosion', 'ath'])) {
                    $weight *= 3.0; // Very strong words
                } elseif (in_array($word, ['bullish', 'rally', 'gain', 'growth', 'success', 'adoption'])) {
                    $weight *= 2.0; // Strong words
                }
                
                $positiveScore += ($weight * $modifierBonus);
                $modifierBonus = 1.0;
            }
            // Score negative words with enhanced logic
            elseif (in_array($word, $this->negativeWords)) {
                // Determine weight based on word strength
                if (in_array($word, ['crash', 'collapse', 'plunge', 'bloodbath', 'capitulation'])) {
                    $weight *= 3.0; // Very strong words
                } elseif (in_array($word, ['bearish', 'drop', 'fall', 'decline', 'hack', 'scam'])) {
                    $weight *= 2.0; // Strong words
                }
                
                $negativeScore += ($weight * $modifierBonus);
                $modifierBonus = 1.0;
            }
        }
        
        // Enhanced scoring calculation
        $totalSentiment = $positiveScore + $negativeScore;
        $confidence = min(1.0, max(0.1, ($confidenceBoost + ($totalSentiment / 10))));
        
        if ($totalSentiment == 0) {
            return [
                'sentiment' => 'neutral',
                'score' => 0.0000,
                'confidence' => 0.1,
                'impact_level' => 'low'
            ];
        }
        
        // Calculate normalized score (-1 to 1) with enhanced logic
        $rawScore = ($positiveScore - $negativeScore) / max($totalSentiment, 1);
        $score = max(-1, min(1, $rawScore)); // Clamp between -1 and 1
        
        // Determine sentiment category with more precise thresholds
        $sentiment = 'neutral';
        if ($score > 0.15) {
            $sentiment = 'positive';
        } elseif ($score < -0.15) {
            $sentiment = 'negative';
        }
        
        // Adjust confidence based on sentiment strength
        if (abs($score) > 0.5) {
            $confidence = min(1.0, $confidence + 0.2); // Strong sentiment = higher confidence
        }
        
        return [
            'sentiment' => $sentiment,
            'score' => round($score, 4),
            'confidence' => round($confidence, 4),
            'impact_level' => $this->getImpactLevel(abs($score)),
            'positive_score' => round($positiveScore, 2),
            'negative_score' => round($negativeScore, 2)
        ];
    }
    
    /**
     * Analyze and update news in database
     */
    public function analyzeNewsInDatabase($limit = 100) {
        require_once __DIR__ . '/../config/database.php';
        
        $sql = "SELECT id, title, summary, content FROM news_events 
                WHERE sentiment = 'neutral' OR sentiment IS NULL 
                LIMIT :limit";
        
        $stmt = getDatabaseConnection()->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $articles = $stmt->fetchAll();
        
        $analyzed = 0;
        
        foreach ($articles as $article) {
            $text = $article['title'] . ' ' . $article['summary'] . ' ' . $article['content'];
            $result = $this->analyze($text);
            
            $updateSql = "UPDATE news_events 
                          SET sentiment = :sentiment, 
                              sentiment_score = :score 
                          WHERE id = :id";
            
            executeQuery($updateSql, [
                ':sentiment' => $result['sentiment'],
                ':score' => $result['score'],
                ':id' => $article['id']
            ]);
            
            $analyzed++;
        }
        
        return $analyzed;
    }
    
    /**
     * Get overall market sentiment
     */
    public function getMarketSentiment($hours = 24) {
        require_once __DIR__ . '/../config/database.php';
        
        $sql = "SELECT sentiment, sentiment_score, COUNT(*) as count 
                FROM news_events 
                WHERE date >= DATE_SUB(NOW(), INTERVAL :hours HOUR)
                AND sentiment IS NOT NULL
                GROUP BY sentiment";
        
        $results = fetchAll($sql, [':hours' => $hours]);
        
        $total = 0;
        $weightedScore = 0;
        $breakdown = ['positive' => 0, 'negative' => 0, 'neutral' => 0];
        
        foreach ($results as $row) {
            $count = (int)$row['count'];
            $total += $count;
            $breakdown[$row['sentiment']] = $count;
        }
        
        // Calculate weighted average
        $avgSql = "SELECT AVG(sentiment_score) as avg_score 
                   FROM news_events 
                   WHERE date >= DATE_SUB(NOW(), INTERVAL :hours HOUR)
                   AND sentiment IS NOT NULL";
        
        $avgResult = fetchOne($avgSql, [':hours' => $hours]);
        $avgScore = $avgResult ? (float)$avgResult['avg_score'] : 0;
        
        // Determine overall sentiment
        if ($avgScore > 0.15) {
            $overall = 'positive';
        } elseif ($avgScore < -0.15) {
            $overall = 'negative';
        } else {
            $overall = 'neutral';
        }
        
        return [
            'overall_sentiment' => $overall,
            'average_score' => round($avgScore, 4),
            'total_articles' => $total,
            'breakdown' => $breakdown,
            'positive_percentage' => $total > 0 ? round(($breakdown['positive'] / $total) * 100, 2) : 0,
            'negative_percentage' => $total > 0 ? round(($breakdown['negative'] / $total) * 100, 2) : 0,
            'neutral_percentage' => $total > 0 ? round(($breakdown['neutral'] / $total) * 100, 2) : 0
        ];
    }
    
    /**
     * Get impact level based on sentiment strength
     */
    private function getImpactLevel($score) {
        if ($score > 0.7) return 'very_high';
        if ($score > 0.5) return 'high';
        if ($score > 0.3) return 'medium';
        if ($score > 0.1) return 'low';
        return 'minimal';
    }
    
    /**
     * Get recent critical news (last 24h with high impact)
     */
    public function getCriticalNews($hours = 24) {
        require_once __DIR__ . '/../config/database.php';
        
        $sql = "SELECT title, content, sentiment, sentiment_score, date, source, link
                FROM news_events 
                WHERE date >= DATE_SUB(NOW(), INTERVAL :hours HOUR)
                AND (
                    sentiment_score > 0.5 OR sentiment_score < -0.5 OR
                    title LIKE '%bitcoin%' OR title LIKE '%ethereum%' OR
                    title LIKE '%sec%' OR title LIKE '%etf%' OR title LIKE '%regulation%'
                )
                ORDER BY ABS(sentiment_score) DESC, date DESC
                LIMIT 20";
        
        return fetchAll($sql, [':hours' => $hours]);
    }
    
    /**
     * Tokenize text into words
     */
    private function tokenize($text) {
        // Remove special characters
        $text = preg_replace('/[^a-z0-9\s]/', ' ', $text);
        // Split into words
        $words = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        return $words;
    }
    
    /**
     * Extract keywords from text
     */
    public function extractKeywords($text, $limit = 10) {
        $words = $this->tokenize(strtolower($text));
        
        // Remove common words
        $stopWords = ['the', 'is', 'at', 'which', 'on', 'a', 'an', 'as', 'are', 'was', 'were', 
                      'been', 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 
                      'could', 'should', 'may', 'might', 'can', 'to', 'of', 'in', 'for', 'and', 
                      'or', 'but', 'with', 'from', 'by', 'this', 'that', 'these', 'those'];
        
        $filtered = array_diff($words, $stopWords);
        $frequencies = array_count_values($filtered);
        arsort($frequencies);
        
        return array_slice(array_keys($frequencies), 0, $limit);
    }
}

// CLI Execution
if (php_sapi_name() === 'cli') {
    echo "=== Sentiment Analyzer ===\n\n";
    require_once __DIR__ . '/../config/database.php';
    
    $analyzer = new SentimentAnalyzer();
    $analyzed = $analyzer->analyzeNewsInDatabase(100);
    
    echo "✓ Analyzed {$analyzed} articles\n\n";
    
    $marketSentiment = $analyzer->getMarketSentiment(24);
    echo "Market Sentiment (Last 24h):\n";
    echo "  Overall: " . strtoupper($marketSentiment['overall_sentiment']) . "\n";
    echo "  Score: " . $marketSentiment['average_score'] . "\n";
    echo "  Positive: " . $marketSentiment['positive_percentage'] . "%\n";
    echo "  Negative: " . $marketSentiment['negative_percentage'] . "%\n";
    echo "  Neutral: " . $marketSentiment['neutral_percentage'] . "%\n";
}
?>

