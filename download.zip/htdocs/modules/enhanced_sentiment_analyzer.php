<?php
/**
 * Enhanced Sentiment Analyzer with AI-Powered Analysis
 * 
 * Advanced sentiment analysis with:
 * - Contextual understanding
 * - Emotion detection
 * - Market impact assessment
 * - Multi-language support
 * - Real-time news correlation
 */

require_once __DIR__ . '/../config/database.php';

class EnhancedSentimentAnalyzer {
    
    // Enhanced sentiment lexicon with emotional weights
    private $sentimentLexicon = [
        'extreme_bullish' => [
            'words' => ['moon', 'rocket', 'skyrocket', 'explosion', 'breakthrough', 'ath', 'all-time high', 'massive surge', 'parabolic'],
            'weight' => 5.0,
            'emotion' => 'euphoria'
        ],
        'strong_bullish' => [
            'words' => ['bullish', 'rally', 'surge', 'boom', 'breakout', 'golden cross', 'bull run', 'institutional adoption'],
            'weight' => 3.0,
            'emotion' => 'optimism'
        ],
        'moderate_bullish' => [
            'words' => ['positive', 'growth', 'gain', 'rise', 'increase', 'support', 'accumulation', 'buying pressure'],
            'weight' => 2.0,
            'emotion' => 'confidence'
        ],
        'mild_bullish' => [
            'words' => ['opportunity', 'potential', 'promising', 'hodl', 'diamond hands', 'long-term'],
            'weight' => 1.0,
            'emotion' => 'hope'
        ],
        'extreme_bearish' => [
            'words' => ['crash', 'collapse', 'bloodbath', 'capitulation', 'death cross', 'panic selling', 'market crash'],
            'weight' => -5.0,
            'emotion' => 'panic'
        ],
        'strong_bearish' => [
            'words' => ['bearish', 'dump', 'plunge', 'selloff', 'bear market', 'recession', 'crisis'],
            'weight' => -3.0,
            'emotion' => 'fear'
        ],
        'moderate_bearish' => [
            'words' => ['decline', 'drop', 'fall', 'loss', 'negative', 'weak', 'selling pressure'],
            'weight' => -2.0,
            'emotion' => 'concern'
        ],
        'mild_bearish' => [
            'words' => ['uncertainty', 'volatility', 'correction', 'pullback', 'resistance', 'profit taking'],
            'weight' => -1.0,
            'emotion' => 'caution'
        ]
    ];
    
    // Market impact keywords
    private $marketImpactKeywords = [
        'high_impact' => [
            'bitcoin etf', 'sec approval', 'federal reserve', 'interest rate', 'inflation data',
            'tether audit', 'binance regulation', 'coinbase listing', 'blackrock bitcoin',
            'el salvador adoption', 'china ban', 'us regulation', 'fed meeting'
        ],
        'medium_impact' => [
            'whale movement', 'institutional buying', 'exchange hack', 'defi protocol',
            'nft market', 'stablecoin', 'mining difficulty', 'hash rate'
        ],
        'low_impact' => [
            'technical analysis', 'price prediction', 'trading volume', 'market cap'
        ]
    ];
    
    // Emotional modifiers
    private $emotionalModifiers = [
        'intensifiers' => ['very', 'extremely', 'highly', 'significantly', 'dramatically', 'massive', 'huge'],
        'diminishers' => ['slightly', 'somewhat', 'moderately', 'relatively', 'fairly', 'quite'],
        'negators' => ['not', 'no', 'never', 'nothing', 'none', 'neither']
    ];
    
    /**
     * Advanced sentiment analysis with emotional intelligence
     */
    public function analyzeAdvanced($text, $source = 'news', $timestamp = null) {
        $analysis = [
            'sentiment' => 'neutral',
            'score' => 0.0,
            'confidence' => 0.0,
            'emotion' => 'neutral',
            'market_impact' => 'low',
            'urgency' => 'normal',
            'credibility' => 0.5,
            'keywords_found' => [],
            'context_analysis' => []
        ];
        
        // Preprocess text
        $processedText = $this->preprocessText($text);
        
        // Perform sentiment analysis
        $sentimentResult = $this->calculateSentiment($processedText);
        $analysis = array_merge($analysis, $sentimentResult);
        
        // Analyze market impact
        $analysis['market_impact'] = $this->assessMarketImpact($processedText);
        
        // Determine urgency
        $analysis['urgency'] = $this->assessUrgency($processedText, $timestamp);
        
        // Assess credibility
        $analysis['credibility'] = $this->assessCredibility($text, $source);
        
        // Contextual analysis
        $analysis['context_analysis'] = $this->performContextualAnalysis($processedText);
        
        // Adjust confidence based on multiple factors
        $analysis['confidence'] = $this->calculateFinalConfidence($analysis);
        
        return $analysis;
    }
    
    /**
     * Calculate sentiment with enhanced algorithm
     */
    private function calculateSentiment($text) {
        $totalScore = 0;
        $wordCount = 0;
        $emotionScores = [];
        $keywordsFound = [];
        
        $words = explode(' ', $text);
        
        for ($i = 0; $i < count($words); $i++) {
            $word = $words[$i];
            $contextMultiplier = 1.0;
            
            // Check for negation in context
            if ($i > 0 && in_array($words[$i-1], $this->emotionalModifiers['negators'])) {
                $contextMultiplier = -0.8; // Reverse sentiment but not completely
            }
            
            // Check for intensifiers
            if ($i > 0 && in_array($words[$i-1], $this->emotionalModifiers['intensifiers'])) {
                $contextMultiplier = 1.5;
            }
            
            // Check for diminishers
            if ($i > 0 && in_array($words[$i-1], $this->emotionalModifiers['diminishers'])) {
                $contextMultiplier = 0.7;
            }
            
            // Find sentiment matches
            foreach ($this->sentimentLexicon as $category => $data) {
                foreach ($data['words'] as $sentimentWord) {
                    if (strpos($text, $sentimentWord) !== false) {
                        $score = $data['weight'] * $contextMultiplier;
                        $totalScore += $score;
                        $wordCount++;
                        
                        $keywordsFound[] = [
                            'word' => $sentimentWord,
                            'category' => $category,
                            'score' => $score,
                            'emotion' => $data['emotion']
                        ];
                        
                        // Track emotions
                        $emotion = $data['emotion'];
                        if (!isset($emotionScores[$emotion])) {
                            $emotionScores[$emotion] = 0;
                        }
                        $emotionScores[$emotion] += abs($score);
                    }
                }
            }
        }
        
        // Calculate final sentiment
        $normalizedScore = $wordCount > 0 ? $totalScore / $wordCount : 0;
        $normalizedScore = max(-1, min(1, $normalizedScore / 3)); // Normalize to -1 to 1
        
        // Determine sentiment category
        $sentiment = 'neutral';
        if ($normalizedScore > 0.3) {
            $sentiment = 'positive';
        } elseif ($normalizedScore < -0.3) {
            $sentiment = 'negative';
        }
        
        // Determine dominant emotion
        $dominantEmotion = 'neutral';
        if (!empty($emotionScores)) {
            $dominantEmotion = array_keys($emotionScores, max($emotionScores))[0];
        }
        
        return [
            'sentiment' => $sentiment,
            'score' => $normalizedScore,
            'emotion' => $dominantEmotion,
            'keywords_found' => $keywordsFound,
            'emotion_scores' => $emotionScores
        ];
    }
    
    /**
     * Assess market impact of the news
     */
    private function assessMarketImpact($text) {
        foreach ($this->marketImpactKeywords as $impact => $keywords) {
            foreach ($keywords as $keyword) {
                if (strpos($text, $keyword) !== false) {
                    return str_replace('_', ' ', $impact);
                }
            }
        }
        return 'low';
    }
    
    /**
     * Assess urgency based on content and timing
     */
    private function assessUrgency($text, $timestamp) {
        $urgencyKeywords = [
            'breaking', 'urgent', 'alert', 'immediate', 'emergency', 'critical',
            'just in', 'developing', 'live', 'now', 'today', 'this hour'
        ];
        
        foreach ($urgencyKeywords as $keyword) {
            if (strpos($text, $keyword) !== false) {
                return 'high';
            }
        }
        
        // Check recency
        if ($timestamp) {
            $hoursAgo = (time() - strtotime($timestamp)) / 3600;
            if ($hoursAgo < 1) {
                return 'high';
            } elseif ($hoursAgo < 6) {
                return 'medium';
            }
        }
        
        return 'normal';
    }
    
    /**
     * Assess credibility of the source and content
     */
    private function assessCredibility($text, $source) {
        $credibilityScore = 0.5; // Base score
        
        // Source credibility
        $trustedSources = [
            'coindesk', 'cointelegraph', 'bloomberg', 'reuters', 'coinbase', 'binance'
        ];
        
        foreach ($trustedSources as $trustedSource) {
            if (strpos(strtolower($source), $trustedSource) !== false) {
                $credibilityScore += 0.3;
                break;
            }
        }
        
        // Content quality indicators
        $qualityIndicators = [
            'according to', 'sources say', 'reported by', 'confirmed by', 'official statement'
        ];
        
        foreach ($qualityIndicators as $indicator) {
            if (strpos(strtolower($text), $indicator) !== false) {
                $credibilityScore += 0.1;
            }
        }
        
        // Red flags
        $redFlags = [
            'rumor', 'unconfirmed', 'speculation', 'allegedly', 'might', 'could be'
        ];
        
        foreach ($redFlags as $flag) {
            if (strpos(strtolower($text), $flag) !== false) {
                $credibilityScore -= 0.2;
            }
        }
        
        return max(0, min(1, $credibilityScore));
    }
    
    /**
     * Perform contextual analysis
     */
    private function performContextualAnalysis($text) {
        $context = [
            'has_price_mention' => false,
            'has_technical_analysis' => false,
            'has_fundamental_news' => false,
            'has_regulatory_content' => false,
            'has_adoption_news' => false
        ];
        
        // Price mentions
        if (preg_match('/\$[\d,]+|\d+%|price|target|support|resistance/', $text)) {
            $context['has_price_mention'] = true;
        }
        
        // Technical analysis
        $technicalTerms = ['rsi', 'macd', 'fibonacci', 'support', 'resistance', 'breakout', 'pattern'];
        foreach ($technicalTerms as $term) {
            if (strpos($text, $term) !== false) {
                $context['has_technical_analysis'] = true;
                break;
            }
        }
        
        // Fundamental news
        $fundamentalTerms = ['partnership', 'development', 'upgrade', 'launch', 'integration'];
        foreach ($fundamentalTerms as $term) {
            if (strpos($text, $term) !== false) {
                $context['has_fundamental_news'] = true;
                break;
            }
        }
        
        // Regulatory content
        $regulatoryTerms = ['regulation', 'sec', 'government', 'law', 'compliance', 'legal'];
        foreach ($regulatoryTerms as $term) {
            if (strpos($text, $term) !== false) {
                $context['has_regulatory_content'] = true;
                break;
            }
        }
        
        // Adoption news
        $adoptionTerms = ['adoption', 'institutional', 'corporate', 'mainstream', 'acceptance'];
        foreach ($adoptionTerms as $term) {
            if (strpos($text, $term) !== false) {
                $context['has_adoption_news'] = true;
                break;
            }
        }
        
        return $context;
    }
    
    /**
     * Calculate final confidence score
     */
    private function calculateFinalConfidence($analysis) {
        $baseConfidence = 0.5;
        
        // Boost confidence for clear sentiment
        if (abs($analysis['score']) > 0.5) {
            $baseConfidence += 0.2;
        }
        
        // Boost for high credibility
        $baseConfidence += ($analysis['credibility'] - 0.5) * 0.4;
        
        // Boost for high market impact
        switch ($analysis['market_impact']) {
            case 'high impact':
                $baseConfidence += 0.2;
                break;
            case 'medium impact':
                $baseConfidence += 0.1;
                break;
        }
        
        // Boost for multiple keywords
        if (count($analysis['keywords_found']) > 3) {
            $baseConfidence += 0.1;
        }
        
        return max(0.1, min(0.95, $baseConfidence));
    }
    
    /**
     * Preprocess text for analysis
     */
    private function preprocessText($text) {
        // Convert to lowercase
        $text = strtolower($text);
        
        // Remove special characters but keep spaces
        $text = preg_replace('/[^\w\s]/', ' ', $text);
        
        // Remove extra spaces
        $text = preg_replace('/\s+/', ' ', $text);
        
        // Trim
        $text = trim($text);
        
        return $text;
    }
    
    /**
     * Analyze sentiment for multiple news articles
     */
    public function analyzeBatch($articles) {
        $results = [];
        $overallSentiment = [
            'positive' => 0,
            'negative' => 0,
            'neutral' => 0
        ];
        
        foreach ($articles as $article) {
            $analysis = $this->analyzeAdvanced(
                $article['title'] . ' ' . $article['summary'],
                $article['source'] ?? 'unknown',
                $article['timestamp'] ?? null
            );
            
            $results[] = $analysis;
            $overallSentiment[$analysis['sentiment']]++;
        }
        
        // Calculate market sentiment summary
        $totalArticles = count($articles);
        $sentimentSummary = [
            'positive_percentage' => ($overallSentiment['positive'] / $totalArticles) * 100,
            'negative_percentage' => ($overallSentiment['negative'] / $totalArticles) * 100,
            'neutral_percentage' => ($overallSentiment['neutral'] / $totalArticles) * 100,
            'overall_sentiment' => $this->determineOverallSentiment($overallSentiment),
            'confidence' => $this->calculateBatchConfidence($results)
        ];
        
        return [
            'individual_analysis' => $results,
            'summary' => $sentimentSummary,
            'total_articles' => $totalArticles,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Determine overall market sentiment
     */
    private function determineOverallSentiment($sentimentCounts) {
        $max = max($sentimentCounts);
        return array_search($max, $sentimentCounts);
    }
    
    /**
     * Calculate confidence for batch analysis
     */
    private function calculateBatchConfidence($results) {
        if (empty($results)) return 0;
        
        $totalConfidence = array_sum(array_column($results, 'confidence'));
        return $totalConfidence / count($results);
    }
    
    /**
     * Get real-time market sentiment
     */
    public function getRealTimeMarketSentiment($hours = 24) {
        // Get recent news from database
        $sql = "SELECT title, summary, source, date as timestamp 
                FROM news 
                WHERE date >= DATE_SUB(NOW(), INTERVAL ? HOUR) 
                ORDER BY date DESC 
                LIMIT 100";
        
        $articles = fetchAll($sql, [$hours]);
        
        if (empty($articles)) {
            return [
                'sentiment' => 'neutral',
                'confidence' => 0.3,
                'articles_analyzed' => 0
            ];
        }
        
        return $this->analyzeBatch($articles);
    }
}

