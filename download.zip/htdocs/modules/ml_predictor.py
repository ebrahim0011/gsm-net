#!/usr/bin/env python3
"""
Machine Learning Predictor for Crypto Market Analysis
Uses LSTM and Random Forest for advanced pattern recognition

Requirements:
pip install numpy pandas scikit-learn tensorflow mysql-connector-python

Usage:
python ml_predictor.py --symbol BTC --action train
python ml_predictor.py --symbol BTC --action predict
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

try:
    import numpy as np
    import pandas as pd
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    import mysql.connector
except ImportError as e:
    print(f"Error: Missing required library: {e}")
    print("Please install required packages:")
    print("pip install numpy pandas scikit-learn tensorflow mysql-connector-python")
    sys.exit(1)

# Database configuration (update with your credentials)
DB_CONFIG = {
    'host': 'sql308.infinityfree.com',
    'user': 'if0_40053752',
    'password': 'YU58LXxgEZU2',
    'database': 'if0_40053752_crypto_ai_analyzer'
}

class CryptoMLPredictor:
    def __init__(self, symbol='BTC'):
        self.symbol = symbol
        self.scaler = StandardScaler()
        self.rf_model = None
        
    def connect_db(self):
        """Connect to MySQL database"""
        try:
            conn = mysql.connector.connect(**DB_CONFIG)
            return conn
        except mysql.connector.Error as e:
            print(f"Database connection error: {e}")
            return None
    
    def fetch_training_data(self, days=90):
        """Fetch historical data for training"""
        conn = self.connect_db()
        if not conn:
            return None
        
        cursor = conn.cursor(dictionary=True)
        
        # Fetch historical patterns
        query = """
        SELECT 
            hp.pattern_date,
            hp.price_before,
            hp.rsi_before,
            hp.macd_before,
            hp.volatility_before,
            hp.sentiment_score_before,
            hp.price_change_24h,
            hp.market_direction,
            hp.event_type
        FROM historical_patterns hp
        WHERE hp.symbol = %s
        AND hp.pattern_date >= DATE_SUB(NOW(), INTERVAL %s DAY)
        ORDER BY hp.pattern_date
        """
        
        cursor.execute(query, (self.symbol, days))
        data = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        if not data:
            print(f"No training data found for {self.symbol}")
            return None
        
        df = pd.DataFrame(data)
        return df
    
    def prepare_features(self, df):
        """Prepare features for ML model"""
        # Convert sentiment to numeric
        df['sentiment_numeric'] = df['sentiment_score_before'].fillna(0)
        
        # Create feature matrix
        features = []
        labels = []
        
        for idx, row in df.iterrows():
            feature_vector = [
                row['rsi_before'] or 50,
                row['macd_before'] or 0,
                row['volatility_before'] or 0.01,
                row['sentiment_numeric'],
            ]
            
            # Add event type encoding (simple binary features)
            event_types = ['Interest Rate Change', 'Regulatory News', 'ETF Approval', 
                          'Major Hack/Security', 'Adoption News', 'Technical Upgrade']
            for et in event_types:
                feature_vector.append(1 if row['event_type'] == et else 0)
            
            features.append(feature_vector)
            
            # Label: 0=bearish, 1=sideways, 2=bullish
            if row['market_direction'] == 'bullish':
                labels.append(2)
            elif row['market_direction'] == 'bearish':
                labels.append(0)
            else:
                labels.append(1)
        
        return np.array(features), np.array(labels)
    
    def train_model(self, days=90):
        """Train Random Forest model"""
        print(f"Training ML model for {self.symbol}...")
        
        # Fetch data
        df = self.fetch_training_data(days)
        if df is None or len(df) < 10:
            print("Insufficient training data")
            return False
        
        print(f"Loaded {len(df)} historical patterns")
        
        # Prepare features
        X, y = self.prepare_features(df)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train Random Forest
        print("Training Random Forest classifier...")
        self.rf_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        self.rf_model.fit(X_train_scaled, y_train)
        
        # Evaluate
        train_accuracy = self.rf_model.score(X_train_scaled, y_train)
        test_accuracy = self.rf_model.score(X_test_scaled, y_test)
        
        print(f"✅ Training completed!")
        print(f"   Train Accuracy: {train_accuracy * 100:.2f}%")
        print(f"   Test Accuracy: {test_accuracy * 100:.2f}%")
        
        # Feature importance
        feature_names = ['RSI', 'MACD', 'Volatility', 'Sentiment', 
                        'Interest Rate', 'Regulatory', 'ETF', 'Hack', 'Adoption', 'Upgrade']
        importance = self.rf_model.feature_importances_
        
        print("\nFeature Importance:")
        for name, imp in sorted(zip(feature_names, importance), key=lambda x: x[1], reverse=True)[:5]:
            print(f"   {name}: {imp * 100:.2f}%")
        
        return True
    
    def predict(self, features_dict):
        """Make prediction for current market conditions"""
        if self.rf_model is None:
            print("Model not trained. Please train first.")
            return None
        
        # Prepare feature vector
        feature_vector = [
            features_dict.get('rsi', 50),
            features_dict.get('macd', 0),
            features_dict.get('volatility', 0.01),
            features_dict.get('sentiment_score', 0),
        ]
        
        # Add event type encoding
        event_types = ['Interest Rate Change', 'Regulatory News', 'ETF Approval', 
                      'Major Hack/Security', 'Adoption News', 'Technical Upgrade']
        current_event = features_dict.get('event_type', '')
        for et in event_types:
            feature_vector.append(1 if current_event == et else 0)
        
        # Scale and predict
        X = np.array([feature_vector])
        X_scaled = self.scaler.transform(X)
        
        prediction = self.rf_model.predict(X_scaled)[0]
        probabilities = self.rf_model.predict_proba(X_scaled)[0]
        
        # Convert prediction to direction
        directions = ['bearish', 'sideways', 'bullish']
        predicted_direction = directions[prediction]
        confidence = probabilities[prediction]
        
        return {
            'predicted_direction': predicted_direction,
            'confidence': float(confidence),
            'probabilities': {
                'bearish': float(probabilities[0]),
                'sideways': float(probabilities[1]),
                'bullish': float(probabilities[2])
            }
        }
    
    def predict_from_db(self):
        """Predict based on current database state"""
        conn = self.connect_db()
        if not conn:
            return None
        
        cursor = conn.cursor(dictionary=True)
        
        # Get latest technical indicators
        cursor.execute("""
            SELECT rsi, macd, volatility
            FROM technical_indicators
            WHERE symbol = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """, (self.symbol,))
        indicators = cursor.fetchone()
        
        # Get latest sentiment
        cursor.execute("""
            SELECT AVG(sentiment_score) as avg_sentiment
            FROM news_events
            WHERE date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        """)
        sentiment = cursor.fetchone()
        
        # Get latest news event type
        cursor.execute("""
            SELECT title, summary
            FROM news_events
            ORDER BY date DESC
            LIMIT 1
        """)
        news = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not indicators:
            print("No technical indicators available")
            return None
        
        # Simple event categorization
        event_type = 'Other'
        if news:
            text = (news['title'] + ' ' + news['summary']).lower()
            if 'etf' in text or 'approval' in text:
                event_type = 'ETF Approval'
            elif 'regulation' in text or 'sec' in text:
                event_type = 'Regulatory News'
            elif 'hack' in text or 'breach' in text:
                event_type = 'Major Hack/Security'
            elif 'rate' in text or 'fed' in text:
                event_type = 'Interest Rate Change'
        
        features = {
            'rsi': indicators['rsi'],
            'macd': indicators['macd'],
            'volatility': indicators['volatility'],
            'sentiment_score': sentiment['avg_sentiment'] if sentiment else 0,
            'event_type': event_type
        }
        
        prediction = self.predict(features)
        
        if prediction:
            print(f"\n🤖 ML Prediction for {self.symbol}:")
            print(f"   Direction: {prediction['predicted_direction'].upper()}")
            print(f"   Confidence: {prediction['confidence'] * 100:.1f}%")
            print(f"   Probabilities:")
            for dir, prob in prediction['probabilities'].items():
                print(f"      {dir}: {prob * 100:.1f}%")
        
        return prediction


def main():
    parser = argparse.ArgumentParser(description='Crypto ML Predictor')
    parser.add_argument('--symbol', default='BTC', help='Crypto symbol (default: BTC)')
    parser.add_argument('--action', choices=['train', 'predict', 'both'], default='both',
                       help='Action to perform')
    parser.add_argument('--days', type=int, default=90, help='Days of historical data for training')
    
    args = parser.parse_args()
    
    predictor = CryptoMLPredictor(symbol=args.symbol)
    
    if args.action in ['train', 'both']:
        success = predictor.train_model(days=args.days)
        if not success:
            print("Training failed")
            return
    
    if args.action in ['predict', 'both']:
        if args.action == 'predict':
            # Need to train first if only predicting
            print("Training model first...")
            predictor.train_model(days=args.days)
        
        prediction = predictor.predict_from_db()
        
        if prediction:
            # Output as JSON for PHP integration
            print("\n" + "="*50)
            print("JSON Output:")
            print(json.dumps(prediction, indent=2))

if __name__ == '__main__':
    main()

