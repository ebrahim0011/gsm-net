<?php
/**
 * Order Book Analyzer
 * تحليل دفتر الأوامر (Order Book) للكشف عن قوة العرض والطلب
 * 
 * Features:
 * - Bid/Ask spread analysis
 * - Order book depth analysis
 * - Whale walls detection
 * - Liquidity zones identification
 * - Support/Resistance from order book
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/cache.php';

class OrderBookAnalyzer {
    
    private $cache;
    private $cacheTime = 60; // 1 minute cache
    
    public function __construct() {
        $this->cache = $GLOBALS['cache'];
    }
    
    /**
     * Get comprehensive order book analysis
     */
    public function getComprehensiveAnalysis($symbol = 'BTC') {
        return $this->cache->getCachedAnalysis(
            $symbol,
            'orderbook',
            function() use ($symbol) {
                return $this->performAnalysis($symbol);
            },
            $this->cacheTime
        );
    }
    
    /**
     * Perform order book analysis
     */
    private function performAnalysis($symbol) {
        $orderBook = $this->fetchOrderBook($symbol);
        
        if (!$orderBook) {
            return null;
        }
        
        return [
            'spread' => $this->analyzeSpread($orderBook),
            'depth' => $this->analyzeDepth($orderBook),
            'whale_walls' => $this->detectWhaleWalls($orderBook),
            'liquidity_zones' => $this->identifyLiquidityZones($orderBook),
            'imbalance' => $this->calculateImbalance($orderBook),
            'support_resistance' => $this->extractSupportResistance($orderBook),
            'overall_signal' => null,
            'confidence' => 0,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Fetch order book from Binance API
     */
    private function fetchOrderBook($symbol, $limit = 100) {
        try {
            $url = "https://api.binance.com/api/v3/depth?symbol={$symbol}USDT&limit={$limit}";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode !== 200 || !$response) {
                return null;
            }
            
            $data = json_decode($response, true);
            
            if (!isset($data['bids']) || !isset($data['asks'])) {
                return null;
            }
            
            return [
                'bids' => $data['bids'], // [price, quantity]
                'asks' => $data['asks'],
                'timestamp' => $data['lastUpdateId'] ?? time()
            ];
            
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Analyze bid-ask spread
     */
    private function analyzeSpread($orderBook) {
        if (empty($orderBook['bids']) || empty($orderBook['asks'])) {
            return null;
        }
        
        $bestBid = (float)$orderBook['bids'][0][0];
        $bestAsk = (float)$orderBook['asks'][0][0];
        
        $spread = $bestAsk - $bestBid;
        $spreadPct = ($spread / $bestBid) * 100;
        
        // Spread analysis
        $spreadSignal = 'normal';
        if ($spreadPct < 0.01) {
            $spreadSignal = 'tight'; // Very liquid
        } elseif ($spreadPct > 0.1) {
            $spreadSignal = 'wide'; // Low liquidity
        }
        
        return [
            'best_bid' => $bestBid,
            'best_ask' => $bestAsk,
            'spread' => $spread,
            'spread_pct' => round($spreadPct, 4),
            'signal' => $spreadSignal,
            'liquidity' => $spreadSignal === 'tight' ? 'high' : ($spreadSignal === 'wide' ? 'low' : 'medium')
        ];
    }
    
    /**
     * Analyze order book depth
     */
    private function analyzeDepth($orderBook) {
        $bids = $orderBook['bids'];
        $asks = $orderBook['asks'];
        
        // Calculate total volume within 1% from best price
        $bestBid = (float)$bids[0][0];
        $bestAsk = (float)$asks[0][0];
        
        $bidVolume1pct = 0;
        $askVolume1pct = 0;
        
        foreach ($bids as $order) {
            $price = (float)$order[0];
            $volume = (float)$order[1];
            
            if ($price >= $bestBid * 0.99) {
                $bidVolume1pct += $volume;
            }
        }
        
        foreach ($asks as $order) {
            $price = (float)$order[0];
            $volume = (float)$order[1];
            
            if ($price <= $bestAsk * 1.01) {
                $askVolume1pct += $volume;
            }
        }
        
        $totalVolume = $bidVolume1pct + $askVolume1pct;
        $bidRatio = $totalVolume > 0 ? ($bidVolume1pct / $totalVolume) * 100 : 50;
        
        return [
            'bid_volume_1pct' => round($bidVolume1pct, 4),
            'ask_volume_1pct' => round($askVolume1pct, 4),
            'total_volume_1pct' => round($totalVolume, 4),
            'bid_ratio' => round($bidRatio, 2),
            'ask_ratio' => round(100 - $bidRatio, 2),
            'depth_signal' => $bidRatio > 55 ? 'bullish' : ($bidRatio < 45 ? 'bearish' : 'neutral')
        ];
    }
    
    /**
     * Detect whale walls (large orders)
     */
    private function detectWhaleWalls($orderBook) {
        $bids = $orderBook['bids'];
        $asks = $orderBook['asks'];
        
        // Calculate average order size
        $bidVolumes = array_column($bids, 1);
        $askVolumes = array_column($asks, 1);
        
        $avgBidVolume = array_sum($bidVolumes) / count($bidVolumes);
        $avgAskVolume = array_sum($askVolumes) / count($askVolumes);
        
        // Detect whale walls (orders > 3x average)
        $whaleThreshold = 3;
        $whaleWalls = [
            'buy_walls' => [],
            'sell_walls' => []
        ];
        
        foreach ($bids as $order) {
            $price = (float)$order[0];
            $volume = (float)$order[1];
            
            if ($volume > $avgBidVolume * $whaleThreshold) {
                $whaleWalls['buy_walls'][] = [
                    'price' => $price,
                    'volume' => $volume,
                    'multiplier' => round($volume / $avgBidVolume, 2)
                ];
            }
        }
        
        foreach ($asks as $order) {
            $price = (float)$order[0];
            $volume = (float)$order[1];
            
            if ($volume > $avgAskVolume * $whaleThreshold) {
                $whaleWalls['sell_walls'][] = [
                    'price' => $price,
                    'volume' => $volume,
                    'multiplier' => round($volume / $avgAskVolume, 2)
                ];
            }
        }
        
        return [
            'buy_walls_count' => count($whaleWalls['buy_walls']),
            'sell_walls_count' => count($whaleWalls['sell_walls']),
            'buy_walls' => array_slice($whaleWalls['buy_walls'], 0, 5), // Top 5
            'sell_walls' => array_slice($whaleWalls['sell_walls'], 0, 5),
            'signal' => count($whaleWalls['buy_walls']) > count($whaleWalls['sell_walls']) ? 'bullish' : 
                       (count($whaleWalls['sell_walls']) > count($whaleWalls['buy_walls']) ? 'bearish' : 'neutral')
        ];
    }
    
    /**
     * Identify liquidity zones
     */
    private function identifyLiquidityZones($orderBook) {
        $bids = $orderBook['bids'];
        $asks = $orderBook['asks'];
        
        // Group orders by price ranges (0.5% buckets)
        $bidZones = $this->groupIntoZones($bids, 'bid');
        $askZones = $this->groupIntoZones($asks, 'ask');
        
        // Find highest liquidity zones
        usort($bidZones, function($a, $b) {
            return $b['volume'] <=> $a['volume'];
        });
        
        usort($askZones, function($a, $b) {
            return $b['volume'] <=> $a['volume'];
        });
        
        return [
            'strongest_bid_zones' => array_slice($bidZones, 0, 3),
            'strongest_ask_zones' => array_slice($askZones, 0, 3)
        ];
    }
    
    /**
     * Group orders into price zones
     */
    private function groupIntoZones($orders, $type = 'bid') {
        if (empty($orders)) return [];
        
        $basePrice = (float)$orders[0][0];
        $zones = [];
        $zoneSize = 0.005; // 0.5%
        
        foreach ($orders as $order) {
            $price = (float)$order[0];
            $volume = (float)$order[1];
            
            // Calculate zone index
            $deviation = abs($price - $basePrice) / $basePrice;
            $zoneIndex = (int)($deviation / $zoneSize);
            
            if (!isset($zones[$zoneIndex])) {
                $zones[$zoneIndex] = [
                    'price_range' => [
                        'min' => $price,
                        'max' => $price
                    ],
                    'volume' => 0,
                    'order_count' => 0
                ];
            }
            
            $zones[$zoneIndex]['volume'] += $volume;
            $zones[$zoneIndex]['order_count']++;
            $zones[$zoneIndex]['price_range']['min'] = min($zones[$zoneIndex]['price_range']['min'], $price);
            $zones[$zoneIndex]['price_range']['max'] = max($zones[$zoneIndex]['price_range']['max'], $price);
        }
        
        return array_values($zones);
    }
    
    /**
     * Calculate bid/ask imbalance
     */
    private function calculateImbalance($orderBook) {
        $bids = $orderBook['bids'];
        $asks = $orderBook['asks'];
        
        $totalBidVolume = 0;
        $totalAskVolume = 0;
        
        foreach ($bids as $order) {
            $totalBidVolume += (float)$order[1];
        }
        
        foreach ($asks as $order) {
            $totalAskVolume += (float)$order[1];
        }
        
        $totalVolume = $totalBidVolume + $totalAskVolume;
        $imbalance = $totalVolume > 0 ? (($totalBidVolume - $totalAskVolume) / $totalVolume) * 100 : 0;
        
        return [
            'total_bid_volume' => round($totalBidVolume, 4),
            'total_ask_volume' => round($totalAskVolume, 4),
            'imbalance_pct' => round($imbalance, 2),
            'signal' => $imbalance > 10 ? 'strong_bullish' : 
                       ($imbalance > 3 ? 'bullish' : 
                       ($imbalance < -10 ? 'strong_bearish' : 
                       ($imbalance < -3 ? 'bearish' : 'neutral'))),
            'pressure' => $imbalance > 0 ? 'buying' : 'selling'
        ];
    }
    
    /**
     * Extract support/resistance from order book
     */
    private function extractSupportResistance($orderBook) {
        $bids = $orderBook['bids'];
        $asks = $orderBook['asks'];
        
        // Find strongest support (largest bid orders)
        usort($bids, function($a, $b) {
            return (float)$b[1] <=> (float)$a[1];
        });
        
        // Find strongest resistance (largest ask orders)
        usort($asks, function($a, $b) {
            return (float)$b[1] <=> (float)$a[1];
        });
        
        $supports = array_slice($bids, 0, 3);
        $resistances = array_slice($asks, 0, 3);
        
        return [
            'key_support_levels' => array_map(function($order) {
                return [
                    'price' => (float)$order[0],
                    'volume' => (float)$order[1]
                ];
            }, $supports),
            'key_resistance_levels' => array_map(function($order) {
                return [
                    'price' => (float)$order[0],
                    'volume' => (float)$order[1]
                ];
            }, $resistances)
        ];
    }
    
    /**
     * Get overall order book signal
     */
    public function getOverallSignal($symbol) {
        $analysis = $this->getComprehensiveAnalysis($symbol);
        
        if (!$analysis) {
            return ['signal' => 'unknown', 'confidence' => 0];
        }
        
        $score = 0;
        $maxScore = 0;
        
        // Depth signal (30 points)
        if (isset($analysis['depth']['depth_signal'])) {
            $maxScore += 30;
            if ($analysis['depth']['depth_signal'] === 'bullish') {
                $score += 30;
            } elseif ($analysis['depth']['depth_signal'] === 'bearish') {
                $score -= 30;
            }
        }
        
        // Whale walls (25 points)
        if (isset($analysis['whale_walls']['signal'])) {
            $maxScore += 25;
            if ($analysis['whale_walls']['signal'] === 'bullish') {
                $score += 25;
            } elseif ($analysis['whale_walls']['signal'] === 'bearish') {
                $score -= 25;
            }
        }
        
        // Imbalance (45 points)
        if (isset($analysis['imbalance']['signal'])) {
            $maxScore += 45;
            if ($analysis['imbalance']['signal'] === 'strong_bullish') {
                $score += 45;
            } elseif ($analysis['imbalance']['signal'] === 'bullish') {
                $score += 22;
            } elseif ($analysis['imbalance']['signal'] === 'strong_bearish') {
                $score -= 45;
            } elseif ($analysis['imbalance']['signal'] === 'bearish') {
                $score -= 22;
            }
        }
        
        // Calculate final signal
        if ($score > 30) {
            $signal = 'bullish';
        } elseif ($score < -30) {
            $signal = 'bearish';
        } else {
            $signal = 'neutral';
        }
        
        $confidence = $maxScore > 0 ? abs($score) / $maxScore : 0;
        
        return [
            'signal' => $signal,
            'confidence' => round($confidence, 4),
            'score' => $score,
            'max_score' => $maxScore
        ];
    }
}
?>

