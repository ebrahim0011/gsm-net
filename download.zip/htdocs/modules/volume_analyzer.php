<?php
/**
 * Volume Analyzer Module
 * تحليل حجم التداول المتقدم
 * 
 * Calculates:
 * - VWAP (Volume Weighted Average Price)
 * - OBV (On-Balance Volume)
 * - Volume Momentum
 * - Anomalous Volume Detection
 * - Buy/Sell Pressure
 */

require_once __DIR__ . '/../config/database.php';

class VolumeAnalyzer {
    
    /**
     * Calculate VWAP (Volume Weighted Average Price)
     */
    public function calculateVWAP($symbol, $hours = 24) {
        $sql = "SELECT close, volume, timestamp 
                FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY timestamp ASC";
        
        $data = fetchAll($sql, [$symbol, $hours]);
        
        if (empty($data)) return null;
        
        $totalPV = 0;
        $totalVolume = 0;
        
        foreach ($data as $candle) {
            $pv = $candle['close'] * $candle['volume'];
            $totalPV += $pv;
            $totalVolume += $candle['volume'];
        }
        
        $vwap = $totalVolume > 0 ? $totalPV / $totalVolume : 0;
        $currentPrice = end($data)['close'];
        
        return [
            'vwap' => $vwap,
            'current_price' => $currentPrice,
            'position' => $currentPrice > $vwap ? 'above' : 'below',
            'deviation_pct' => (($currentPrice - $vwap) / $vwap) * 100
        ];
    }
    
    /**
     * Calculate OBV (On-Balance Volume)
     */
    public function calculateOBV($symbol, $days = 7) {
        $sql = "SELECT close, volume, timestamp 
                FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? DAY)
                ORDER BY timestamp ASC";
        
        $data = fetchAll($sql, [$symbol, $days]);
        
        if (count($data) < 2) return null;
        
        $obv = 0;
        $obvValues = [0];
        
        for ($i = 1; $i < count($data); $i++) {
            if ($data[$i]['close'] > $data[$i-1]['close']) {
                $obv += $data[$i]['volume'];
            } elseif ($data[$i]['close'] < $data[$i-1]['close']) {
                $obv -= $data[$i]['volume'];
            }
            $obvValues[] = $obv;
        }
        
        // Calculate OBV trend (positive = accumulation, negative = distribution)
        $firstHalf = array_slice($obvValues, 0, (int)(count($obvValues) / 2));
        $secondHalf = array_slice($obvValues, (int)(count($obvValues) / 2));
        
        $avgFirst = array_sum($firstHalf) / count($firstHalf);
        $avgSecond = array_sum($secondHalf) / count($secondHalf);
        
        $trend = $avgSecond > $avgFirst ? 'accumulation' : 'distribution';
        $trendStrength = abs($avgSecond - $avgFirst) / (abs($avgFirst) + 1);
        
        return [
            'obv' => $obv,
            'trend' => $trend,
            'strength' => min(1.0, $trendStrength),
            'signal' => $trend === 'accumulation' ? 'bullish' : 'bearish'
        ];
    }
    
    /**
     * Calculate Volume Momentum
     */
    public function calculateVolumeMomentum($symbol, $hours = 24) {
        $sql = "SELECT volume, timestamp 
                FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY timestamp DESC";
        
        $data = fetchAll($sql, [$symbol, $hours]);
        
        if (count($data) < 2) return null;
        
        $recentVolumes = array_slice($data, 0, (int)($hours / 4)); // Last quarter
        $olderVolumes = array_slice($data, (int)($hours / 4)); // First 3 quarters
        
        $avgRecent = array_sum(array_column($recentVolumes, 'volume')) / count($recentVolumes);
        $avgOlder = array_sum(array_column($olderVolumes, 'volume')) / count($olderVolumes);
        
        $momentum = (($avgRecent - $avgOlder) / $avgOlder) * 100;
        
        return [
            'momentum_pct' => $momentum,
            'signal' => $momentum > 20 ? 'strong_increase' : ($momentum > 5 ? 'increase' : ($momentum < -20 ? 'strong_decrease' : ($momentum < -5 ? 'decrease' : 'stable')))
        ];
    }
    
    /**
     * Detect Anomalous Volume (Whale Activity)
     */
    public function detectAnomalousVolume($symbol, $days = 7) {
        $sql = "SELECT volume, close, timestamp 
                FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? DAY)
                ORDER BY timestamp DESC";
        
        $data = fetchAll($sql, [$symbol, $days]);
        
        if (count($data) < 10) return null;
        
        $volumes = array_column($data, 'volume');
        $avgVolume = array_sum($volumes) / count($volumes);
        $stdDev = $this->standardDeviation($volumes);
        
        $latestVolume = $volumes[0];
        $zScore = $stdDev > 0 ? ($latestVolume - $avgVolume) / $stdDev : 0;
        
        $isAnomalous = abs($zScore) > 2; // 2 standard deviations
        $type = $zScore > 2 ? 'spike' : ($zScore < -2 ? 'drop' : 'normal');
        
        return [
            'is_anomalous' => $isAnomalous,
            'type' => $type,
            'z_score' => $zScore,
            'current_volume' => $latestVolume,
            'avg_volume' => $avgVolume,
            'multiplier' => $avgVolume > 0 ? $latestVolume / $avgVolume : 1
        ];
    }
    
    /**
     * Calculate Buy/Sell Pressure from Volume
     */
    public function calculateBuySellPressure($symbol, $hours = 24) {
        $sql = "SELECT open, close, high, low, volume 
                FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY timestamp DESC";
        
        $data = fetchAll($sql, [$symbol, $hours]);
        
        if (empty($data)) return null;
        
        $buyVolume = 0;
        $sellVolume = 0;
        
        foreach ($data as $candle) {
            // Simplified: if close > open = buying pressure
            if ($candle['close'] > $candle['open']) {
                $buyVolume += $candle['volume'];
            } else {
                $sellVolume += $candle['volume'];
            }
        }
        
        $totalVolume = $buyVolume + $sellVolume;
        $buyPressure = $totalVolume > 0 ? ($buyVolume / $totalVolume) * 100 : 50;
        $sellPressure = 100 - $buyPressure;
        
        $signal = $buyPressure > 60 ? 'strong_buy' : ($buyPressure > 52 ? 'buy' : ($buyPressure < 40 ? 'strong_sell' : ($buyPressure < 48 ? 'sell' : 'neutral')));
        
        return [
            'buy_pressure' => $buyPressure,
            'sell_pressure' => $sellPressure,
            'signal' => $signal,
            'dominance' => $buyPressure > 50 ? 'buyers' : 'sellers'
        ];
    }
    
    /**
     * Get comprehensive volume analysis
     */
    public function getComprehensiveAnalysis($symbol) {
        $vwap = $this->calculateVWAP($symbol, 24);
        $obv = $this->calculateOBV($symbol, 7);
        $momentum = $this->calculateVolumeMomentum($symbol, 24);
        $anomaly = $this->detectAnomalousVolume($symbol, 7);
        $pressure = $this->calculateBuySellPressure($symbol, 24);
        
        // Calculate overall volume score (-100 to +100)
        $score = 0;
        
        // VWAP contribution (20 points)
        if ($vwap) {
            $score += $vwap['position'] === 'above' ? 10 : -10;
            if (abs($vwap['deviation_pct']) > 2) {
                $score += $vwap['position'] === 'above' ? 10 : -10;
            }
        }
        
        // OBV contribution (30 points)
        if ($obv) {
            $score += $obv['signal'] === 'bullish' ? 15 : -15;
            $score += ($obv['strength'] * 15) * ($obv['signal'] === 'bullish' ? 1 : -1);
        }
        
        // Volume Momentum (20 points)
        if ($momentum) {
            if ($momentum['signal'] === 'strong_increase') $score += 20;
            elseif ($momentum['signal'] === 'increase') $score += 10;
            elseif ($momentum['signal'] === 'strong_decrease') $score -= 20;
            elseif ($momentum['signal'] === 'decrease') $score -= 10;
        }
        
        // Buy/Sell Pressure (30 points)
        if ($pressure) {
            $score += (($pressure['buy_pressure'] - 50) / 50) * 30;
        }
        
        $score = max(-100, min(100, $score));
        
        return [
            'vwap' => $vwap,
            'obv' => $obv,
            'momentum' => $momentum,
            'anomaly' => $anomaly,
            'pressure' => $pressure,
            'overall_score' => $score,
            'signal' => $score > 30 ? 'strong_bullish' : ($score > 10 ? 'bullish' : ($score < -30 ? 'strong_bearish' : ($score < -10 ? 'bearish' : 'neutral')))
        ];
    }
    
    /**
     * Helper: Calculate standard deviation
     */
    private function standardDeviation($arr) {
        $n = count($arr);
        if ($n === 0) return 0;
        
        $mean = array_sum($arr) / $n;
        $variance = 0;
        
        foreach ($arr as $val) {
            $variance += pow($val - $mean, 2);
        }
        
        return sqrt($variance / $n);
    }
}
?>

