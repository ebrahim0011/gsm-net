<?php
/**
 * Pattern Matcher Module
 * 
 * Analyzes current events and matches them with historical patterns
 * to predict market movements based on past behavior
 */

require_once __DIR__ . '/../config/database.php';

class PatternMatcher {
    
    private $minSimilarityThreshold = 0.35; // Minimum similarity to consider a match (balanced for quality and coverage)
    
    /**
     * Store a new historical pattern from completed event
     */
    public function storeHistoricalPattern($newsId, $symbol) {
        // Get the news event
        $news = fetchOne("SELECT * FROM news_events WHERE id = ?", [$newsId]);
        if (!$news) {
            return false;
        }
        
        // Get price data around the event time
        $eventTime = $news['date'];
        $priceQuery = "SELECT * FROM market_prices 
                       WHERE symbol = ? 
                       AND timestamp <= ?
                       ORDER BY timestamp DESC LIMIT 1";
        $priceBefore = fetchOne($priceQuery, [$symbol, $eventTime]);
        
        if (!$priceBefore) {
            return false;
        }
        
        // Get price changes after event
        $priceChanges = $this->calculatePriceChanges($symbol, $eventTime);
        
        // Get technical indicators before event
        $indicatorsQuery = "SELECT * FROM technical_indicators 
                           WHERE symbol = ? 
                           AND timestamp <= ?
                           ORDER BY timestamp DESC LIMIT 1";
        $indicators = fetchOne($indicatorsQuery, [$symbol, $eventTime]);
        
        // Determine market direction
        $marketDirection = $this->determineMarketDirection($priceChanges);
        
        // Extract keywords and event type
        $eventType = $this->categorizeEvent($news['title'] . ' ' . $news['summary']);
        $keywords = $this->extractKeywords($news['title'] . ' ' . $news['summary']);
        
        // Calculate pattern strength
        $patternStrength = $this->calculatePatternStrength($priceChanges, $indicators);
        
        // Insert into historical_patterns
        $sql = "INSERT INTO historical_patterns (
                    pattern_date, symbol, event_type, event_description,
                    news_id, price_before, volume_before,
                    rsi_before, macd_before, volatility_before,
                    sentiment_before, sentiment_score_before,
                    price_change_1h, price_change_4h, price_change_24h, price_change_7d,
                    volume_change_24h, market_direction, volatility_change,
                    pattern_strength, keywords
                ) VALUES (
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    ?, ?, ?,
                    ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    ?, ?
                )";
        
        $params = [
            $eventTime, $symbol, $eventType, $news['summary'],
            $newsId, $priceBefore['close'], $priceBefore['volume'],
            $indicators['rsi'] ?? null, $indicators['macd'] ?? null, $indicators['volatility'] ?? null,
            $news['sentiment'], $news['sentiment_score'],
            $priceChanges['1h'], $priceChanges['4h'], $priceChanges['24h'], $priceChanges['7d'],
            $priceChanges['volume_24h'], $marketDirection, $priceChanges['volatility_change'],
            $patternStrength, json_encode($keywords)
        ];
        
        executeQuery($sql, $params);
        
        return true;
    }
    
    /**
     * Find similar historical patterns for a current event
     */
    public function findSimilarPatterns($newsId, $symbol, $limit = 10) {
        // Get current news
        $currentNews = fetchOne("SELECT * FROM news_events WHERE id = ?", [$newsId]);
        if (!$currentNews) {
            return [];
        }
        
        // Get current market context
        $currentPrice = fetchOne(
            "SELECT * FROM market_prices WHERE symbol = ? ORDER BY timestamp DESC LIMIT 1",
            [$symbol]
        );
        
        $currentIndicators = fetchOne(
            "SELECT * FROM technical_indicators WHERE symbol = ? ORDER BY timestamp DESC LIMIT 1",
            [$symbol]
        );
        
        // Categorize current event
        $currentEventType = $this->categorizeEvent($currentNews['title'] . ' ' . $currentNews['summary']);
        $currentKeywords = $this->extractKeywords($currentNews['title'] . ' ' . $currentNews['summary']);
        
        // Find historical patterns (prioritize same event type, but include all)
        // Now using full 365 days of imported data
        $sql = "SELECT * FROM historical_patterns 
                WHERE symbol = ? 
                AND pattern_date >= DATE_SUB(NOW(), INTERVAL 365 DAY)
                ORDER BY 
                    CASE WHEN event_type = ? THEN 0 ELSE 1 END,
                    pattern_strength DESC,
                    pattern_date DESC
                LIMIT 200";
        
        $historicalPatterns = fetchAll($sql, [$symbol, $currentEventType]);
        
        // Calculate similarity for each pattern
        $matches = [];
        foreach ($historicalPatterns as $pattern) {
            $similarity = $this->calculateSimilarity(
                $currentNews,
                $currentPrice,
                $currentIndicators,
                $currentKeywords,
                $pattern
            );
            
            if ($similarity['overall'] >= $this->minSimilarityThreshold) {
                $matches[] = [
                    'pattern' => $pattern,
                    'similarity' => $similarity,
                    'predicted_direction' => $pattern['market_direction'],
                    'predicted_change' => $pattern['price_change_24h'],
                    'confidence' => $similarity['overall'] * $pattern['pattern_strength']
                ];
            }
        }
        
        // Sort by similarity and confidence
        usort($matches, function($a, $b) {
            return $b['confidence'] <=> $a['confidence'];
        });
        
        return array_slice($matches, 0, $limit);
    }
    
    /**
     * Store a pattern match for tracking
     */
    public function storePatternMatch($currentNewsId, $historicalPatternId, $symbol, $similarity, $prediction) {
        $sql = "INSERT INTO pattern_matches (
                    current_news_id, historical_pattern_id, symbol, match_date,
                    similarity_score, text_similarity, price_context_similarity,
                    indicator_similarity, sentiment_similarity,
                    predicted_direction, predicted_price_change_24h, confidence_score
                ) VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?)";
        
        executeQuery($sql, [
            $currentNewsId,
            $historicalPatternId,
            $symbol,
            $similarity['overall'],
            $similarity['text'],
            $similarity['price_context'],
            $similarity['indicators'],
            $similarity['sentiment'],
            $prediction['direction'],
            $prediction['price_change_24h'],
            $prediction['confidence']
        ]);
        
        return getDatabaseConnection()->lastInsertId();
    }
    
    /**
     * Calculate similarity between current event and historical pattern
     */
    private function calculateSimilarity($currentNews, $currentPrice, $currentIndicators, $currentKeywords, $historicalPattern) {
        // Text similarity (keyword matching)
        $textSimilarity = $this->calculateTextSimilarity(
            $currentKeywords,
            json_decode($historicalPattern['keywords'], true) ?? []
        );
        
        // Price context similarity
        $priceContextSimilarity = 0;
        if ($currentPrice && $historicalPattern['price_before']) {
            // Compare relative price positions (normalize)
            $priceContextSimilarity = 0.8; // Simplified
        }
        
        // Technical indicators similarity
        $indicatorSimilarity = 0;
        if ($currentIndicators && $historicalPattern['rsi_before']) {
            $indicatorSimilarity = $this->calculateIndicatorSimilarity(
                $currentIndicators,
                [
                    'rsi' => $historicalPattern['rsi_before'],
                    'macd' => $historicalPattern['macd_before'],
                    'volatility' => $historicalPattern['volatility_before']
                ]
            );
        }
        
        // Sentiment similarity
        $sentimentSimilarity = 0;
        if ($currentNews['sentiment'] === $historicalPattern['sentiment_before']) {
            $sentimentSimilarity = 1.0 - abs($currentNews['sentiment_score'] - $historicalPattern['sentiment_score_before']);
        }
        
        // Weighted overall similarity
        $overall = (
            $textSimilarity * 0.4 +
            $priceContextSimilarity * 0.2 +
            $indicatorSimilarity * 0.2 +
            $sentimentSimilarity * 0.2
        );
        
        return [
            'overall' => round($overall, 4),
            'text' => round($textSimilarity, 4),
            'price_context' => round($priceContextSimilarity, 4),
            'indicators' => round($indicatorSimilarity, 4),
            'sentiment' => round($sentimentSimilarity, 4)
        ];
    }
    
    /**
     * Calculate text similarity based on keywords
     */
    private function calculateTextSimilarity($keywords1, $keywords2) {
        if (empty($keywords1) || empty($keywords2)) {
            return 0;
        }
        
        $intersection = array_intersect($keywords1, $keywords2);
        $union = array_unique(array_merge($keywords1, $keywords2));
        
        return count($intersection) / count($union);
    }
    
    /**
     * Calculate indicator similarity
     */
    private function calculateIndicatorSimilarity($current, $historical) {
        $similarities = [];
        
        // RSI similarity
        if (isset($current['rsi']) && isset($historical['rsi'])) {
            $rsiDiff = abs($current['rsi'] - $historical['rsi']);
            $similarities[] = max(0, 1 - ($rsiDiff / 100));
        }
        
        // MACD similarity (normalized)
        if (isset($current['macd']) && isset($historical['macd'])) {
            $macdSame = ($current['macd'] > 0) === ($historical['macd'] > 0);
            $similarities[] = $macdSame ? 0.8 : 0.2;
        }
        
        // Volatility similarity
        if (isset($current['volatility']) && isset($historical['volatility'])) {
            $volDiff = abs($current['volatility'] - $historical['volatility']);
            $similarities[] = max(0, 1 - $volDiff);
        }
        
        return empty($similarities) ? 0 : array_sum($similarities) / count($similarities);
    }
    
    /**
     * Categorize event based on content
     */
    private function categorizeEvent($text) {
        $text = strtolower($text);
        
        // Get categories from database
        $categories = fetchAll("SELECT * FROM pattern_categories");
        
        $bestMatch = 'Other';
        $bestScore = 0;
        
        foreach ($categories as $category) {
            $keywords = json_decode($category['keywords'], true) ?? [];
            $score = 0;
            
            foreach ($keywords as $keyword) {
                if (stripos($text, $keyword) !== false) {
                    $score++;
                }
            }
            
            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $category['category_name'];
            }
        }
        
        return $bestMatch;
    }
    
    /**
     * Extract keywords from text
     */
    private function extractKeywords($text) {
        // Simple keyword extraction
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9\s]/', '', $text);
        
        // Common stop words
        $stopWords = ['the', 'is', 'at', 'which', 'on', 'a', 'an', 'as', 'are', 'was', 'were', 'been', 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should'];
        
        $words = explode(' ', $text);
        $words = array_filter($words, function($word) use ($stopWords) {
            return strlen($word) > 3 && !in_array($word, $stopWords);
        });
        
        // Get word frequency
        $frequency = array_count_values($words);
        arsort($frequency);
        
        return array_keys(array_slice($frequency, 0, 10));
    }
    
    /**
     * Calculate price changes after event
     */
    private function calculatePriceChanges($symbol, $eventTime) {
        $changes = [
            '1h' => null,
            '4h' => null,
            '24h' => null,
            '7d' => null,
            'volume_24h' => null,
            'volatility_change' => null
        ];
        
        // Get price before event
        $priceBefore = fetchOne(
            "SELECT close, volume FROM market_prices 
             WHERE symbol = ? AND timestamp <= ?
             ORDER BY timestamp DESC LIMIT 1",
            [$symbol, $eventTime]
        );
        
        if (!$priceBefore) return $changes;
        
        // Get prices after event
        $intervals = [
            '1h' => '1 HOUR',
            '4h' => '4 HOUR',
            '24h' => '24 HOUR',
            '7d' => '7 DAY'
        ];
        
        foreach ($intervals as $key => $interval) {
            $priceAfter = fetchOne(
                "SELECT close, volume FROM market_prices 
                 WHERE symbol = ? 
                 AND timestamp >= DATE_ADD(?, INTERVAL $interval)
                 ORDER BY timestamp ASC LIMIT 1",
                [$symbol, $eventTime]
            );
            
            if ($priceAfter) {
                $changes[$key] = (($priceAfter['close'] - $priceBefore['close']) / $priceBefore['close']) * 100;
                
                if ($key === '24h' && $priceBefore['volume'] > 0) {
                    $changes['volume_24h'] = (($priceAfter['volume'] - $priceBefore['volume']) / $priceBefore['volume']) * 100;
                }
            }
        }
        
        return $changes;
    }
    
    /**
     * Determine market direction from price changes
     */
    private function determineMarketDirection($priceChanges) {
        $change24h = $priceChanges['24h'] ?? 0;
        
        if ($change24h > 2) {
            return 'bullish';
        } elseif ($change24h < -2) {
            return 'bearish';
        } else {
            return 'sideways';
        }
    }
    
    /**
     * Calculate pattern strength based on price movement and indicators
     */
    private function calculatePatternStrength($priceChanges, $indicators) {
        $strength = 0.5; // Base strength
        
        // Strong price movements increase strength
        $change24h = abs($priceChanges['24h'] ?? 0);
        if ($change24h > 5) {
            $strength += 0.2;
        } elseif ($change24h > 10) {
            $strength += 0.3;
        }
        
        // High volatility indicates strong pattern
        if (isset($indicators['volatility']) && $indicators['volatility'] > 0.05) {
            $strength += 0.1;
        }
        
        return min(1.0, $strength);
    }
    
    /**
     * Generate learning insights from historical patterns
     */
    public function generateInsights($symbol = null, $eventType = null, $days = 30) {
        $whereConditions = ["match_date >= DATE_SUB(NOW(), INTERVAL ? DAY)"];
        $params = [$days];
        
        if ($symbol) {
            $whereConditions[] = "pm.symbol = ?";
            $params[] = $symbol;
        }
        
        if ($eventType) {
            $whereConditions[] = "hp.event_type = ?";
            $params[] = $eventType;
        }
        
        $where = implode(' AND ', $whereConditions);
        
        $sql = "SELECT 
                    pm.symbol,
                    hp.event_type,
                    COUNT(*) as pattern_count,
                    AVG(pm.predicted_price_change_24h) as avg_predicted_change,
                    AVG(pm.actual_price_change_24h) as avg_actual_change,
                    AVG(pm.prediction_accuracy) as avg_accuracy,
                    SUM(CASE WHEN pm.predicted_direction = pm.actual_direction THEN 1 ELSE 0 END) / COUNT(*) as success_rate
                FROM pattern_matches pm
                JOIN historical_patterns hp ON pm.historical_pattern_id = hp.id
                WHERE $where
                AND pm.actual_direction IS NOT NULL
                GROUP BY pm.symbol, hp.event_type
                HAVING pattern_count >= 3
                ORDER BY success_rate DESC, pattern_count DESC";
        
        return fetchAll($sql, $params);
    }
    
    /**
     * Get learning summary for display
     */
    public function getLearningSum($symbol, $newsId = null) {
        if (!$newsId) {
            // Get latest news (within 30 days for better pattern matching)
            $news = fetchOne(
                "SELECT id FROM news_events 
                 WHERE date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                 ORDER BY date DESC LIMIT 1"
            );
            $newsId = $news['id'] ?? null;
        }
        
        if (!$newsId) {
            return null;
        }
        
        // Find similar patterns
        $matches = $this->findSimilarPatterns($newsId, $symbol, 5);
        
        if (empty($matches)) {
            return null;
        }
        
        // Calculate aggregate prediction
        $totalConfidence = 0;
        $weightedChange = 0;
        $directions = ['bullish' => 0, 'bearish' => 0, 'sideways' => 0];
        
        foreach ($matches as $match) {
            $confidence = $match['confidence'];
            $totalConfidence += $confidence;
            $weightedChange += $match['predicted_change'] * $confidence;
            $directions[$match['predicted_direction']] += $confidence;
        }
        
        arsort($directions);
        $predictedDirection = array_key_first($directions);
        $avgChange = $totalConfidence > 0 ? $weightedChange / $totalConfidence : 0;
        $avgConfidence = $totalConfidence / count($matches);
        
        return [
            'symbol' => $symbol,
            'pattern_count' => count($matches),
            'predicted_direction' => $predictedDirection,
            'predicted_change' => round($avgChange, 2),
            'confidence' => round($avgConfidence, 4),
            'similar_patterns' => $matches,
            'recommendation' => $this->generateRecommendation($predictedDirection, $avgChange, $avgConfidence)
        ];
    }
    
    /**
     * Generate recommendation based on prediction (bilingual)
     */
    private function generateRecommendation($direction, $change, $confidence) {
        $absChange = abs($change);
        $lang = $_COOKIE['lang'] ?? 'ar';
        $isArabic = ($lang === 'ar');
        
        if ($confidence < 0.5) {
            return $isArabic ? 
                "⚠️ تنبؤ بثقة منخفضة. انتظر المزيد من البيانات قبل اتخاذ أي إجراء." :
                "⚠️ Low confidence prediction. Wait for more data before taking action.";
        }
        
        if ($direction === 'bullish') {
            if ($absChange > 5) {
                return $isArabic ?
                    "🚀 إشارة صاعدة قوية. الأنماط التاريخية تشير لحركة صعود كبيرة (+{$change}%). فكر في فرص الشراء." :
                    "🚀 Strong bullish signal detected. Historical patterns suggest significant upward movement (+{$change}%). Consider buying opportunities.";
            } else {
                return $isArabic ?
                    "📈 إشارة صاعدة متوسطة. الأنماط التاريخية تشير لاتجاه صاعد (+{$change}%). جيد للتراكم." :
                    "📈 Moderate bullish signal. Historical patterns suggest upward trend (+{$change}%). Good for accumulation.";
            }
        } elseif ($direction === 'bearish') {
            if ($absChange > 5) {
                return $isArabic ?
                    "⚠️ إشارة هابطة قوية. الأنماط التاريخية تشير لحركة هبوط كبيرة ({$change}%). فكر في إدارة المخاطر." :
                    "⚠️ Strong bearish signal detected. Historical patterns suggest significant downward movement ({$change}%). Consider risk management.";
            } else {
                return $isArabic ?
                    "📉 إشارة هابطة متوسطة. الأنماط التاريخية تشير لاتجاه هابط ({$change}%). كن حذراً مع المراكز الجديدة." :
                    "📉 Moderate bearish signal. Historical patterns suggest downward trend ({$change}%). Be cautious with new positions.";
            }
        } else {
            return $isArabic ?
                "➡️ حركة جانبية متوقعة. الأنماط التاريخية تشير للتماسك. انتظر إشارات أوضح." :
                "➡️ Sideways movement expected. Historical patterns suggest consolidation. Wait for clearer signals.";
        }
    }
}

// CLI Execution
if (php_sapi_name() === 'cli') {
    echo "=== Pattern Matcher Test ===\n\n";
    
    $matcher = new PatternMatcher();
    
    // Example: Find insights
    $insights = $matcher->generateInsights(null, null, 30);
    
    echo "Learning Insights (Last 30 days):\n";
    foreach ($insights as $insight) {
        echo "\n{$insight['symbol']} - {$insight['event_type']}:\n";
        echo "  Patterns found: {$insight['pattern_count']}\n";
        echo "  Success rate: " . round($insight['success_rate'] * 100, 1) . "%\n";
        echo "  Avg accuracy: " . round($insight['avg_accuracy'] * 100, 1) . "%\n";
    }
}
?>

