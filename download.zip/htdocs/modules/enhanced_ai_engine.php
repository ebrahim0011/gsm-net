<?php
/**
 * Enhanced AI Prediction Engine v2.0
 * 
 * Advanced AI system with:
 * - Multi-layer neural network simulation
 * - Dynamic weight adjustment
 * - Ensemble learning
 * - Risk assessment
 * - Confidence calibration
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/enhanced_sentiment_analyzer.php';
require_once __DIR__ . '/technical_indicators.php';
require_once __DIR__ . '/enhanced_multitimeframe_analyzer.php';
require_once __DIR__ . '/volume_analyzer.php';
require_once __DIR__ . '/fear_greed_index.php';

class EnhancedAIEngine {
    
    private $modelVersion = 'v2.0';
    private $silent = false;
    
    // Enhanced model parameters
    private $neuralWeights = [
        'technical_layer' => [
            'rsi' => 0.15,
            'macd' => 0.20,
            'bollinger' => 0.10,
            'ema_crossover' => 0.15,
            'volume_profile' => 0.25,
            'support_resistance' => 0.15
        ],
        'sentiment_layer' => [
            'news_sentiment' => 0.30,
            'social_sentiment' => 0.20,
            'market_emotion' => 0.25,
            'fear_greed' => 0.25
        ],
        'fundamental_layer' => [
            'adoption_metrics' => 0.25,
            'regulatory_news' => 0.30,
            'institutional_flow' => 0.25,
            'market_structure' => 0.20
        ],
        'timeframe_layer' => [
            '1h' => 0.15,
            '4h' => 0.25,
            '1d' => 0.35,
            '1w' => 0.25
        ]
    ];
    
    // Risk assessment parameters
    private $riskFactors = [
        'volatility_threshold' => 0.05,
        'volume_anomaly_threshold' => 2.0,
        'sentiment_divergence_threshold' => 0.3,
        'technical_conflict_threshold' => 0.4
    ];
    
    public function setSilentMode($silent = true) {
        $this->silent = $silent;
    }
    
    private function output($message) {
        if (!$this->silent) {
            echo $message;
        }
    }
    
    /**
     * Enhanced prediction with ensemble learning
     */
    public function predictEnhanced($symbol) {
        $this->output("🧠 Enhanced AI Analysis for {$symbol}...\n");
        
        // Gather all data sources
        $dataLayers = $this->gatherDataLayers($symbol);
        
        // Validate data quality
        $dataQuality = $this->assessDataQuality($dataLayers);
        if ($dataQuality['score'] < 0.5) {
            return $this->generateLowConfidencePrediction($dataQuality);
        }
        
        // Multi-layer analysis
        $layerResults = $this->performMultiLayerAnalysis($dataLayers);
        
        // Ensemble prediction
        $ensemblePrediction = $this->ensembleLearning($layerResults);
        
        // Risk assessment
        $riskAssessment = $this->assessRisk($dataLayers, $layerResults);
        
        // Confidence calibration
        $calibratedConfidence = $this->calibrateConfidence($ensemblePrediction, $riskAssessment, $dataQuality);
        
        // Generate final prediction
        $finalPrediction = $this->generateFinalPrediction(
            $ensemblePrediction,
            $riskAssessment,
            $calibratedConfidence,
            $symbol
        );
        
        // Save to database
        $this->savePrediction($symbol, $finalPrediction);
        
        $this->output("✅ Enhanced prediction completed\n");
        
        return $finalPrediction;
    }
    
    /**
     * Gather data from all layers
     */
    private function gatherDataLayers($symbol) {
        $layers = [];
        
        // Technical layer
        $technical = new TechnicalIndicators();
        $technical->setSilentMode(true);
        $layers['technical'] = $technical->getLatestIndicators($symbol);
        
        // Sentiment layer
        $sentiment = new EnhancedSentimentAnalyzer();
        $layers['sentiment'] = $sentiment->getRealTimeMarketSentiment(24);
        
        // Multi-timeframe layer
        $multiTimeframe = new EnhancedMultiTimeframeAnalyzer();
        $layers['timeframes'] = $multiTimeframe->analyzeMultiTimeframe($symbol);
        
        // Volume layer
        $volume = new VolumeAnalyzer();
        $layers['volume'] = $volume->getComprehensiveAnalysis($symbol);
        
        // Fear & Greed layer
        $fearGreed = new FearGreedIndex();
        $layers['fear_greed'] = $fearGreed->getCurrentIndex();
        
        // Price action layer
        $layers['price_action'] = $this->analyzePriceAction($symbol);
        
        return $layers;
    }
    
    /**
     * Assess data quality
     */
    private function assessDataQuality($dataLayers) {
        $qualityScore = 0;
        $qualityFactors = [];
        
        // Technical data quality
        if (!empty($dataLayers['technical'])) {
            $qualityScore += 0.2;
            $qualityFactors['technical'] = 'available';
        } else {
            $qualityFactors['technical'] = 'missing';
        }
        
        // Sentiment data quality
        if (!empty($dataLayers['sentiment']) && $dataLayers['sentiment']['total_articles'] > 5) {
            $qualityScore += 0.2;
            $qualityFactors['sentiment'] = 'sufficient';
        } else {
            $qualityFactors['sentiment'] = 'insufficient';
        }
        
        // Volume data quality
        if (!empty($dataLayers['volume']) && isset($dataLayers['volume']['vwap'])) {
            $qualityScore += 0.2;
            $qualityFactors['volume'] = 'available';
        } else {
            $qualityFactors['volume'] = 'limited';
        }
        
        // Timeframe data quality
        if (!empty($dataLayers['timeframes']['timeframe_analysis'])) {
            $timeframeCount = count($dataLayers['timeframes']['timeframe_analysis']);
            if ($timeframeCount >= 4) {
                $qualityScore += 0.2;
                $qualityFactors['timeframes'] = 'comprehensive';
            } else {
                $qualityScore += 0.1;
                $qualityFactors['timeframes'] = 'partial';
            }
        }
        
        // Price action data quality
        if (!empty($dataLayers['price_action'])) {
            $qualityScore += 0.2;
            $qualityFactors['price_action'] = 'available';
        }
        
        return [
            'score' => $qualityScore,
            'factors' => $qualityFactors,
            'grade' => $this->getQualityGrade($qualityScore)
        ];
    }
    
    /**
     * Perform multi-layer analysis
     */
    private function performMultiLayerAnalysis($dataLayers) {
        $results = [];
        
        // Technical analysis layer
        $results['technical'] = $this->analyzeTechnicalLayer($dataLayers['technical']);
        
        // Sentiment analysis layer
        $results['sentiment'] = $this->analyzeSentimentLayer($dataLayers['sentiment']);
        
        // Timeframe analysis layer
        $results['timeframes'] = $this->analyzeTimeframeLayer($dataLayers['timeframes']);
        
        // Volume analysis layer
        $results['volume'] = $this->analyzeVolumeLayer($dataLayers['volume']);
        
        // Market psychology layer
        $results['psychology'] = $this->analyzeMarketPsychology($dataLayers);
        
        return $results;
    }
    
    /**
     * Analyze technical layer
     */
    private function analyzeTechnicalLayer($technicalData) {
        if (empty($technicalData)) {
            return ['signal' => 'neutral', 'strength' => 0, 'confidence' => 0];
        }
        
        $signals = [];
        $weights = $this->neuralWeights['technical_layer'];
        
        // RSI analysis
        $rsi = (float)$technicalData['rsi'];
        if ($rsi <= 30) {
            $signals['rsi'] = ['signal' => 'bullish', 'strength' => (30 - $rsi) / 30];
        } elseif ($rsi >= 70) {
            $signals['rsi'] = ['signal' => 'bearish', 'strength' => ($rsi - 70) / 30];
        } else {
            $signals['rsi'] = ['signal' => 'neutral', 'strength' => 0];
        }
        
        // MACD analysis
        $macd = (float)$technicalData['macd'];
        $macdSignal = (float)$technicalData['macd_signal'];
        $macdHist = (float)$technicalData['macd_histogram'];
        
        if ($macd > $macdSignal && $macdHist > 0) {
            $signals['macd'] = ['signal' => 'bullish', 'strength' => min(1, abs($macdHist) * 100)];
        } elseif ($macd < $macdSignal && $macdHist < 0) {
            $signals['macd'] = ['signal' => 'bearish', 'strength' => min(1, abs($macdHist) * 100)];
        } else {
            $signals['macd'] = ['signal' => 'neutral', 'strength' => 0];
        }
        
        // Combine signals with neural weights
        return $this->combineSignals($signals, $weights);
    }
    
    /**
     * Analyze sentiment layer
     */
    private function analyzeSentimentLayer($sentimentData) {
        if (empty($sentimentData) || !isset($sentimentData['summary'])) {
            return ['signal' => 'neutral', 'strength' => 0, 'confidence' => 0.3];
        }
        
        $summary = $sentimentData['summary'];
        $signal = 'neutral';
        $strength = 0;
        
        // Determine signal from sentiment
        if ($summary['positive_percentage'] > 60) {
            $signal = 'bullish';
            $strength = ($summary['positive_percentage'] - 50) / 50;
        } elseif ($summary['negative_percentage'] > 60) {
            $signal = 'bearish';
            $strength = ($summary['negative_percentage'] - 50) / 50;
        }
        
        return [
            'signal' => $signal,
            'strength' => $strength,
            'confidence' => $summary['confidence'] ?? 0.5,
            'articles_count' => $sentimentData['total_articles'] ?? 0
        ];
    }
    
    /**
     * Ensemble learning - combine all layer predictions
     */
    private function ensembleLearning($layerResults) {
        $ensembleScore = 0;
        $totalWeight = 0;
        $confidenceSum = 0;
        $layerCount = 0;
        
        // Layer weights for ensemble
        $layerWeights = [
            'technical' => 0.25,
            'sentiment' => 0.20,
            'timeframes' => 0.25,
            'volume' => 0.15,
            'psychology' => 0.15
        ];
        
        foreach ($layerResults as $layer => $result) {
            if (isset($layerWeights[$layer]) && !empty($result)) {
                $weight = $layerWeights[$layer];
                $signal = $result['signal'] ?? 'neutral';
                $strength = $result['strength'] ?? 0;
                $confidence = $result['confidence'] ?? 0.5;
                
                // Convert signal to score
                $score = 0;
                if ($signal === 'bullish') {
                    $score = $strength;
                } elseif ($signal === 'bearish') {
                    $score = -$strength;
                }
                
                $ensembleScore += $score * $weight * $confidence;
                $totalWeight += $weight * $confidence;
                $confidenceSum += $confidence;
                $layerCount++;
            }
        }
        
        // Calculate final ensemble prediction
        $finalScore = $totalWeight > 0 ? $ensembleScore / $totalWeight : 0;
        $avgConfidence = $layerCount > 0 ? $confidenceSum / $layerCount : 0.3;
        
        // Determine final signal
        $finalSignal = 'neutral';
        if ($finalScore > 0.2) {
            $finalSignal = 'bullish';
        } elseif ($finalScore < -0.2) {
            $finalSignal = 'bearish';
        }
        
        return [
            'signal' => $finalSignal,
            'score' => $finalScore,
            'strength' => abs($finalScore),
            'confidence' => $avgConfidence,
            'layer_contributions' => $this->calculateLayerContributions($layerResults, $layerWeights)
        ];
    }
    
    /**
     * Assess overall risk
     */
    private function assessRisk($dataLayers, $layerResults) {
        $riskFactors = [];
        $riskScore = 0;
        
        // Volatility risk
        if (isset($dataLayers['technical']['volatility'])) {
            $volatility = (float)$dataLayers['technical']['volatility'];
            if ($volatility > $this->riskFactors['volatility_threshold']) {
                $riskFactors['high_volatility'] = $volatility;
                $riskScore += 0.3;
            }
        }
        
        // Sentiment divergence risk
        if (isset($layerResults['sentiment']) && isset($layerResults['technical'])) {
            $sentimentSignal = $layerResults['sentiment']['signal'];
            $technicalSignal = $layerResults['technical']['signal'];
            
            if ($sentimentSignal !== $technicalSignal && 
                $sentimentSignal !== 'neutral' && 
                $technicalSignal !== 'neutral') {
                $riskFactors['sentiment_technical_divergence'] = true;
                $riskScore += 0.4;
            }
        }
        
        // Volume anomaly risk
        if (isset($dataLayers['volume']['anomalous_volume'])) {
            $volumeAnomaly = $dataLayers['volume']['anomalous_volume'];
            if ($volumeAnomaly > $this->riskFactors['volume_anomaly_threshold']) {
                $riskFactors['volume_anomaly'] = $volumeAnomaly;
                $riskScore += 0.2;
            }
        }
        
        // Timeframe conflict risk
        if (isset($dataLayers['timeframes']['divergences'])) {
            $divergences = $dataLayers['timeframes']['divergences'];
            if (!empty($divergences)) {
                $riskFactors['timeframe_divergences'] = count($divergences);
                $riskScore += 0.3;
            }
        }
        
        return [
            'score' => min(1.0, $riskScore),
            'level' => $this->getRiskLevel($riskScore),
            'factors' => $riskFactors
        ];
    }
    
    /**
     * Calibrate confidence based on multiple factors
     */
    private function calibrateConfidence($prediction, $riskAssessment, $dataQuality) {
        $baseConfidence = $prediction['confidence'];
        
        // Adjust for data quality
        $qualityAdjustment = ($dataQuality['score'] - 0.5) * 0.4;
        
        // Adjust for risk
        $riskAdjustment = -$riskAssessment['score'] * 0.3;
        
        // Adjust for signal strength
        $strengthAdjustment = $prediction['strength'] * 0.2;
        
        $calibratedConfidence = $baseConfidence + $qualityAdjustment + $riskAdjustment + $strengthAdjustment;
        
        return max(0.1, min(0.95, $calibratedConfidence));
    }
    
    /**
     * Generate final prediction
     */
    private function generateFinalPrediction($ensemble, $risk, $confidence, $symbol) {
        $currentPrice = $this->getCurrentPrice($symbol);
        
        // Calculate price targets
        $priceTargets = $this->calculatePriceTargets($currentPrice, $ensemble, $confidence);
        
        // Generate explanation
        $explanation = $this->generateAdvancedExplanation($ensemble, $risk);
        
        return [
            'symbol' => $symbol,
            'model_version' => $this->modelVersion,
            'signal' => $ensemble['signal'],
            'confidence' => $confidence,
            'strength' => $ensemble['strength'],
            'score' => $ensemble['score'],
            'current_price' => $currentPrice,
            'price_targets' => $priceTargets,
            'risk_assessment' => $risk,
            'explanation' => $explanation,
            'layer_contributions' => $ensemble['layer_contributions'],
            'timestamp' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime('+4 hours'))
        ];
    }
    
    // Helper methods
    private function getQualityGrade($score) {
        if ($score >= 0.8) return 'A';
        if ($score >= 0.6) return 'B';
        if ($score >= 0.4) return 'C';
        return 'D';
    }
    
    private function getRiskLevel($score) {
        if ($score >= 0.7) return 'high';
        if ($score >= 0.4) return 'medium';
        return 'low';
    }
    
    private function combineSignals($signals, $weights) {
        $totalScore = 0;
        $totalWeight = 0;
        
        foreach ($signals as $indicator => $data) {
            $weight = $weights[$indicator] ?? 0;
            $score = 0;
            
            if ($data['signal'] === 'bullish') {
                $score = $data['strength'];
            } elseif ($data['signal'] === 'bearish') {
                $score = -$data['strength'];
            }
            
            $totalScore += $score * $weight;
            $totalWeight += $weight;
        }
        
        $finalScore = $totalWeight > 0 ? $totalScore / $totalWeight : 0;
        
        return [
            'signal' => $finalScore > 0.1 ? 'bullish' : ($finalScore < -0.1 ? 'bearish' : 'neutral'),
            'strength' => abs($finalScore),
            'confidence' => min(0.9, 0.5 + abs($finalScore))
        ];
    }
    
    // Placeholder methods - would need full implementation
    private function analyzePriceAction($symbol) { return []; }
    private function analyzeTimeframeLayer($data) { return ['signal' => 'neutral', 'strength' => 0, 'confidence' => 0.5]; }
    private function analyzeVolumeLayer($data) { return ['signal' => 'neutral', 'strength' => 0, 'confidence' => 0.5]; }
    private function analyzeMarketPsychology($data) { return ['signal' => 'neutral', 'strength' => 0, 'confidence' => 0.5]; }
    private function calculateLayerContributions($results, $weights) { return []; }
    private function getCurrentPrice($symbol) { return 0; }
    private function calculatePriceTargets($price, $ensemble, $confidence) { return []; }
    private function generateAdvancedExplanation($ensemble, $risk) { return 'Advanced AI analysis completed'; }
    private function savePrediction($symbol, $prediction) { return true; }
    private function generateLowConfidencePrediction($quality) { 
        return [
            'signal' => 'neutral',
            'confidence' => 0.3,
            'explanation' => 'Insufficient data quality for reliable prediction'
        ];
    }
}

