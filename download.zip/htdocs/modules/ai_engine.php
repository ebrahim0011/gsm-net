<?php
/**
 * AI Prediction Engine
 * 
 * Advanced AI system for cryptocurrency market prediction
 * Combines technical analysis, sentiment analysis, and historical patterns
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/sentiment_analyzer.php';
require_once __DIR__ . '/technical_indicators.php';
require_once __DIR__ . '/volume_analyzer.php';
require_once __DIR__ . '/fear_greed_index.php';

class AIEngine {
    
    // Silent mode (no console output) - for API calls
    private $silent = false;
    
    private $modelVersion = 'v1.2';
    private $minConfidenceThreshold = 0.60;
    
    /**
     * Enable/Disable console output
     */
    public function setSilentMode($silent = true) {
        $this->silent = $silent;
    }
    
    /**
     * Output helper - only print if not in silent mode
     */
    private function output($message) {
        if (!$this->silent) {
            echo $message;
        }
    }
    
    /**
     * Generate market prediction for symbol
     */
    public function predict($symbol) {
        $this->output("Generating AI prediction for {$symbol}...\n");
        
        // 1. Get technical indicators
        $technical = new TechnicalIndicators();
        $indicators = $technical->getLatestIndicators($symbol);
        
        if (!$indicators) {
            $this->output("  ✗ No technical indicators found. Please calculate them first.\n");
            return null;
        }
        
        // 2. Get sentiment analysis
        $sentiment = new SentimentAnalyzer();
        $marketSentiment = $sentiment->getMarketSentiment(24);
        
        // 3. Get recent price data
        $recentPrices = $this->getRecentPrices($symbol, 7);
        
        // 4. Calculate features
        $features = $this->extractFeatures($indicators, $marketSentiment, $recentPrices);
        
        // 5. Run prediction model
        $prediction = $this->runPredictionModel($features);
        
        // 6. Generate explanation
        $explanation = $this->generateExplanation($features, $prediction, $indicators, $marketSentiment);
        
        // 7. Save prediction to database
        $this->savePrediction($symbol, $prediction, $explanation);
        
        $this->output("  ✓ Prediction generated successfully\n");
        
        return [
            'symbol' => $symbol,
            'signal' => $prediction['signal'],
            'confidence' => $prediction['confidence'],
            'predicted_change' => $prediction['predicted_change'],
            'price_target' => $prediction['price_target'],
            'explanation' => $explanation,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Extract comprehensive features from all data sources
     */
    private function extractFeatures($indicators, $sentiment, $recentPrices) {
        $features = [];
        
        // Get advanced volume analysis (NEW - Weight: 15%)
        $volumeAnalyzer = new VolumeAnalyzer();
        $volumeAnalysis = $volumeAnalyzer->getComprehensiveAnalysis(
            $indicators['symbol'] ?? 'BTC'
        );
        $features['volume_analysis'] = $volumeAnalysis;
        
        // Get Fear & Greed Index (NEW - Weight: 10%)
        $fearGreedIndex = new FearGreedIndex();
        $fearGreed = $fearGreedIndex->getCurrentIndex();
        $features['fear_greed'] = $fearGreed;
        
        // Technical Analysis Features (Weight: 30% - reduced from 40%)
        $features['rsi'] = (float)$indicators['rsi'];
        $features['rsi_signal'] = $this->getRSISignal($features['rsi']);
        $features['rsi_strength'] = $this->getRSIStrength($features['rsi']);
        
        $features['macd'] = (float)$indicators['macd'];
        $features['macd_signal'] = (float)$indicators['macd_signal'];
        $features['macd_histogram'] = (float)$indicators['macd_histogram'];
        $features['macd_trend'] = $features['macd'] > $features['macd_signal'] ? 1 : -1;
        $features['macd_momentum'] = $this->getMACD_Momentum($features['macd_histogram']);
        
        $features['ema_12'] = (float)$indicators['ema_12'];
        $features['ema_26'] = (float)$indicators['ema_26'];
        $features['ema_crossover'] = $features['ema_12'] > $features['ema_26'] ? 1 : -1;
        $features['ema_separation'] = abs($features['ema_12'] - $features['ema_26']);
        
        $features['sma_20'] = (float)$indicators['sma_20'];
        $features['sma_50'] = (float)$indicators['sma_50'];
        
        $currentPrice = $recentPrices[0]['close'] ?? 0;
        $features['price_vs_sma20'] = $currentPrice > $features['sma_20'] ? 1 : -1;
        $features['price_vs_sma50'] = $currentPrice > $features['sma_50'] ? 1 : -1;
        
        $features['bb_position'] = $this->getBollingerPosition(
            $currentPrice,
            $indicators['bb_upper'],
            $indicators['bb_lower']
        );
        $features['bb_squeeze'] = $this->getBollingerSqueeze($indicators);
        
        $features['volatility'] = (float)$indicators['volatility'];
        $features['volatility_signal'] = $this->getVolatilitySignal($features['volatility']);
        
        // Enhanced News Sentiment Analysis (Weight: 35%)
        $criticalNews = $this->getCriticalNewsAnalysis();
        $features['sentiment_score'] = $sentiment['average_score'];
        $features['sentiment_signal'] = $this->getSentimentSignal($sentiment['overall_sentiment']);
        $features['sentiment_confidence'] = $criticalNews['confidence'];
        $features['sentiment_impact'] = $criticalNews['impact_score'];
        $features['positive_ratio'] = $sentiment['positive_percentage'] / 100;
        $features['negative_ratio'] = $sentiment['negative_percentage'] / 100;
        
        // Critical news weighting (higher impact)
        $features['critical_news_score'] = $criticalNews['weighted_score'];
        $features['news_freshness'] = $criticalNews['freshness_factor'];
        $features['source_credibility'] = $criticalNews['source_reliability'];
        
        // Price Action & Momentum Features (Weight: 25%)
        $features['price_trend_1h'] = $this->calculatePriceTrend($recentPrices, 1);
        $features['price_trend_4h'] = $this->calculatePriceTrend($recentPrices, 4);
        $features['price_trend_24h'] = $this->calculatePriceTrend($recentPrices, 24);
        $features['price_trend_7d'] = $this->calculatePriceTrend($recentPrices, 168);
        
        $features['price_momentum'] = $this->calculateMomentum($recentPrices);
        $features['volume_momentum'] = $this->calculateVolumeMomentum($recentPrices);
        $features['support_resistance'] = $this->getSupportResistanceLevels($recentPrices);
        
        return $features;
    }
    
    /**
     * Advanced AI prediction model with multi-factor analysis
     * NEW Weights: Volume 15%, Fear&Greed 10%, Technical 30%, News 30%, Price Action 15%
     */
    private function runPredictionModel($features) {
        $bullishScore = 0;
        $bearishScore = 0;
        $confidenceMultiplier = 1.0;
        
        // === VOLUME ANALYSIS (15% Weight) - NEW ===
        if (isset($features['volume_analysis'])) {
            $volumeScore = $features['volume_analysis']['overall_score'] ?? 0;
            
            // Volume score ranges from -100 to +100
            if ($volumeScore > 0) {
                $bullishScore += ($volumeScore / 100) * 40; // Max 40 points
                if ($volumeScore > 60) {
                    $confidenceMultiplier += 0.2; // Strong volume = high confidence
                }
            } else {
                $bearishScore += (abs($volumeScore) / 100) * 40;
                if ($volumeScore < -60) {
                    $confidenceMultiplier += 0.2;
                }
            }
            
            // VWAP Position bonus
            if (isset($features['volume_analysis']['vwap'])) {
                $vwap = $features['volume_analysis']['vwap'];
                if ($vwap['position'] === 'above' && $vwap['deviation_pct'] > 2) {
                    $bullishScore += 10;
                } elseif ($vwap['position'] === 'below' && $vwap['deviation_pct'] < -2) {
                    $bearishScore += 10;
                }
            }
            
            // OBV Trend
            if (isset($features['volume_analysis']['obv'])) {
                $obv = $features['volume_analysis']['obv'];
                if ($obv['signal'] === 'bullish' && $obv['strength'] > 0.5) {
                    $bullishScore += 15;
                    $confidenceMultiplier += 0.15;
                } elseif ($obv['signal'] === 'bearish' && $obv['strength'] > 0.5) {
                    $bearishScore += 15;
                    $confidenceMultiplier += 0.15;
                }
            }
            
            // Buy/Sell Pressure
            if (isset($features['volume_analysis']['pressure'])) {
                $pressure = $features['volume_analysis']['pressure'];
                if ($pressure['signal'] === 'strong_buy') {
                    $bullishScore += 15;
                } elseif ($pressure['signal'] === 'strong_sell') {
                    $bearishScore += 15;
                }
            }
        }
        
        // === FEAR & GREED INDEX (10% Weight) - NEW ===
        if (isset($features['fear_greed'])) {
            $fgValue = $features['fear_greed']['value'];
            
            // Fear & Greed is CONTRARIAN indicator
            // Extreme Fear (0-24) = BUY signal
            // Extreme Greed (76-100) = SELL signal
            if ($fgValue <= 24) {
                $bullishScore += 30; // Extreme Fear = Strong Buy
                $confidenceMultiplier += 0.25;
            } elseif ($fgValue <= 44) {
                $bullishScore += 15; // Fear = Moderate Buy
                $confidenceMultiplier += 0.1;
            } elseif ($fgValue >= 76) {
                $bearishScore += 30; // Extreme Greed = Strong Sell
                $confidenceMultiplier += 0.25;
            } elseif ($fgValue >= 56) {
                $bearishScore += 15; // Greed = Moderate Sell
                $confidenceMultiplier += 0.1;
            }
            // Neutral zone (45-55) = no impact
        }
        
        // === TECHNICAL ANALYSIS (30% Weight - reduced from 40%) ===
        
        // RSI Analysis - Enhanced with strength levels
        if ($features['rsi'] < 20) {
            $bullishScore += 35; // Extremely oversold
            $confidenceMultiplier += 0.3;
        } elseif ($features['rsi'] < 30) {
            $bullishScore += 25; // Oversold
            $confidenceMultiplier += 0.2;
        } elseif ($features['rsi'] > 80) {
            $bearishScore += 35; // Extremely overbought
            $confidenceMultiplier += 0.3;
        } elseif ($features['rsi'] > 70) {
            $bearishScore += 25; // Overbought
            $confidenceMultiplier += 0.2;
        } elseif ($features['rsi'] >= 45 && $features['rsi'] <= 55) {
            // Neutral zone - lower confidence
            $confidenceMultiplier -= 0.1;
        }
        
        // MACD Analysis - Enhanced with momentum
        $macdScore = 0;
        if ($features['macd_trend'] > 0) {
            $macdScore = 20;
            if (isset($features['macd_momentum']) && $features['macd_momentum'] > 0) {
                $macdScore += 10; // Strong bullish momentum
                $confidenceMultiplier += 0.15;
            }
            $bullishScore += $macdScore;
        } else {
            $macdScore = 20;
            if (isset($features['macd_momentum']) && $features['macd_momentum'] < 0) {
                $macdScore += 10; // Strong bearish momentum
                $confidenceMultiplier += 0.15;
            }
            $bearishScore += $macdScore;
        }
        
        // EMA Crossover - Enhanced with separation analysis
        if ($features['ema_crossover'] > 0) {
            $emaScore = 18;
            if (isset($features['ema_separation']) && $features['ema_separation'] > 100) {
                $emaScore += 7; // Strong separation = stronger signal
                $confidenceMultiplier += 0.1;
            }
            $bullishScore += $emaScore;
        } else {
            $emaScore = 18;
            if (isset($features['ema_separation']) && $features['ema_separation'] > 100) {
                $emaScore += 7;
                $confidenceMultiplier += 0.1;
            }
            $bearishScore += $emaScore;
        }
        
        // Multi-timeframe SMA Analysis
        $smaScore = 0;
        if ($features['price_vs_sma20'] > 0 && $features['price_vs_sma50'] > 0) {
            $smaScore = 15; // Both SMAs bullish
            $bullishScore += $smaScore;
        } elseif ($features['price_vs_sma20'] < 0 && $features['price_vs_sma50'] < 0) {
            $smaScore = 15; // Both SMAs bearish
            $bearishScore += $smaScore;
        }
        
        // Bollinger Bands Advanced Analysis
        if ($features['bb_position'] < -0.8) {
            $bullishScore += 15; // Very close to lower band - strong oversold
            $confidenceMultiplier += 0.15;
        } elseif ($features['bb_position'] > 0.8) {
            $bearishScore += 15; // Very close to upper band - strong overbought
            $confidenceMultiplier += 0.15;
        }
        
        // Bollinger Squeeze (volatility breakout prediction)
        if (isset($features['bb_squeeze']) && $features['bb_squeeze']) {
            $confidenceMultiplier += 0.2; // High probability of breakout
        }
        
        // === ENHANCED NEWS SENTIMENT ANALYSIS (30% Weight - reduced from 35%) ===
        
        // Critical news impact (higher weight for important news)
        $newsWeight = 30;
        if (isset($features['critical_news_score'])) {
            $criticalNewsImpact = $features['critical_news_score'] * 2; // Double weight for critical news
            if ($criticalNewsImpact > 0) {
                $bullishScore += $criticalNewsImpact;
            } else {
                $bearishScore += abs($criticalNewsImpact);
            }
            
            // Boost confidence for fresh, credible news
            if (isset($features['news_freshness']) && $features['news_freshness'] > 0.8) {
                $confidenceMultiplier += 0.25; // Fresh news = higher confidence
            }
            if (isset($features['source_credibility']) && $features['source_credibility'] > 0.8) {
                $confidenceMultiplier += 0.2; // Credible sources = higher confidence
            }
        }
        
        // General sentiment impact
        if ($features['sentiment_signal'] > 0) {
            $sentimentImpact = $newsWeight * $features['positive_ratio'];
            $bullishScore += $sentimentImpact;
        } else {
            $sentimentImpact = $newsWeight * $features['negative_ratio'];
            $bearishScore += $sentimentImpact;
        }
        
        // === PRICE ACTION & MOMENTUM (15% Weight - reduced from 25%) ===
        
        // Multi-timeframe trend analysis
        $trendScore = 0;
        if (isset($features['price_trend_1h']) && isset($features['price_trend_4h']) && 
            isset($features['price_trend_24h']) && isset($features['price_trend_7d'])) {
            
            $shortTermTrend = ($features['price_trend_1h'] + $features['price_trend_4h']) / 2;
            $longTermTrend = ($features['price_trend_24h'] + $features['price_trend_7d']) / 2;
            
            // Align short and long term trends
            if ($shortTermTrend > 0 && $longTermTrend > 0) {
                $trendScore = 20; // Strong aligned bullish trend
                $confidenceMultiplier += 0.2;
                $bullishScore += $trendScore;
            } elseif ($shortTermTrend < 0 && $longTermTrend < 0) {
                $trendScore = 20; // Strong aligned bearish trend
                $confidenceMultiplier += 0.2;
                $bearishScore += $trendScore;
            } elseif (abs($shortTermTrend - $longTermTrend) > 0.5) {
                $confidenceMultiplier -= 0.1; // Divergent trends = lower confidence
            }
        }
        
        // Volume momentum analysis
        if (isset($features['volume_momentum']) && abs($features['volume_momentum']) > 0.3) {
            $volumeImpact = 10;
            if ($features['volume_momentum'] > 0) {
                $bullishScore += $volumeImpact;
            } else {
                $bearishScore += $volumeImpact;
            }
            $confidenceMultiplier += 0.1; // Strong volume = higher confidence
        }
        
        // Price Momentum (Enhanced)
        if (isset($features['price_momentum']) && $features['price_momentum'] != 0) {
            $momentumImpact = 15 * abs($features['price_momentum']);
            if ($features['price_momentum'] > 0) {
                $bullishScore += $momentumImpact;
            } else {
                $bearishScore += $momentumImpact;
            }
        }
        
        // === FINAL DECISION ALGORITHM ===
        
        $totalScore = $bullishScore + $bearishScore;
        
        if ($totalScore == 0) {
            $signal = 'sideways';
            $confidence = 0.3; // Low confidence for no data
            $predictedChange = 0;
        } else {
            $bullishProb = $bullishScore / $totalScore;
            $bearishProb = $bearishScore / $totalScore;
            
            // Enhanced decision thresholds with confidence multiplier
            $baseConfidence = max($bullishProb, $bearishProb);
            $finalConfidence = min(0.95, $baseConfidence * $confidenceMultiplier);
            
            // More conservative thresholds for higher accuracy
            if ($bullishProb > 0.65) { // Raised from 0.55
                $signal = 'bullish';
                $confidence = $finalConfidence;
                $predictedChange = $this->calculatePredictedChange($features, 'bullish');
            } elseif ($bearishProb > 0.65) { // Raised from 0.55
                $signal = 'bearish';
                $confidence = $finalConfidence;
                $predictedChange = $this->calculatePredictedChange($features, 'bearish');
            } else {
                $signal = 'sideways';
                // Higher confidence for sideways when scores are close
                $confidence = min(0.85, 0.5 + (abs($bullishProb - $bearishProb) * 0.3));
                $predictedChange = 0;
            }
            
            // Apply minimum confidence threshold
            if ($confidence < $this->minConfidenceThreshold) {
                $signal = 'sideways';
                $confidence = max(0.3, $confidence);
            }
        }
        
        return [
            'signal' => $signal,
            'confidence' => round($confidence, 4),
            'predicted_change' => round($predictedChange, 2),
            'price_target' => 0, // Will be calculated later
            'bullish_score' => $bullishScore,
            'bearish_score' => $bearishScore
        ];
    }
    
    /**
     * Generate human-readable explanation
     */
    private function generateExplanation($features, $prediction, $indicators, $sentiment) {
        $factors = [];
        
        // === ENHANCED TECHNICAL FACTORS ===
        
        // Advanced RSI Analysis
        $rsi = $features['rsi'];
        if ($rsi < 20) {
            $factors[] = [
                'factor' => 'RSI شديد التشبع البيعي (Extremely Oversold)',
                'impact' => 'bullish',
                'strength' => 'very_high',
                'description' => "RSI عند {$rsi} - إشارة شراء قوية جداً، السوق مُتشبع بالبيع بشدة"
            ];
        } elseif ($rsi < 30) {
            $factors[] = [
                'factor' => 'RSI متشبع بالبيع (Oversold)',
                'impact' => 'bullish',
                'strength' => 'high',
                'description' => "RSI عند {$rsi} - إشارة شراء قوية، قد يحدث ارتداد صاعد"
            ];
        } elseif ($rsi > 80) {
            $factors[] = [
                'factor' => 'RSI شديد التشبع الشرائي (Extremely Overbought)',
                'impact' => 'bearish',
                'strength' => 'very_high',
                'description' => "RSI عند {$rsi} - إشارة بيع قوية جداً، السوق مُتشبع بالشراء بشدة"
            ];
        } elseif ($rsi > 70) {
            $factors[] = [
                'factor' => 'RSI متشبع بالشراء (Overbought)',
                'impact' => 'bearish',
                'strength' => 'high',
                'description' => "RSI عند {$rsi} - إشارة بيع قوية، قد يحدث تصحيح هابط"
            ];
        }
        
        // Enhanced MACD Analysis
        if ($features['macd_trend'] > 0) {
            $strength = isset($features['macd_momentum']) && $features['macd_momentum'] > 0 ? 'very_high' : 'medium';
            $factors[] = [
                'factor' => 'MACD صاعد (Bullish Crossover)',
                'impact' => 'bullish',
                'strength' => $strength,
                'description' => 'خط MACD فوق الإشارة - زخم صاعد ' . ($strength === 'very_high' ? 'قوي جداً' : 'متوسط')
            ];
        } else {
            $strength = isset($features['macd_momentum']) && $features['macd_momentum'] < 0 ? 'very_high' : 'medium';
            $factors[] = [
                'factor' => 'MACD هابط (Bearish Crossover)',
                'impact' => 'bearish',
                'strength' => $strength,
                'description' => 'خط MACD تحت الإشارة - زخم هابط ' . ($strength === 'very_high' ? 'قوي جداً' : 'متوسط')
            ];
        }
        
        // Enhanced EMA Analysis
        if ($features['ema_crossover'] > 0) {
            $strength = isset($features['ema_separation']) && $features['ema_separation'] > 100 ? 'high' : 'medium';
            $factors[] = [
                'factor' => 'التقاطع الذهبي (Golden Cross)',
                'impact' => 'bullish',
                'strength' => $strength,
                'description' => 'EMA قصير المدى فوق طويل المدى - اتجاه صاعد ' . ($strength === 'high' ? 'قوي' : 'متوسط')
            ];
        }
        
        // Bollinger Bands Analysis
        if (isset($features['bb_squeeze']) && $features['bb_squeeze']) {
            $factors[] = [
                'factor' => 'ضغط بولينجر (Bollinger Squeeze)',
                'impact' => 'neutral',
                'strength' => 'high',
                'description' => 'الأشرطة ضيقة جداً - احتمالية اختراق قوي قريباً'
            ];
        } elseif ($features['bb_position'] < -0.8) {
            $factors[] = [
                'factor' => 'قرب الشريط السفلي (Near Lower Band)',
                'impact' => 'bullish',
                'strength' => 'high',
                'description' => 'السعر قريب جداً من الشريط السفلي - منطقة دعم قوية'
            ];
        } elseif ($features['bb_position'] > 0.8) {
            $factors[] = [
                'factor' => 'قرب الشريط العلوي (Near Upper Band)',
                'impact' => 'bearish',
                'strength' => 'high',
                'description' => 'السعر قريب جداً من الشريط العلوي - منطقة مقاومة قوية'
            ];
        }
        
        // === VOLUME ANALYSIS FACTORS (NEW) ===
        
        if (isset($features['volume_analysis'])) {
            $volumeSignal = $features['volume_analysis']['signal'] ?? 'neutral';
            $volumeScore = $features['volume_analysis']['overall_score'] ?? 0;
            
            if ($volumeSignal !== 'neutral') {
                $impact = in_array($volumeSignal, ['bullish', 'strong_bullish']) ? 'bullish' : 'bearish';
                $strength = strpos($volumeSignal, 'strong') !== false ? 'very_high' : 'high';
                
                $factors[] = [
                    'factor' => 'تحليل الحجم (Volume Analysis)',
                    'impact' => $impact,
                    'strength' => $strength,
                    'description' => "تحليل حجم التداول يظهر إشارة {$volumeSignal} بدرجة {$volumeScore}"
                ];
            }
            
            // OBV Signal
            if (isset($features['volume_analysis']['obv'])) {
                $obv = $features['volume_analysis']['obv'];
                if ($obv['strength'] > 0.5) {
                    $factors[] = [
                        'factor' => 'OBV - التراكم والتوزيع',
                        'impact' => $obv['signal'] === 'bullish' ? 'bullish' : 'bearish',
                        'strength' => 'high',
                        'description' => "OBV يُظهر " . ($obv['trend'] === 'accumulation' ? 'تراكم' : 'توزيع') . " قوي"
                    ];
                }
            }
            
            // Anomalous Volume
            if (isset($features['volume_analysis']['anomaly']) && $features['volume_analysis']['anomaly']['is_anomalous']) {
                $anomaly = $features['volume_analysis']['anomaly'];
                $factors[] = [
                    'factor' => 'نشاط الحيتان (Whale Activity)',
                    'impact' => 'neutral',
                    'strength' => 'very_high',
                    'description' => "حجم تداول غير طبيعي (×{$anomaly['multiplier']} من المعدل) - نشاط حيتان محتمل"
                ];
            }
        }
        
        // === FEAR & GREED INDEX FACTOR (NEW) ===
        
        if (isset($features['fear_greed'])) {
            $fg = $features['fear_greed'];
            $impact = in_array($fg['sentiment'], ['extreme_fear', 'fear']) ? 'bullish' : 
                     (in_array($fg['sentiment'], ['extreme_greed', 'greed']) ? 'bearish' : 'neutral');
            
            if ($impact !== 'neutral') {
                $strength = strpos($fg['sentiment'], 'extreme') !== false ? 'very_high' : 'high';
                $factors[] = [
                    'factor' => "مؤشر الخوف والطمع ({$fg['classification']})",
                    'impact' => $impact,
                    'strength' => $strength,
                    'description' => "{$fg['emoji']} {$fg['value']}/100 - {$fg['recommendation']}"
                ];
            }
        }
        
        // === ENHANCED NEWS SENTIMENT FACTORS ===
        
        // Critical news impact
        if (isset($features['critical_news_score']) && abs($features['critical_news_score']) > 0.3) {
            $impact = $features['critical_news_score'] > 0 ? 'bullish' : 'bearish';
            $strength = abs($features['critical_news_score']) > 0.6 ? 'very_high' : 'high';
            $factors[] = [
                'factor' => 'أخبار حرجة مؤثرة (Critical News Impact)',
                'impact' => $impact,
                'strength' => $strength,
                'description' => 'أخبار مهمة تؤثر بقوة على السوق - مؤشر ' . ($impact === 'bullish' ? 'إيجابي' : 'سلبي') . ' قوي'
            ];
        }
        
        // General sentiment
        if (abs($sentiment['average_score']) > 0.2) {
            $factors[] = [
                'factor' => 'معنويات السوق (Market Sentiment)',
                'impact' => $sentiment['overall_sentiment'] === 'positive' ? 'bullish' : 'bearish',
                'strength' => abs($sentiment['average_score']) > 0.4 ? 'high' : 'medium',
                'description' => "معنويات السوق {$sentiment['overall_sentiment']} مع {$sentiment['positive_percentage']}% أخبار إيجابية"
            ];
        }
        
        // === PRICE ACTION FACTORS ===
        
        // Multi-timeframe trend analysis
        if (isset($features['price_trend_24h']) && abs($features['price_trend_24h']) > 0.05) {
            $impact = $features['price_trend_24h'] > 0 ? 'bullish' : 'bearish';
            $factors[] = [
                'factor' => 'اتجاه السعر 24 ساعة (24h Price Trend)',
                'impact' => $impact,
                'strength' => 'medium',
                'description' => 'اتجاه السعر خلال 24 ساعة ' . ($impact === 'bullish' ? 'صاعد' : 'هابط') . ' بقوة'
            ];
        }
        
        // Volume momentum
        if (isset($features['volume_momentum']) && abs($features['volume_momentum']) > 0.3) {
            $impact = $features['volume_momentum'] > 0 ? 'bullish' : 'bearish';
            $factors[] = [
                'factor' => 'زخم حجم التداول (Volume Momentum)',
                'impact' => $impact,
                'strength' => 'medium',
                'description' => 'حجم التداول ' . ($impact === 'bullish' ? 'يرتفع' : 'ينخفض') . ' - مؤشر على القوة'
            ];
        }
        
        // Support/Resistance levels
        if (isset($features['support_resistance'])) {
            if ($features['support_resistance'] == 1) {
                $factors[] = [
                    'factor' => 'قرب مستوى الدعم (Near Support)',
                    'impact' => 'bullish',
                    'strength' => 'high',
                    'description' => 'السعر قريب من مستوى دعم قوي - احتمالية ارتداد عالية'
                ];
            } elseif ($features['support_resistance'] == -1) {
                $factors[] = [
                    'factor' => 'قرب مستوى المقاومة (Near Resistance)',
                    'impact' => 'bearish',
                    'strength' => 'high',
                    'description' => 'السعر قريب من مستوى مقاومة قوي - صعوبة في الاختراق'
                ];
            }
        }
        
        // Generate enhanced recommendation
        $recommendation = $this->generateEnhancedRecommendation($prediction['signal'], $prediction['confidence'], $features);
        
        return [
            'top_factors' => array_slice($factors, 0, 6),
            'recommendation' => $recommendation,
            'risk_level' => $this->assessRiskLevel($features),
            'suggested_action' => $this->suggestAction($prediction['signal'], $prediction['confidence']),
            'market_context' => $this->getMarketContext($features)
        ];
    }
    
    /**
     * Generate trading recommendation (bilingual)
     */
    private function generateRecommendation($signal, $confidence) {
        $lang = $_COOKIE['lang'] ?? 'ar';
        $isArabic = ($lang === 'ar');
        
        if ($confidence < $this->minConfidenceThreshold) {
            return $isArabic ?
                "إشارة بثقة منخفضة. فكر في الانتظار للحصول على مؤشرات أقوى قبل اتخاذ إجراء." :
                "Low confidence signal. Consider waiting for stronger indicators before taking action.";
        }
        
        switch ($signal) {
            case 'bullish':
                if ($confidence > 0.8) {
                    return $isArabic ?
                        "إشارة صاعدة قوية. ظروف السوق تفضل فرص الشراء. فكر في الدخول بمراكز شراء مع إدارة مخاطر مناسبة." :
                        "Strong bullish signal detected. Market conditions favor buying opportunities. Consider entering long positions with proper risk management.";
                } else {
                    return $isArabic ?
                        "إشارة صاعدة متوسطة. السوق يُظهر مؤشرات إيجابية لكن توخَّ الحذر. فكر في أحجام مراكز صغيرة." :
                        "Moderate bullish signal. Market shows positive indicators but exercise caution. Consider small position sizes.";
                }
            
            case 'bearish':
                if ($confidence > 0.8) {
                    return $isArabic ?
                        "إشارة هابطة قوية. ظروف السوق تشير لضغط هبوطي. فكر في جني الأرباح أو تجنب مراكز شراء جديدة." :
                        "Strong bearish signal detected. Market conditions suggest downward pressure. Consider taking profits or avoiding new long positions.";
                } else {
                    return $isArabic ?
                        "إشارة هابطة متوسطة. السوق يُظهر مؤشرات سلبية. كن حذراً مع المراكز الجديدة وفكر في التحوط من المخاطر." :
                        "Moderate bearish signal. Market shows negative indicators. Be cautious with new positions and consider risk hedging.";
                }
            
            default:
                return $isArabic ?
                    "السوق في حالة تماسك. لا يوجد اتجاه واضح. من الأفضل الانتظار للحصول على إشارات أوضح قبل اتخاذ مراكز كبيرة." :
                    "Market is consolidating. No clear direction detected. Best to wait for clearer signals before taking significant positions.";
        }
    }
    
    /**
     * Assess risk level
     */
    private function assessRiskLevel($features) {
        $volatility = $features['volatility'];
        $sentimentScore = abs($features['sentiment_score']);
        
        $riskScore = ($volatility * 0.6) + ($sentimentScore * 0.4);
        
        if ($riskScore > 0.7) {
            return 'high';
        } elseif ($riskScore > 0.4) {
            return 'medium';
        } else {
            return 'low';
        }
    }
    
    /**
     * Suggest action
     */
    private function suggestAction($signal, $confidence) {
        if ($confidence < 0.6) {
            return 'WAIT';
        }
        
        if ($signal === 'bullish' && $confidence > 0.7) {
            return 'BUY';
        } elseif ($signal === 'bearish' && $confidence > 0.7) {
            return 'SELL';
        } else {
            return 'HOLD';
        }
    }
    
    /**
     * Enhanced helper functions for advanced analysis
     */
    private function getRSISignal($rsi) {
        if ($rsi < 30) return 1;      // Bullish
        if ($rsi > 70) return -1;     // Bearish
        return 0;                      // Neutral
    }
    
    private function getRSIStrength($rsi) {
        if ($rsi < 20 || $rsi > 80) return 'extreme';
        if ($rsi < 30 || $rsi > 70) return 'strong';
        if ($rsi < 40 || $rsi > 60) return 'moderate';
        return 'weak';
    }
    
    private function getMACD_Momentum($histogram) {
        if (!is_numeric($histogram)) return 0;
        if ($histogram > 50) return 1;
        if ($histogram < -50) return -1;
        return 0;
    }
    
    private function getBollingerSqueeze($indicators) {
        if (!isset($indicators['bb_upper']) || !isset($indicators['bb_lower'])) return false;
        $bandWidth = $indicators['bb_upper'] - $indicators['bb_lower'];
        $currentPrice = $indicators['bb_middle'] ?? 0;
        if ($currentPrice == 0) return false;
        
        $percentWidth = ($bandWidth / $currentPrice) * 100;
        return $percentWidth < 2; // Squeeze when bands are very tight
    }
    
    private function getVolatilitySignal($volatility) {
        if ($volatility > 0.05) return 'high';
        if ($volatility > 0.03) return 'medium';
        return 'low';
    }
    
    private function getCriticalNewsAnalysis() {
        $sentiment = new SentimentAnalyzer();
        $criticalNews = $sentiment->getCriticalNews(24);
        
        if (empty($criticalNews)) {
            return [
                'weighted_score' => 0,
                'confidence' => 0.1,
                'impact_score' => 0,
                'freshness_factor' => 0,
                'source_reliability' => 0.5
            ];
        }
        
        $totalScore = 0;
        $totalWeight = 0;
        $freshnessSum = 0;
        $reliabilitySum = 0;
        
        // Source reliability weights
        $sourceWeights = [
            'cointelegraph' => 0.9,
            'coindesk' => 0.95,
            'theblock' => 0.85,
            'decrypt' => 0.8,
            'bitcoin' => 0.75,
            'cryptoslate' => 0.7,
            'default' => 0.6
        ];
        
        foreach ($criticalNews as $news) {
            $score = (float)$news['sentiment_score'];
            $weight = 1.0;
            
            // Time decay (fresher news = higher weight)
            $hoursAgo = (time() - strtotime($news['date'])) / 3600;
            $freshnessWeight = max(0.3, 1 - ($hoursAgo / 24)); // Decay over 24h
            
            // Source reliability
            $source = $news['source'] ?? 'default';
            $reliability = $sourceWeights[$source] ?? $sourceWeights['default'];
            
            // Critical keyword bonus
            $title = strtolower($news['title']);
            if (strpos($title, 'bitcoin') !== false || strpos($title, 'btc') !== false) {
                $weight *= 1.5;
            }
            if (strpos($title, 'sec') !== false || strpos($title, 'etf') !== false) {
                $weight *= 2.0; // SEC/ETF news very important
            }
            
            $finalWeight = $weight * $freshnessWeight * $reliability;
            $totalScore += $score * $finalWeight;
            $totalWeight += $finalWeight;
            
            $freshnessSum += $freshnessWeight;
            $reliabilitySum += $reliability;
        }
        
        $avgScore = $totalWeight > 0 ? $totalScore / $totalWeight : 0;
        $avgFreshness = count($criticalNews) > 0 ? $freshnessSum / count($criticalNews) : 0;
        $avgReliability = count($criticalNews) > 0 ? $reliabilitySum / count($criticalNews) : 0.5;
        
        return [
            'weighted_score' => $avgScore,
            'confidence' => min(1.0, $avgReliability + $avgFreshness * 0.3),
            'impact_score' => abs($avgScore),
            'freshness_factor' => $avgFreshness,
            'source_reliability' => $avgReliability
        ];
    }
    
    private function calculateVolumeMomentum($recentPrices) {
        if (count($recentPrices) < 2) return 0;
        
        $currentVolume = $recentPrices[0]['volume'] ?? 0;
        $avgVolume = 0;
        $count = min(5, count($recentPrices));
        
        for ($i = 1; $i < $count; $i++) {
            $avgVolume += $recentPrices[$i]['volume'] ?? 0;
        }
        $avgVolume = $avgVolume / ($count - 1);
        
        if ($avgVolume == 0) return 0;
        return ($currentVolume - $avgVolume) / $avgVolume;
    }
    
    private function getSupportResistanceLevels($recentPrices) {
        if (count($recentPrices) < 5) return 0;
        
        $highs = array_column($recentPrices, 'high');
        $lows = array_column($recentPrices, 'low');
        
        $resistance = max($highs);
        $support = min($lows);
        $currentPrice = $recentPrices[0]['close'] ?? 0;
        
        if ($currentPrice == 0) return 0;
        
        // Distance from support/resistance
        $supportDistance = ($currentPrice - $support) / $currentPrice;
        $resistanceDistance = ($resistance - $currentPrice) / $currentPrice;
        
        // Near support = bullish signal, near resistance = bearish signal
        if ($supportDistance < 0.02) return 1; // Very close to support
        if ($resistanceDistance < 0.02) return -1; // Very close to resistance
        return 0; // In between
    }
    
    private function getSentimentSignal($sentiment) {
        return $sentiment === 'positive' ? 1 : ($sentiment === 'negative' ? -1 : 0);
    }
    
    private function getBollingerPosition($price, $upper, $lower) {
        if ($upper == $lower) return 0;
        return (($price - $lower) / ($upper - $lower)) - 0.5;
    }
    
    private function calculatePriceTrend($prices, $hours) {
        if (count($prices) < 2) return 0;
        
        $recent = $prices[0]['close'];
        $past = $prices[min(count($prices) - 1, $hours)]['close'] ?? $prices[count($prices) - 1]['close'];
        
        if ($past == 0) return 0;
        return ($recent - $past) / $past;
    }
    
    private function calculateMomentum($prices) {
        if (count($prices) < 3) return 0;
        
        $changes = [];
        for ($i = 0; $i < min(3, count($prices) - 1); $i++) {
            $changes[] = ($prices[$i]['close'] - $prices[$i + 1]['close']) / $prices[$i + 1]['close'];
        }
        
        return array_sum($changes) / count($changes);
    }
    
    private function calculatePredictedChange($features, $direction) {
        $base = 2; // Base percentage
        $momentum = abs($features['price_momentum']) * 50;
        $sentiment = abs($features['sentiment_score']) * 30;
        
        $change = $base + $momentum + $sentiment;
        
        return $direction === 'bullish' ? $change : -$change;
    }
    
    private function getRecentPrices($symbol, $days = 7) {
        $sql = "SELECT * FROM market_prices 
                WHERE symbol = :symbol 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL :days DAY)
                ORDER BY timestamp DESC";
        
        return fetchAll($sql, [':symbol' => $symbol, ':days' => $days]);
    }
    
    /**
     * Save prediction to database
     */
    private function savePrediction($symbol, $prediction, $explanation) {
        try {
            $sql = "INSERT INTO ai_predictions 
                    (symbol, prediction_timestamp, target_timestamp, predicted_signal, 
                     confidence_score, predicted_price, top_factors, model_version)
                    VALUES 
                    (:symbol, NOW(), DATE_ADD(NOW(), INTERVAL 24 HOUR), :signal,
                     :confidence, :predicted_price, :factors, :model_version)";
            
            executeQuery($sql, [
                ':symbol' => $symbol,
                ':signal' => $prediction['signal'],
                ':confidence' => $prediction['confidence'],
                ':predicted_price' => $prediction['price_target'] ?? 0,
                ':factors' => json_encode($explanation['top_factors'] ?? []),
                ':model_version' => $this->modelVersion
            ]);
            
            $this->output("  ✓ Prediction saved to database\n");
        } catch (Exception $e) {
            $this->output("  ✗ Failed to save prediction: " . $e->getMessage() . "\n");
        }
    }
    
    /**
     * Generate enhanced trading recommendation with context (bilingual)
     */
    private function generateEnhancedRecommendation($signal, $confidence, $features) {
        $lang = $_COOKIE['lang'] ?? 'ar';
        $isArabic = ($lang === 'ar');
        
        $baseRecommendation = $this->generateRecommendation($signal, $confidence);
        
        // Add contextual advice based on current market conditions
        $context = "";
        
        // Volatility context
        if (isset($features['volatility']) && $features['volatility'] > 0.05) {
            $context .= $isArabic ?
                " السوق متقلب حالياً - فكر في تجزئة الدخول. " :
                " Market is volatile - consider scaling in. ";
        }
        
        // News context
        if (isset($features['critical_news_score']) && abs($features['critical_news_score']) > 0.5) {
            $context .= $isArabic ?
                " توجد أخبار مؤثرة حالياً - راقب التطورات عن كثب. " :
                " Critical news present - monitor developments closely. ";
        }
        
        // Risk management
        if ($confidence < 0.7) {
            $context .= $isArabic ?
                " الثقة متوسطة - استخدم مبالغ صغيرة للاختبار. " :
                " Medium confidence - use small amounts for testing. ";
        }
        
        return $baseRecommendation . $context;
    }
    
    /**
     * Get market context summary
     */
    private function getMarketContext($features) {
        $context = [];
        
        // Overall market phase
        if (isset($features['volatility'])) {
            if ($features['volatility'] < 0.02) {
                $context['phase'] = 'accumulation'; // Low volatility
            } elseif ($features['volatility'] > 0.06) {
                $context['phase'] = 'distribution'; // High volatility
            } else {
                $context['phase'] = 'trending'; // Medium volatility
            }
        }
        
        // Sentiment context
        if (isset($features['sentiment_confidence'])) {
            $context['news_reliability'] = $features['sentiment_confidence'] > 0.7 ? 'high' : 'medium';
        }
        
        // Technical context
        $technicalStrength = 0;
        if (isset($features['rsi_strength'])) {
            $technicalStrength += $features['rsi_strength'] === 'extreme' ? 2 : 1;
        }
        if (isset($features['macd_momentum']) && abs($features['macd_momentum']) > 0) {
            $technicalStrength += 1;
        }
        
        $context['technical_strength'] = $technicalStrength > 2 ? 'strong' : 'moderate';
        
        return $context;
    }
    
    /**
     * Get latest prediction
     */
    public function getLatestPrediction($symbol) {
        $sql = "SELECT * FROM ai_predictions 
                WHERE symbol = :symbol 
                ORDER BY prediction_timestamp DESC 
                LIMIT 1";
        
        return fetchOne($sql, [':symbol' => $symbol]);
    }
}

// CLI Execution
if (php_sapi_name() === 'cli') {
    echo "=== AI Prediction Engine ===\n\n";
    
    $ai = new AIEngine();
    $symbols = ['BTC', 'ETH'];
    
    foreach ($symbols as $symbol) {
        $prediction = $ai->predict($symbol);
        
        if ($prediction) {
            echo "\n{$symbol} Prediction:\n";
            echo "  Signal: " . strtoupper($prediction['signal']) . "\n";
            echo "  Confidence: " . ($prediction['confidence'] * 100) . "%\n";
            echo "  Predicted Change: " . $prediction['predicted_change'] . "%\n";
        }
    }
}
?>

