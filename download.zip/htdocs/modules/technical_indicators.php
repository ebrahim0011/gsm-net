<?php
/**
 * Technical Indicators Calculator
 * 
 * Calculates various technical indicators:
 * - RSI (Relative Strength Index)
 * - MACD (Moving Average Convergence Divergence)
 * - EMA (Exponential Moving Average)
 * - SMA (Simple Moving Average)
 * - Bollinger Bands
 * - Volatility
 * - ADX (Average Directional Index)
 * - Ichimoku Cloud
 * - Fibonacci Retracement
 */

require_once __DIR__ . '/../config/database.php';

class TechnicalIndicators {
    
    // Silent mode (no console output) - for API calls
    private $silent = false;
    
    /**
     * Enable/Disable console output
     */
    public function setSilentMode($silent = true) {
        $this->silent = $silent;
    }
    
    /**
     * Output helper - only print if not in silent mode
     */
    private function output($message) {
        if (!$this->silent) {
            echo $message;
        }
    }
    
    /**
     * Calculate all indicators for a symbol
     */
    public function calculateAll($symbol, $limit = 200) {
        $this->output("Calculating technical indicators for {$symbol}...\n");
        
        // Get price data
        $prices = $this->getPriceData($symbol, $limit);
        
        if (empty($prices)) {
            $this->output("  ✗ No price data found for {$symbol}\n");
            return false;
        }
        
        $priceCount = count($prices);
        $this->output("  → Found {$priceCount} price records\n");
        
        // Reverse prices array for correct chronological order (oldest first)
        // Database returns DESC (newest first), but indicators need oldest first
        $prices = array_reverse($prices);
        
        // Calculate indicators (with smart periods based on data availability)
        $closes = array_column($prices, 'close');
        $highs = array_column($prices, 'high');
        $lows = array_column($prices, 'low');
        $timestamps = array_column($prices, 'timestamp');
        
        // Adjust periods based on available data
        $dataCount = count($closes);
        $rsiPeriod = min(14, max(5, $dataCount - 1));
        $smaPeriod = min(20, max(5, $dataCount - 1));
        
        // Calculate indicators with adaptive periods
        $rsi = $this->calculateRSI($closes, $rsiPeriod);
        $macd = $this->calculateMACD($closes);
        $ema12 = $this->calculateEMA($closes, min(12, $dataCount));
        $ema26 = $this->calculateEMA($closes, min(26, $dataCount));
        $sma20 = $this->calculateSMA($closes, $smaPeriod);
        $sma50 = $dataCount >= 50 ? $this->calculateSMA($closes, 50) : [end($closes)];
        $sma200 = $dataCount >= 200 ? $this->calculateSMA($closes, 200) : [end($closes)];
        $bb = $this->calculateBollingerBands($closes, $smaPeriod, 2);
        $volatility = $this->calculateVolatility($closes, $smaPeriod);
        $ichimoku = $this->calculateIchimoku($highs, $lows, $closes);
        $fib = $this->calculateFibonacci($closes);
        
        $this->output("  ✓ Calculated indicators (RSI period: {$rsiPeriod}, SMA period: {$smaPeriod})\n");
        
        // Use latest (last) data point after chronological sort
        $latest = $prices[count($prices) - 1];
        
        // Get last index for each indicator array (they may have different lengths)
        $rsiIndex = !empty($rsi) ? count($rsi) - 1 : 0;
        $macdIndex = !empty($macd['macd']) ? count($macd['macd']) - 1 : 0;
        $emaIndex = !empty($ema12) ? count($ema12) - 1 : 0;
        $smaIndex = !empty($sma20) ? count($sma20) - 1 : 0;
        $bbIndex = !empty($bb['upper']) ? count($bb['upper']) - 1 : 0;
        $volIndex = !empty($volatility) ? count($volatility) - 1 : 0;
        $ichiIndex = !empty($ichimoku['tenkan']) ? count($ichimoku['tenkan']) - 1 : 0;
        
        $sql = "INSERT INTO technical_indicators 
                (symbol, timestamp, rsi, macd, macd_signal, macd_histogram, 
                 ema_12, ema_26, sma_20, sma_50, sma_200,
                 bb_upper, bb_middle, bb_lower, volatility,
                 ichimoku_tenkan, ichimoku_kijun, ichimoku_senkou_a, ichimoku_senkou_b,
                 fib_0, fib_236, fib_382, fib_50, fib_618, fib_100)
                VALUES 
                (:symbol, :timestamp, :rsi, :macd, :macd_signal, :macd_histogram,
                 :ema_12, :ema_26, :sma_20, :sma_50, :sma_200,
                 :bb_upper, :bb_middle, :bb_lower, :volatility,
                 :ichimoku_tenkan, :ichimoku_kijun, :ichimoku_senkou_a, :ichimoku_senkou_b,
                 :fib_0, :fib_236, :fib_382, :fib_50, :fib_618, :fib_100)
                ON DUPLICATE KEY UPDATE
                rsi = VALUES(rsi), macd = VALUES(macd), macd_signal = VALUES(macd_signal)";
        
        executeQuery($sql, [
            ':symbol' => $symbol,
            ':timestamp' => $latest['timestamp'],
            ':rsi' => $rsi[$rsiIndex] ?? null,
            ':macd' => $macd['macd'][$macdIndex] ?? null,
            ':macd_signal' => $macd['signal'][$macdIndex] ?? null,
            ':macd_histogram' => $macd['histogram'][$macdIndex] ?? null,
            ':ema_12' => $ema12[$emaIndex] ?? null,
            ':ema_26' => $ema26[$emaIndex] ?? null,
            ':sma_20' => $sma20[$smaIndex] ?? null,
            ':sma_50' => $sma50[$smaIndex] ?? null,
            ':sma_200' => $sma200[$smaIndex] ?? null,
            ':bb_upper' => $bb['upper'][$bbIndex] ?? null,
            ':bb_middle' => $bb['middle'][$bbIndex] ?? null,
            ':bb_lower' => $bb['lower'][$bbIndex] ?? null,
            ':volatility' => $volatility[$volIndex] ?? null,
            ':ichimoku_tenkan' => $ichimoku['tenkan'][$ichiIndex] ?? null,
            ':ichimoku_kijun' => $ichimoku['kijun'][$ichiIndex] ?? null,
            ':ichimoku_senkou_a' => $ichimoku['senkou_a'][$ichiIndex] ?? null,
            ':ichimoku_senkou_b' => $ichimoku['senkou_b'][$ichiIndex] ?? null,
            ':fib_0' => $fib['fib_0'] ?? null,
            ':fib_236' => $fib['fib_236'] ?? null,
            ':fib_382' => $fib['fib_382'] ?? null,
            ':fib_50' => $fib['fib_50'] ?? null,
            ':fib_618' => $fib['fib_618'] ?? null,
            ':fib_100' => $fib['fib_100'] ?? null
        ]);
        
        $this->output("  ✓ Indicators calculated and saved\n");
        
        return [
            'rsi' => $rsi[$rsiIndex] ?? null,
            'macd' => [
                'macd' => $macd['macd'][$macdIndex] ?? null,
                'signal' => $macd['signal'][$macdIndex] ?? null,
                'histogram' => $macd['histogram'][$macdIndex] ?? null
            ],
            'ema_12' => $ema12[$emaIndex] ?? null,
            'ema_26' => $ema26[$emaIndex] ?? null,
            'sma_20' => $sma20[$smaIndex] ?? null,
            'bollinger' => [
                'upper' => $bb['upper'][$bbIndex] ?? null,
                'middle' => $bb['middle'][$bbIndex] ?? null,
                'lower' => $bb['lower'][$bbIndex] ?? null
            ],
            'volatility' => $volatility[$volIndex] ?? null,
            'ichimoku' => [
                'tenkan' => $ichimoku['tenkan'][$ichiIndex] ?? null,
                'kijun' => $ichimoku['kijun'][$ichiIndex] ?? null,
                'senkou_a' => $ichimoku['senkou_a'][$ichiIndex] ?? null,
                'senkou_b' => $ichimoku['senkou_b'][$ichiIndex] ?? null
            ],
            'fibonacci' => $fib
        ];
    }
    
    /**
     * Calculate RSI
     */
    /**
     * Enhanced RSI with Wilder's Smoothing and Multiple Timeframe Support
     */
    private function calculateRSI($prices, $period = 14) {
        if (count($prices) < 2) {
            return [50]; // Neutral RSI for insufficient data
        }
        
        $rsi = [];
        $gains = [];
        $losses = [];
        
        // Calculate price changes
        for ($i = 1; $i < count($prices); $i++) {
            $change = $prices[$i] - $prices[$i - 1];
            $gains[] = $change > 0 ? $change : 0;
            $losses[] = $change < 0 ? abs($change) : 0;
        }
        
        // Adjust period if not enough data
        $actualPeriod = min($period, count($gains));
        if ($actualPeriod < 2) {
            return [50]; // Neutral RSI
        }
        
        // Enhanced RSI with Wilder's smoothing method for better accuracy
        if (count($gains) >= $actualPeriod) {
            // Calculate initial averages
            $avgGain = array_sum(array_slice($gains, 0, $actualPeriod)) / $actualPeriod;
            $avgLoss = array_sum(array_slice($losses, 0, $actualPeriod)) / $actualPeriod;
            
            // First RSI calculation
            if ($avgLoss == 0) {
                $rsi[] = 100;
            } else {
                $rs = $avgGain / $avgLoss;
                $rsi[] = 100 - (100 / (1 + $rs));
            }
            
            // Subsequent RSI calculations using Wilder's smoothing
            for ($i = $actualPeriod; $i < count($gains); $i++) {
                $avgGain = (($avgGain * ($actualPeriod - 1)) + $gains[$i]) / $actualPeriod;
                $avgLoss = (($avgLoss * ($actualPeriod - 1)) + $losses[$i]) / $actualPeriod;
                
                if ($avgLoss == 0) {
                    $rsi[] = 100;
                } else {
                    $rs = $avgGain / $avgLoss;
                    $rsi[] = 100 - (100 / (1 + $rs));
                }
            }
        }
        
        // If no RSI calculated, return neutral
        return empty($rsi) ? [50] : $rsi;
    }
    
    /**
     * Calculate RSI Divergence (Enhanced Feature)
     */
    private function calculateRSIDivergence($prices, $rsi, $lookback = 20) {
        if (count($prices) < $lookback || count($rsi) < $lookback) {
            return null;
        }
        
        $priceSlice = array_slice($prices, -$lookback);
        $rsiSlice = array_slice($rsi, -$lookback);
        
        // Find price peaks and troughs
        $priceHigh = max($priceSlice);
        $priceLow = min($priceSlice);
        $rsiHigh = max($rsiSlice);
        $rsiLow = min($rsiSlice);
        
        // Detect bullish divergence (price makes lower low, RSI makes higher low)
        $currentPrice = end($priceSlice);
        $currentRSI = end($rsiSlice);
        
        if ($currentPrice <= $priceLow * 1.02 && $currentRSI >= $rsiLow * 1.05) {
            return 'bullish_divergence';
        }
        
        // Detect bearish divergence (price makes higher high, RSI makes lower high)
        if ($currentPrice >= $priceHigh * 0.98 && $currentRSI <= $rsiHigh * 0.95) {
            return 'bearish_divergence';
        }
        
        return null;
    }
    
    /**
     * Enhanced MACD with Adaptive Parameters and Divergence Detection
     */
    private function calculateMACD($prices, $fastPeriod = 12, $slowPeriod = 26, $signalPeriod = 9) {
        if (count($prices) < $slowPeriod) {
            return [
                'macd' => [0],
                'signal' => [0],
                'histogram' => [0],
                'divergence' => null,
                'momentum' => 'neutral'
            ];
        }
        
        $ema12 = $this->calculateEMA($prices, $fastPeriod);
        $ema26 = $this->calculateEMA($prices, $slowPeriod);
        
        $macd = [];
        $minLength = min(count($ema12), count($ema26));
        
        // Calculate MACD line
        for ($i = 0; $i < $minLength; $i++) {
            $macd[] = $ema12[$i] - $ema26[$i];
        }
        
        // Calculate Signal line
        $signal = $this->calculateEMA($macd, $signalPeriod);
        
        // Calculate Histogram
        $histogram = [];
        $signalLength = count($signal);
        for ($i = 0; $i < $signalLength; $i++) {
            $macdIndex = count($macd) - $signalLength + $i;
            if ($macdIndex >= 0) {
                $histogram[] = $macd[$macdIndex] - $signal[$i];
            }
        }
        
        // Enhanced features
        $divergence = $this->calculateMACDDivergence($prices, $macd);
        $momentum = $this->calculateMACDMomentum($histogram);
        
        return [
            'macd' => $macd,
            'signal' => $signal,
            'histogram' => $histogram,
            'divergence' => $divergence,
            'momentum' => $momentum,
            'crossover' => $this->detectMACDCrossover($macd, $signal)
        ];
    }
    
    /**
     * Detect MACD Divergence
     */
    private function calculateMACDDivergence($prices, $macd, $lookback = 20) {
        if (count($prices) < $lookback || count($macd) < $lookback) {
            return null;
        }
        
        $priceSlice = array_slice($prices, -$lookback);
        $macdSlice = array_slice($macd, -$lookback);
        
        $priceHigh = max($priceSlice);
        $priceLow = min($priceSlice);
        $macdHigh = max($macdSlice);
        $macdLow = min($macdSlice);
        
        $currentPrice = end($priceSlice);
        $currentMACD = end($macdSlice);
        
        // Bullish divergence: price lower low, MACD higher low
        if ($currentPrice <= $priceLow * 1.02 && $currentMACD >= $macdLow * 1.1) {
            return 'bullish_divergence';
        }
        
        // Bearish divergence: price higher high, MACD lower high
        if ($currentPrice >= $priceHigh * 0.98 && $currentMACD <= $macdHigh * 0.9) {
            return 'bearish_divergence';
        }
        
        return null;
    }
    
    /**
     * Calculate MACD Momentum
     */
    private function calculateMACDMomentum($histogram) {
        if (count($histogram) < 3) {
            return 'neutral';
        }
        
        $recent = array_slice($histogram, -3);
        
        // Check if histogram is increasing (bullish momentum)
        if ($recent[2] > $recent[1] && $recent[1] > $recent[0]) {
            return 'increasing';
        }
        
        // Check if histogram is decreasing (bearish momentum)
        if ($recent[2] < $recent[1] && $recent[1] < $recent[0]) {
            return 'decreasing';
        }
        
        return 'neutral';
    }
    
    /**
     * Detect MACD Signal Line Crossover
     */
    private function detectMACDCrossover($macd, $signal) {
        if (count($macd) < 2 || count($signal) < 2) {
            return null;
        }
        
        $macdCurrent = end($macd);
        $macdPrevious = $macd[count($macd) - 2];
        $signalCurrent = end($signal);
        $signalPrevious = $signal[count($signal) - 2];
        
        // Bullish crossover: MACD crosses above signal
        if ($macdPrevious <= $signalPrevious && $macdCurrent > $signalCurrent) {
            return 'bullish_crossover';
        }
        
        // Bearish crossover: MACD crosses below signal
        if ($macdPrevious >= $signalPrevious && $macdCurrent < $signalCurrent) {
            return 'bearish_crossover';
        }
        
        return null;
    }
    
    /**
     * Calculate EMA
     */
    private function calculateEMA($prices, $period) {
        $ema = [];
        $multiplier = 2 / ($period + 1);
        
        // First EMA is SMA
        $sma = array_sum(array_slice($prices, 0, $period)) / $period;
        $ema[] = $sma;
        
        // Calculate subsequent EMAs
        for ($i = $period; $i < count($prices); $i++) {
            $ema[] = ($prices[$i] - $ema[count($ema) - 1]) * $multiplier + $ema[count($ema) - 1];
        }
        
        return $ema;
    }
    
    /**
     * Calculate SMA
     */
    private function calculateSMA($prices, $period) {
        if (empty($prices)) {
            return [0];
        }
        
        $priceCount = count($prices);
        $actualPeriod = min($period, $priceCount);
        $sma = [];
        
        for ($i = $actualPeriod - 1; $i < $priceCount; $i++) {
            $sum = array_sum(array_slice($prices, $i - $actualPeriod + 1, $actualPeriod));
            $sma[] = $sum / $actualPeriod;
        }
        
        // If no SMA calculated, return last price
        return empty($sma) ? [end($prices)] : $sma;
    }
    
    /**
     * Calculate Bollinger Bands with better error handling
     */
    private function calculateBollingerBands($prices, $period = 20, $stdDev = 2) {
        $upper = [];
        $middle = [];
        $lower = [];
        
        // Ensure we have enough data
        if (count($prices) < $period) {
            // Not enough data - return current price as all bands
            $lastPrice = end($prices);
            return [
                'upper' => [$lastPrice],
                'middle' => [$lastPrice],
                'lower' => [$lastPrice]
            ];
        }
        
        // Calculate Bollinger Bands for each data point
        for ($i = $period - 1; $i < count($prices); $i++) {
            $slice = array_slice($prices, $i - $period + 1, $period);
            
            // Calculate mean (SMA)
            $mean = array_sum($slice) / $period;
            
            // Calculate standard deviation
            $variance = 0;
            foreach ($slice as $value) {
                $variance += pow($value - $mean, 2);
            }
            $sd = sqrt($variance / $period);
            
            // Calculate bands
            $middle[] = $mean;
            $upper[] = $mean + ($stdDev * $sd);
            $lower[] = $mean - ($stdDev * $sd);
        }
        
        // If still empty, return last price
        if (empty($middle)) {
            $lastPrice = end($prices);
            return [
                'upper' => [$lastPrice],
                'middle' => [$lastPrice],
                'lower' => [$lastPrice]
            ];
        }
        
        return [
            'upper' => $upper,
            'middle' => $middle,
            'lower' => $lower
        ];
    }
    
    /**
     * Calculate Volatility
     */
    private function calculateVolatility($prices, $period = 20) {
        $volatility = [];
        
        for ($i = $period - 1; $i < count($prices); $i++) {
            $slice = array_slice($prices, $i - $period + 1, $period);
            $mean = array_sum($slice) / $period;
            
            $variance = 0;
            foreach ($slice as $value) {
                $variance += pow($value - $mean, 2);
            }
            
            $volatility[] = sqrt($variance / $period);
        }
        
        return $volatility;
    }
    
    /**
     * Calculate Ichimoku Cloud
     */
    private function calculateIchimoku($highs, $lows, $closes) {
        $tenkan = []; // Conversion Line (9 period)
        $kijun = [];  // Base Line (26 period)
        $senkou_a = []; // Leading Span A
        $senkou_b = []; // Leading Span B
        
        // Simplified Ichimoku calculation
        for ($i = 26; $i < count($closes); $i++) {
            $highSlice9 = array_slice($highs, $i - 9, 9);
            $lowSlice9 = array_slice($lows, $i - 9, 9);
            $tenkan[] = (max($highSlice9) + min($lowSlice9)) / 2;
            
            $highSlice26 = array_slice($highs, $i - 26, 26);
            $lowSlice26 = array_slice($lows, $i - 26, 26);
            $kijun[] = (max($highSlice26) + min($lowSlice26)) / 2;
            
            $senkou_a[] = ($tenkan[count($tenkan) - 1] + $kijun[count($kijun) - 1]) / 2;
            
            $highSlice52 = array_slice($highs, max(0, $i - 52), min(52, $i));
            $lowSlice52 = array_slice($lows, max(0, $i - 52), min(52, $i));
            $senkou_b[] = (max($highSlice52) + min($lowSlice52)) / 2;
        }
        
        return [
            'tenkan' => $tenkan,
            'kijun' => $kijun,
            'senkou_a' => $senkou_a,
            'senkou_b' => $senkou_b
        ];
    }
    
    /**
     * Calculate Fibonacci Retracement Levels
     */
    private function calculateFibonacci($prices) {
        $high = max($prices);
        $low = min($prices);
        $diff = $high - $low;
        
        return [
            'fib_0' => $high,
            'fib_236' => $high - ($diff * 0.236),
            'fib_382' => $high - ($diff * 0.382),
            'fib_50' => $high - ($diff * 0.5),
            'fib_618' => $high - ($diff * 0.618),
            'fib_100' => $low
        ];
    }
    
    /**
     * Get price data from database
     */
    private function getPriceData($symbol, $limit = 200) {
        $sql = "SELECT timestamp, open, high, low, close, volume 
                FROM market_prices 
                WHERE symbol = :symbol 
                ORDER BY timestamp DESC 
                LIMIT :limit";
        
        $stmt = getDatabaseConnection()->prepare($sql);
        $stmt->bindValue(':symbol', $symbol, PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Get latest indicators for symbol
     */
    public function getLatestIndicators($symbol) {
        $sql = "SELECT * FROM technical_indicators 
                WHERE symbol = :symbol 
                ORDER BY timestamp DESC 
                LIMIT 1";
        
        return fetchOne($sql, [':symbol' => $symbol]);
    }
}

// CLI Execution
if (php_sapi_name() === 'cli') {
    echo "=== Technical Indicators Calculator ===\n\n";
    
    $calculator = new TechnicalIndicators();
    $symbols = ['BTC', 'ETH', 'BNB'];
    
    foreach ($symbols as $symbol) {
        $calculator->calculateAll($symbol);
    }
    
    echo "\n✓ All indicators calculated\n";
}
?>

