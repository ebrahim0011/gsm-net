<?php
/**
 * News Impact Analyzer
 * 
 * Automated news analysis system that:
 * - Analyzes news impact on market movements
 * - Correlates news with price changes
 * - Predicts market reaction to breaking news
 * - Tracks news sentiment over time
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/enhanced_sentiment_analyzer.php';

class NewsImpactAnalyzer {
    
    private $impactCategories = [
        'regulatory' => [
            'keywords' => ['sec', 'regulation', 'government', 'ban', 'legal', 'compliance', 'law'],
            'impact_multiplier' => 2.5,
            'volatility_factor' => 3.0
        ],
        'institutional' => [
            'keywords' => ['institutional', 'corporate', 'etf', 'blackrock', 'microstrategy', 'tesla'],
            'impact_multiplier' => 2.0,
            'volatility_factor' => 1.5
        ],
        'technical' => [
            'keywords' => ['upgrade', 'fork', 'protocol', 'blockchain', 'network', 'development'],
            'impact_multiplier' => 1.5,
            'volatility_factor' => 1.2
        ],
        'market_structure' => [
            'keywords' => ['exchange', 'listing', 'delisting', 'trading', 'liquidity', 'volume'],
            'impact_multiplier' => 1.8,
            'volatility_factor' => 2.0
        ],
        'adoption' => [
            'keywords' => ['adoption', 'partnership', 'integration', 'mainstream', 'payment'],
            'impact_multiplier' => 1.7,
            'volatility_factor' => 1.3
        ]
    ];
    
    private $urgencyIndicators = [
        'breaking' => 3.0,
        'urgent' => 2.5,
        'alert' => 2.0,
        'developing' => 1.8,
        'just in' => 2.2,
        'live' => 2.0
    ];
    
    /**
     * Analyze news impact on market
     */
    public function analyzeNewsImpact($newsId = null, $hours = 24) {
        if ($newsId) {
            return $this->analyzeSingleNews($newsId);
        } else {
            return $this->analyzeRecentNews($hours);
        }
    }
    
    /**
     * Analyze single news article impact
     */
    private function analyzeSingleNews($newsId) {
        // Get news article
        $news = $this->getNewsById($newsId);
        if (!$news) {
            return ['error' => 'News not found'];
        }
        
        // Perform comprehensive analysis
        $sentimentAnalyzer = new EnhancedSentimentAnalyzer();
        $sentimentAnalysis = $sentimentAnalyzer->analyzeAdvanced(
            $news['title'] . ' ' . $news['summary'],
            $news['source'],
            $news['date']
        );
        
        // Categorize news
        $category = $this->categorizeNews($news['title'] . ' ' . $news['summary']);
        
        // Calculate impact score
        $impactScore = $this->calculateImpactScore($sentimentAnalysis, $category, $news);
        
        // Predict market reaction
        $marketPrediction = $this->predictMarketReaction($impactScore, $sentimentAnalysis, $category);
        
        // Get historical correlation
        $historicalCorrelation = $this->getHistoricalCorrelation($category, $sentimentAnalysis['sentiment']);
        
        return [
            'news_id' => $newsId,
            'title' => $news['title'],
            'category' => $category,
            'sentiment_analysis' => $sentimentAnalysis,
            'impact_score' => $impactScore,
            'market_prediction' => $marketPrediction,
            'historical_correlation' => $historicalCorrelation,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Analyze recent news collectively
     */
    private function analyzeRecentNews($hours) {
        // Get recent news
        $recentNews = $this->getRecentNews($hours);
        
        if (empty($recentNews)) {
            return [
                'total_articles' => 0,
                'overall_impact' => 'minimal',
                'market_direction' => 'neutral'
            ];
        }
        
        $analyses = [];
        $totalImpact = 0;
        $sentimentSum = 0;
        $categoryImpacts = [];
        
        foreach ($recentNews as $news) {
            $analysis = $this->analyzeSingleNews($news['id']);
            $analyses[] = $analysis;
            
            $totalImpact += $analysis['impact_score']['total_score'];
            $sentimentSum += $analysis['sentiment_analysis']['score'];
            
            $category = $analysis['category']['primary'];
            if (!isset($categoryImpacts[$category])) {
                $categoryImpacts[$category] = 0;
            }
            $categoryImpacts[$category] += $analysis['impact_score']['total_score'];
        }
        
        // Calculate overall metrics
        $avgSentiment = count($recentNews) > 0 ? $sentimentSum / count($recentNews) : 0;
        $avgImpact = count($recentNews) > 0 ? $totalImpact / count($recentNews) : 0;
        
        // Determine market direction
        $marketDirection = $this->determineMarketDirection($avgSentiment, $avgImpact, $categoryImpacts);
        
        // Calculate confidence
        $confidence = $this->calculateNewsConfidence($analyses);
        
        return [
            'total_articles' => count($recentNews),
            'analysis_period' => $hours . ' hours',
            'individual_analyses' => $analyses,
            'overall_sentiment' => $avgSentiment,
            'overall_impact' => $this->getImpactLevel($avgImpact),
            'market_direction' => $marketDirection,
            'confidence' => $confidence,
            'category_breakdown' => $categoryImpacts,
            'dominant_category' => $this->getDominantCategory($categoryImpacts),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Categorize news article
     */
    private function categorizeNews($text) {
        $text = strtolower($text);
        $categoryScores = [];
        
        foreach ($this->impactCategories as $category => $data) {
            $score = 0;
            foreach ($data['keywords'] as $keyword) {
                if (strpos($text, $keyword) !== false) {
                    $score += 1;
                }
            }
            $categoryScores[$category] = $score;
        }
        
        // Find primary category
        $primaryCategory = array_keys($categoryScores, max($categoryScores))[0];
        
        // Find secondary categories
        $secondaryCategories = [];
        foreach ($categoryScores as $category => $score) {
            if ($score > 0 && $category !== $primaryCategory) {
                $secondaryCategories[] = $category;
            }
        }
        
        return [
            'primary' => $primaryCategory,
            'secondary' => $secondaryCategories,
            'scores' => $categoryScores
        ];
    }
    
    /**
     * Calculate comprehensive impact score
     */
    private function calculateImpactScore($sentimentAnalysis, $category, $news) {
        $baseScore = abs($sentimentAnalysis['score']) * 100; // 0-100 scale
        
        // Category multiplier
        $categoryMultiplier = $this->impactCategories[$category['primary']]['impact_multiplier'] ?? 1.0;
        
        // Urgency multiplier
        $urgencyMultiplier = $this->calculateUrgencyMultiplier($news['title'] . ' ' . $news['summary']);
        
        // Source credibility multiplier
        $credibilityMultiplier = $sentimentAnalysis['credibility'];
        
        // Market impact multiplier
        $marketImpactMultiplier = $this->getMarketImpactMultiplier($sentimentAnalysis['market_impact']);
        
        // Calculate components
        $sentimentScore = $baseScore * $credibilityMultiplier;
        $categoryScore = $baseScore * $categoryMultiplier;
        $urgencyScore = $baseScore * $urgencyMultiplier;
        $marketScore = $baseScore * $marketImpactMultiplier;
        
        // Total weighted score
        $totalScore = ($sentimentScore * 0.3) + 
                     ($categoryScore * 0.25) + 
                     ($urgencyScore * 0.25) + 
                     ($marketScore * 0.2);
        
        return [
            'total_score' => min(100, $totalScore),
            'components' => [
                'sentiment' => $sentimentScore,
                'category' => $categoryScore,
                'urgency' => $urgencyScore,
                'market_impact' => $marketScore
            ],
            'multipliers' => [
                'category' => $categoryMultiplier,
                'urgency' => $urgencyMultiplier,
                'credibility' => $credibilityMultiplier,
                'market_impact' => $marketImpactMultiplier
            ]
        ];
    }
    
    /**
     * Predict market reaction
     */
    private function predictMarketReaction($impactScore, $sentimentAnalysis, $category) {
        $totalScore = $impactScore['total_score'];
        $sentiment = $sentimentAnalysis['sentiment'];
        $emotion = $sentimentAnalysis['emotion'];
        
        // Base prediction
        $direction = 'neutral';
        $magnitude = 'low';
        $timeframe = 'short';
        
        // Determine direction
        if ($sentiment === 'positive' && $totalScore > 30) {
            $direction = 'bullish';
        } elseif ($sentiment === 'negative' && $totalScore > 30) {
            $direction = 'bearish';
        }
        
        // Determine magnitude
        if ($totalScore > 70) {
            $magnitude = 'high';
        } elseif ($totalScore > 40) {
            $magnitude = 'medium';
        }
        
        // Determine timeframe based on category
        $categoryData = $this->impactCategories[$category['primary']] ?? [];
        $volatilityFactor = $categoryData['volatility_factor'] ?? 1.0;
        
        if ($volatilityFactor > 2.0) {
            $timeframe = 'immediate';
        } elseif ($volatilityFactor > 1.5) {
            $timeframe = 'short';
        } else {
            $timeframe = 'medium';
        }
        
        // Calculate price impact estimate
        $priceImpactPercent = $this->estimatePriceImpact($totalScore, $sentiment, $volatilityFactor);
        
        return [
            'direction' => $direction,
            'magnitude' => $magnitude,
            'timeframe' => $timeframe,
            'estimated_price_impact' => $priceImpactPercent,
            'confidence' => $this->calculatePredictionConfidence($impactScore, $sentimentAnalysis),
            'key_factors' => $this->identifyKeyFactors($sentimentAnalysis, $category)
        ];
    }
    
    /**
     * Get historical correlation for similar news
     */
    private function getHistoricalCorrelation($category, $sentiment) {
        // This would query historical data to find similar news and their market impact
        // For now, return simulated correlation data
        
        $categoryName = $category['primary'];
        
        // Simulated historical correlations
        $correlations = [
            'regulatory' => [
                'positive' => ['avg_impact' => 5.2, 'success_rate' => 0.73],
                'negative' => ['avg_impact' => -8.1, 'success_rate' => 0.81]
            ],
            'institutional' => [
                'positive' => ['avg_impact' => 3.8, 'success_rate' => 0.68],
                'negative' => ['avg_impact' => -2.4, 'success_rate' => 0.59]
            ],
            'technical' => [
                'positive' => ['avg_impact' => 2.1, 'success_rate' => 0.62],
                'negative' => ['avg_impact' => -1.8, 'success_rate' => 0.55]
            ]
        ];
        
        $correlation = $correlations[$categoryName][$sentiment] ?? ['avg_impact' => 0, 'success_rate' => 0.5];
        
        return [
            'category' => $categoryName,
            'sentiment' => $sentiment,
            'historical_avg_impact' => $correlation['avg_impact'],
            'prediction_success_rate' => $correlation['success_rate'],
            'sample_size' => rand(20, 100) // Simulated
        ];
    }
    
    /**
     * Calculate urgency multiplier
     */
    private function calculateUrgencyMultiplier($text) {
        $text = strtolower($text);
        $maxMultiplier = 1.0;
        
        foreach ($this->urgencyIndicators as $indicator => $multiplier) {
            if (strpos($text, $indicator) !== false) {
                $maxMultiplier = max($maxMultiplier, $multiplier);
            }
        }
        
        return $maxMultiplier;
    }
    
    /**
     * Get market impact multiplier
     */
    private function getMarketImpactMultiplier($marketImpact) {
        switch ($marketImpact) {
            case 'high impact':
                return 2.5;
            case 'medium impact':
                return 1.5;
            case 'low impact':
            default:
                return 1.0;
        }
    }
    
    /**
     * Estimate price impact percentage
     */
    private function estimatePriceImpact($totalScore, $sentiment, $volatilityFactor) {
        $baseImpact = ($totalScore / 100) * 5; // Max 5% base impact
        
        // Apply sentiment direction
        if ($sentiment === 'negative') {
            $baseImpact = -$baseImpact;
        }
        
        // Apply volatility factor
        $finalImpact = $baseImpact * $volatilityFactor;
        
        return round($finalImpact, 2);
    }
    
    /**
     * Calculate prediction confidence
     */
    private function calculatePredictionConfidence($impactScore, $sentimentAnalysis) {
        $baseConfidence = $sentimentAnalysis['confidence'];
        
        // Boost confidence for high impact scores
        if ($impactScore['total_score'] > 60) {
            $baseConfidence += 0.2;
        }
        
        // Boost confidence for high credibility
        $baseConfidence += ($sentimentAnalysis['credibility'] - 0.5) * 0.3;
        
        return max(0.1, min(0.95, $baseConfidence));
    }
    
    /**
     * Identify key factors driving the prediction
     */
    private function identifyKeyFactors($sentimentAnalysis, $category) {
        $factors = [];
        
        // Sentiment factors
        if (abs($sentimentAnalysis['score']) > 0.5) {
            $factors[] = 'Strong sentiment signal (' . $sentimentAnalysis['emotion'] . ')';
        }
        
        // Category factors
        $factors[] = 'News category: ' . $category['primary'];
        
        // Market impact factors
        if ($sentimentAnalysis['market_impact'] !== 'low') {
            $factors[] = ucfirst($sentimentAnalysis['market_impact']) . ' market impact expected';
        }
        
        // Urgency factors
        if ($sentimentAnalysis['urgency'] === 'high') {
            $factors[] = 'High urgency news';
        }
        
        return $factors;
    }
    
    // Helper methods
    private function getNewsById($id) {
        $sql = "SELECT * FROM news WHERE id = ?";
        return fetchOne($sql, [$id]);
    }
    
    private function getRecentNews($hours) {
        $sql = "SELECT * FROM news WHERE date >= DATE_SUB(NOW(), INTERVAL ? HOUR) ORDER BY date DESC LIMIT 50";
        return fetchAll($sql, [$hours]);
    }
    
    private function getImpactLevel($score) {
        if ($score > 60) return 'high';
        if ($score > 30) return 'medium';
        return 'low';
    }
    
    private function determineMarketDirection($sentiment, $impact, $categoryImpacts) {
        if ($sentiment > 0.3 && $impact > 30) return 'bullish';
        if ($sentiment < -0.3 && $impact > 30) return 'bearish';
        return 'neutral';
    }
    
    private function calculateNewsConfidence($analyses) {
        if (empty($analyses)) return 0.3;
        
        $totalConfidence = 0;
        foreach ($analyses as $analysis) {
            $totalConfidence += $analysis['sentiment_analysis']['confidence'] ?? 0.5;
        }
        
        return $totalConfidence / count($analyses);
    }
    
    private function getDominantCategory($categoryImpacts) {
        if (empty($categoryImpacts)) return 'none';
        
        return array_keys($categoryImpacts, max($categoryImpacts))[0];
    }
}

