<?php
/**
 * Market Forecast Module
 * توقع السوق المستقبلي بناءً على جميع التحليلات
 * 
 * Combines all analysis tools to provide clear market direction forecast
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/ai_engine.php';
require_once __DIR__ . '/volume_analyzer.php';
require_once __DIR__ . '/fear_greed_index.php';
require_once __DIR__ . '/technical_indicators.php';
require_once __DIR__ . '/sentiment_analyzer.php';
require_once __DIR__ . '/pattern_matcher.php';
require_once __DIR__ . '/auto_learner.php';

class MarketForecast {
    
    private $autoLearner;
    
    /**
     * Get comprehensive market forecast
     */
    public function getMarketForecast($symbol) {
        $lang = $_COOKIE['lang'] ?? 'ar';
        $isArabic = ($lang === 'ar');
        
        // Initialize auto learner
        $this->autoLearner = new AutoLearner();
        
        // جمع جميع التحليلات
        $allAnalysis = $this->gatherAllAnalysis($symbol);
        
        // حساب التوقع الشامل (with dynamic weights)
        $forecast = $this->calculateOverallForecast($allAnalysis, $symbol);
        
        // إنشاء التوصية النهائية
        $recommendation = $this->generateFinalRecommendation($forecast, $allAnalysis, $isArabic);
        
        return [
            'symbol' => $symbol,
            'forecast_period' => '24h', // يمكن تعديله حسب قوة الإشارة
            'direction' => $forecast['direction'],
            'confidence' => $forecast['confidence'],
            'strength' => $forecast['strength'],
            'expected_change' => $forecast['expected_change'],
            'current_price' => $forecast['current_price'],
            'target_price' => $forecast['target_price'],
            'stop_loss' => $forecast['stop_loss'],
            'timeframe' => $forecast['timeframe'],
            'bullish_points' => $forecast['bullish_points'],
            'bearish_points' => $forecast['bearish_points'],
            'max_points' => $forecast['max_points'],
            'recommendation' => $recommendation,
            'supporting_factors' => $forecast['supporting_factors'],
            'risk_factors' => $forecast['risk_factors'],
            'all_analysis' => $allAnalysis,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Gather all analysis from all tools
     */
    private function gatherAllAnalysis($symbol) {
        $analysis = [];
        
        // 1. AI Prediction
        try {
            $ai = new AIEngine();
            $ai->setSilentMode(true);
            $prediction = $ai->getLatestPrediction($symbol);
            $analysis['ai_prediction'] = $prediction;
        } catch (Exception $e) {
            $analysis['ai_prediction'] = null;
        }
        
        // 2. Volume Analysis
        try {
            $volumeAnalyzer = new VolumeAnalyzer();
            $analysis['volume'] = $volumeAnalyzer->getComprehensiveAnalysis($symbol);
        } catch (Exception $e) {
            $analysis['volume'] = null;
        }
        
        // 3. Fear & Greed Index
        try {
            $fearGreed = new FearGreedIndex();
            $analysis['fear_greed'] = $fearGreed->getCurrentIndex();
        } catch (Exception $e) {
            $analysis['fear_greed'] = null;
        }
        
        // 4. Technical Indicators
        try {
            $technical = new TechnicalIndicators();
            $analysis['technical'] = $technical->getLatestIndicators($symbol);
        } catch (Exception $e) {
            $analysis['technical'] = null;
        }
        
        // 5. Market Sentiment
        try {
            $sentiment = new SentimentAnalyzer();
            $analysis['sentiment'] = $sentiment->getMarketSentiment(24);
        } catch (Exception $e) {
            $analysis['sentiment'] = null;
        }
        
        // 6. Historical Patterns
        try {
            $patternMatcher = new PatternMatcher();
            $analysis['patterns'] = $patternMatcher->getLearningSum($symbol);
        } catch (Exception $e) {
            $analysis['patterns'] = null;
        }
        
        return $analysis;
    }
    
    /**
     * Calculate overall forecast from all analysis
     */
    private function calculateOverallForecast($analysis, $symbol) {
        $bullishPoints = 0;
        $bearishPoints = 0;
        $maxPoints = 0;
        
        $supportingFactors = [];
        $riskFactors = [];
        
        // 🧠 Get dynamic weights from auto-learner
        $weights = $this->autoLearner->getCurrentWeights();
        $aiWeight = ($weights['ai_prediction'] ?? 0.25) * 100;
        $volumeWeight = ($weights['volume_analysis'] ?? 0.20) * 100;
        $fearGreedWeight = ($weights['fear_greed'] ?? 0.15) * 100;
        $technicalWeight = ($weights['technical'] ?? 0.20) * 100;
        $sentimentWeight = ($weights['sentiment'] ?? 0.15) * 100;
        $patternsWeight = ($weights['patterns'] ?? 0.05) * 100;
        
        // === AI Prediction (Dynamic Weight) ===
        if ($analysis['ai_prediction']) {
            $maxPoints += $aiWeight;
            $signal = $analysis['ai_prediction']['predicted_signal'] ?? 'sideways';
            $confidence = (float)($analysis['ai_prediction']['confidence_score'] ?? 0);
            
            if ($signal === 'bullish') {
                $points = $aiWeight * $confidence;
                $bullishPoints += $points;
                $supportingFactors[] = [
                    'ar' => "الذكاء الاصطناعي: إشارة صاعدة (ثقة {$this->formatPercent($confidence)})",
                    'en' => "AI: Bullish signal (confidence {$this->formatPercent($confidence)})"
                ];
            } elseif ($signal === 'bearish') {
                $points = $aiWeight * $confidence;
                $bearishPoints += $points;
                $riskFactors[] = [
                    'ar' => "الذكاء الاصطناعي: إشارة هابطة (ثقة {$this->formatPercent($confidence)})",
                    'en' => "AI: Bearish signal (confidence {$this->formatPercent($confidence)})"
                ];
            }
        }
        
        // === Volume Analysis (Dynamic Weight) ===
        if ($analysis['volume']) {
            $maxPoints += $volumeWeight;
            $score = $analysis['volume']['overall_score'] ?? 0;
            $signal = $analysis['volume']['signal'] ?? 'neutral';
            
            if ($score > 0) {
                $bullishPoints += ($score / 100) * $volumeWeight;
                $supportingFactors[] = [
                    'ar' => "تحليل الحجم: {$signal} (نقاط: +{$score})",
                    'en' => "Volume: {$signal} (score: +{$score})"
                ];
            } else {
                $bearishPoints += (abs($score) / 100) * $volumeWeight;
                $riskFactors[] = [
                    'ar' => "تحليل الحجم: {$signal} (نقاط: {$score})",
                    'en' => "Volume: {$signal} (score: {$score})"
                ];
            }
        }
        
        // === Fear & Greed Index (Dynamic Weight) ===
        if ($analysis['fear_greed']) {
            $maxPoints += $fearGreedWeight;
            $value = $analysis['fear_greed']['value'];
            $sentiment = $analysis['fear_greed']['sentiment'];
            
            // Contrarian indicator
            if ($value <= 30) {
                $bullishPoints += $fearGreedWeight;
                $supportingFactors[] = [
                    'ar' => "الخوف والطمع: {$value}/100 (خوف = فرصة شراء)",
                    'en' => "Fear & Greed: {$value}/100 (fear = buy opportunity)"
                ];
            } elseif ($value >= 70) {
                $bearishPoints += $fearGreedWeight;
                $riskFactors[] = [
                    'ar' => "الخوف والطمع: {$value}/100 (طمع = خطر)",
                    'en' => "Fear & Greed: {$value}/100 (greed = risk)"
                ];
            }
        }
        
        // === Technical Indicators (Dynamic Weight) ===
        if ($analysis['technical']) {
            $maxPoints += $technicalWeight;
            $tech = $analysis['technical'];
            $techScore = 0;
            
            // RSI
            if ($tech['rsi'] < 30) {
                $techScore += 5;
                $supportingFactors[] = ['ar' => "RSI: {$tech['rsi']} (متشبع بالبيع)", 'en' => "RSI: {$tech['rsi']} (oversold)"];
            } elseif ($tech['rsi'] > 70) {
                $techScore -= 5;
                $riskFactors[] = ['ar' => "RSI: {$tech['rsi']} (متشبع بالشراء)", 'en' => "RSI: {$tech['rsi']} (overbought)"];
            }
            
            // MACD
            if ($tech['macd'] > $tech['macd_signal']) {
                $techScore += 5;
                $supportingFactors[] = ['ar' => "MACD: إشارة صاعدة", 'en' => "MACD: Bullish"];
            } else {
                $techScore -= 5;
                $riskFactors[] = ['ar' => "MACD: إشارة هابطة", 'en' => "MACD: Bearish"];
            }
            
            // EMA
            if ($tech['ema_12'] > $tech['ema_26']) {
                $techScore += 5;
                $supportingFactors[] = ['ar' => "EMA: اتجاه صاعد", 'en' => "EMA: Uptrend"];
            } else {
                $techScore -= 5;
                $riskFactors[] = ['ar' => "EMA: اتجاه هابط", 'en' => "EMA: Downtrend"];
            }
            
            if ($techScore > 0) {
                $bullishPoints += ($techScore / 15) * $technicalWeight;
            } else {
                $bearishPoints += (abs($techScore) / 15) * $technicalWeight;
            }
        }
        
        // === Market Sentiment (Dynamic Weight) ===
        if ($analysis['sentiment']) {
            $maxPoints += $sentimentWeight;
            $score = $analysis['sentiment']['average_score'];
            $positive = $analysis['sentiment']['positive_percentage'];
            
            if ($score > 0) {
                $bullishPoints += ($positive / 100) * $sentimentWeight;
                $supportingFactors[] = [
                    'ar' => "معنويات السوق: إيجابية {$positive}%",
                    'en' => "Sentiment: Positive {$positive}%"
                ];
            } else {
                $negative = $analysis['sentiment']['negative_percentage'];
                $bearishPoints += ($negative / 100) * $sentimentWeight;
                $riskFactors[] = [
                    'ar' => "معنويات السوق: سلبية {$negative}%",
                    'en' => "Sentiment: Negative {$negative}%"
                ];
            }
        }
        
        // === Historical Patterns (Dynamic Weight) ===
        if ($analysis['patterns'] && isset($analysis['patterns']['prediction'])) {
            $maxPoints += $patternsWeight;
            $direction = $analysis['patterns']['prediction']['direction'] ?? 'sideways';
            $confidence = $analysis['patterns']['prediction']['confidence'] ?? 0;
            
            if ($direction === 'bullish') {
                $bullishPoints += $patternsWeight * $confidence;
            } elseif ($direction === 'bearish') {
                $bearishPoints += $patternsWeight * $confidence;
            }
        }
        
        // === Calculate Final Direction ===
        $totalPoints = $bullishPoints + $bearishPoints;
        
        if ($totalPoints == 0) {
            $direction = 'sideways';
            $confidence = 0.3;
            $expectedChange = 0;
        } else {
            $bullishProb = $bullishPoints / $totalPoints;
            $bearishProb = $bearishPoints / $totalPoints;
            
            if ($bullishProb > 0.60) {
                $direction = 'bullish';
                $confidence = $bullishProb;
                $expectedChange = 2 + ($bullishProb * 5); // 2-7%
            } elseif ($bearishProb > 0.60) {
                $direction = 'bearish';
                $confidence = $bearishProb;
                $expectedChange = -(2 + ($bearishProb * 5)); // -2 to -7%
            } else {
                $direction = 'sideways';
                $confidence = 0.5;
                $expectedChange = 0;
            }
        }
        
        // Calculate strength
        $strength = $this->calculateStrength($confidence, $bullishPoints, $bearishPoints);
        
        // Calculate timeframe based on strength
        $timeframe = $this->calculateTimeframe($strength, $confidence);
        
        // Get current price
        $currentPrice = $this->getCurrentPrice($symbol);
        
        // Calculate target and stop loss
        $targetPrice = $currentPrice * (1 + ($expectedChange / 100));
        $stopLoss = $direction === 'bullish' ? 
            $currentPrice * 0.97 : // -3% for bullish
            $currentPrice * 1.03;  // +3% for bearish
        
        return [
            'direction' => $direction,
            'confidence' => round($confidence, 4),
            'strength' => $strength,
            'expected_change' => round($expectedChange, 2),
            'current_price' => $currentPrice,
            'target_price' => round($targetPrice, 2),
            'stop_loss' => round($stopLoss, 2),
            'timeframe' => $timeframe,
            'bullish_points' => round($bullishPoints, 2),
            'bearish_points' => round($bearishPoints, 2),
            'max_points' => $maxPoints,
            'supporting_factors' => $supportingFactors,
            'risk_factors' => $riskFactors
        ];
    }
    
    /**
     * Calculate strength level
     */
    private function calculateStrength($confidence, $bullishPoints, $bearishPoints) {
        $diff = abs($bullishPoints - $bearishPoints);
        
        if ($confidence > 0.85 && $diff > 50) return 'very_strong';
        if ($confidence > 0.75 && $diff > 35) return 'strong';
        if ($confidence > 0.65 && $diff > 20) return 'moderate';
        if ($confidence > 0.55) return 'weak';
        return 'very_weak';
    }
    
    /**
     * Calculate recommended timeframe
     */
    private function calculateTimeframe($strength, $confidence) {
        if ($strength === 'very_strong' && $confidence > 0.85) {
            return ['hours' => 48, 'label_ar' => '48 ساعة', 'label_en' => '48 hours'];
        }
        if ($strength === 'strong' && $confidence > 0.75) {
            return ['hours' => 36, 'label_ar' => '36 ساعة', 'label_en' => '36 hours'];
        }
        if ($strength === 'moderate') {
            return ['hours' => 24, 'label_ar' => '24 ساعة', 'label_en' => '24 hours'];
        }
        if ($strength === 'weak') {
            return ['hours' => 12, 'label_ar' => '12 ساعة', 'label_en' => '12 hours'];
        }
        return ['hours' => 6, 'label_ar' => '6 ساعات', 'label_en' => '6 hours'];
    }
    
    /**
     * Get current price from analysis
     */
    private function getCurrentPrice($symbol) {
        // Try from database first
        $sql = "SELECT close FROM market_prices WHERE symbol = ? ORDER BY timestamp DESC LIMIT 1";
        $result = fetchOne($sql, [$symbol]);
        
        if ($result && $result['close'] > 0) {
            return (float)$result['close'];
        }
        
        // Fallback: Try to fetch from Binance API directly
        try {
            $apiUrl = "https://api.binance.com/api/v3/ticker/price?symbol={$symbol}USDT";
            $response = @file_get_contents($apiUrl);
            if ($response) {
                $data = json_decode($response, true);
                if (isset($data['price'])) {
                    return (float)$data['price'];
                }
            }
        } catch (Exception $e) {
            // Ignore
        }
        
        return 0;
    }
    
    /**
     * Generate final recommendation
     */
    private function generateFinalRecommendation($forecast, $analysis, $isArabic = true) {
        $direction = $forecast['direction'];
        $confidence = $forecast['confidence'];
        $strength = $forecast['strength'];
        $change = $forecast['expected_change'];
        $timeframe = $forecast['timeframe'][$isArabic ? 'label_ar' : 'label_en'];
        
        $rec = [];
        
        // Main recommendation
        if ($direction === 'bullish') {
            if ($strength === 'very_strong') {
                $rec['title'] = $isArabic ? 
                    "🚀 فرصة شراء قوية جداً" : 
                    "🚀 Very Strong Buy Opportunity";
                $rec['action'] = $isArabic ? "شراء" : "BUY";
                $rec['action_color'] = 'green';
            } elseif ($strength === 'strong') {
                $rec['title'] = $isArabic ? 
                    "📈 فرصة شراء قوية" : 
                    "📈 Strong Buy Opportunity";
                $rec['action'] = $isArabic ? "شراء" : "BUY";
                $rec['action_color'] = 'green';
            } else {
                $rec['title'] = $isArabic ? 
                    "📊 فرصة شراء متوسطة" : 
                    "📊 Moderate Buy Opportunity";
                $rec['action'] = $isArabic ? "شراء حذر" : "CAUTIOUS BUY";
                $rec['action_color'] = 'lightgreen';
            }
        } elseif ($direction === 'bearish') {
            if ($strength === 'very_strong') {
                $rec['title'] = $isArabic ? 
                    "⚠️ خطر هبوط قوي جداً" : 
                    "⚠️ Very Strong Sell Signal";
                $rec['action'] = $isArabic ? "بيع / خروج" : "SELL / EXIT";
                $rec['action_color'] = 'red';
            } elseif ($strength === 'strong') {
                $rec['title'] = $isArabic ? 
                    "📉 خطر هبوط قوي" : 
                    "📉 Strong Sell Signal";
                $rec['action'] = $isArabic ? "بيع" : "SELL";
                $rec['action_color'] = 'red';
            } else {
                $rec['title'] = $isArabic ? 
                    "⚠️ خطر هبوط متوسط" : 
                    "⚠️ Moderate Sell Signal";
                $rec['action'] = $isArabic ? "بيع حذر" : "CAUTIOUS SELL";
                $rec['action_color'] = 'orange';
            }
        } else {
            $rec['title'] = $isArabic ? 
                "⏸️ انتظر - لا يوجد اتجاه واضح" : 
                "⏸️ Wait - No Clear Direction";
            $rec['action'] = $isArabic ? "انتظر" : "WAIT";
            $rec['action_color'] = 'gray';
        }
        
        // Description
        if ($direction !== 'sideways') {
            $rec['description'] = $isArabic ?
                "التحليل الشامل يشير إلى اتجاه {$this->translateDirection($direction, true)} بثقة {$this->formatPercent($confidence)}. " .
                "التغير المتوقع {$change}% خلال {$timeframe}." :
                "Comprehensive analysis indicates {$direction} direction with {$this->formatPercent($confidence)} confidence. " .
                "Expected change {$change}% within {$timeframe}.";
        } else {
            $rec['description'] = $isArabic ?
                "السوق في حالة تماسك. لا توجد إشارات قوية كافية لاتخاذ قرار. من الأفضل الانتظار." :
                "Market is consolidating. No strong signals to take action. Better to wait.";
        }
        
        // Risk management
        if ($direction !== 'sideways') {
            $rec['risk_management'] = [
                'stop_loss' => $forecast['stop_loss'],
                'target' => $forecast['target_price'],
                'advice' => $isArabic ?
                    "استخدم وقف خسارة عند {$forecast['stop_loss']} والهدف {$forecast['target_price']}" :
                    "Use stop loss at {$forecast['stop_loss']} and target {$forecast['target_price']}"
            ];
        }
        
        return $rec;
    }
    
    /**
     * Helper functions
     */
    private function formatPercent($value) {
        return round($value * 100, 1) . '%';
    }
    
    private function translateDirection($direction, $isArabic) {
        $map = [
            'bullish' => ['ar' => 'صاعد', 'en' => 'bullish'],
            'bearish' => ['ar' => 'هابط', 'en' => 'bearish'],
            'sideways' => ['ar' => 'جانبي', 'en' => 'sideways']
        ];
        return $map[$direction][$isArabic ? 'ar' : 'en'];
    }
}
?>

