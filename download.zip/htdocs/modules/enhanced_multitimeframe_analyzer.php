<?php
/**
 * Enhanced Multi-Timeframe Analysis System
 * 
 * Advanced analysis across multiple timeframes with AI-powered confluence detection
 * Supports: 1m, 5m, 15m, 1h, 4h, 1d, 1w timeframes
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/technical_indicators.php';
require_once __DIR__ . '/sentiment_analyzer.php';

class EnhancedMultiTimeframeAnalyzer {
    
    private $timeframes = [
        '1m' => 1,      // 1 minute
        '5m' => 5,      // 5 minutes  
        '15m' => 15,    // 15 minutes
        '1h' => 60,     // 1 hour
        '4h' => 240,    // 4 hours
        '1d' => 1440,   // 1 day
        '1w' => 10080   // 1 week
    ];
    
    private $weights = [
        '1m' => 0.05,   // Short-term noise
        '5m' => 0.10,   // Scalping signals
        '15m' => 0.15,  // Day trading
        '1h' => 0.20,   // Swing trading
        '4h' => 0.25,   // Position trading
        '1d' => 0.20,   // Long-term trend
        '1w' => 0.05    // Major trend confirmation
    ];
    
    /**
     * Perform comprehensive multi-timeframe analysis
     */
    public function analyzeMultiTimeframe($symbol) {
        $results = [];
        $confluences = [];
        $divergences = [];
        
        foreach ($this->timeframes as $tf => $minutes) {
            $analysis = $this->analyzeTimeframe($symbol, $tf, $minutes);
            $results[$tf] = $analysis;
            
            // Detect confluences and divergences
            if (!empty($results)) {
                $confluences = $this->detectConfluences($results);
                $divergences = $this->detectDivergences($results);
            }
        }
        
        // Calculate overall signal strength
        $overallSignal = $this->calculateOverallSignal($results);
        $riskLevel = $this->assessRiskLevel($results, $divergences);
        
        return [
            'timeframe_analysis' => $results,
            'confluences' => $confluences,
            'divergences' => $divergences,
            'overall_signal' => $overallSignal,
            'risk_level' => $riskLevel,
            'recommendation' => $this->generateRecommendation($overallSignal, $riskLevel),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Analyze individual timeframe
     */
    private function analyzeTimeframe($symbol, $timeframe, $minutes) {
        // Get price data for this timeframe
        $priceData = $this->getPriceDataForTimeframe($symbol, $minutes, 200);
        
        if (empty($priceData)) {
            return [
                'signal' => 'neutral',
                'strength' => 0,
                'confidence' => 0,
                'indicators' => []
            ];
        }
        
        $closes = array_column($priceData, 'close');
        $highs = array_column($priceData, 'high');
        $lows = array_column($priceData, 'low');
        
        // Calculate technical indicators
        $technical = new TechnicalIndicators();
        $technical->setSilentMode(true);
        
        $rsi = $this->calculateRSI($closes);
        $macd = $this->calculateMACD($closes);
        $ema20 = $this->calculateEMA($closes, 20);
        $ema50 = $this->calculateEMA($closes, 50);
        $bb = $this->calculateBollingerBands($closes);
        
        // Analyze each indicator
        $indicators = [
            'rsi' => $this->analyzeRSI($rsi),
            'macd' => $this->analyzeMACD($macd),
            'ema_crossover' => $this->analyzeEMACrossover($ema20, $ema50),
            'bollinger' => $this->analyzeBollingerBands($closes, $bb),
            'support_resistance' => $this->analyzeSupportResistance($closes, $highs, $lows)
        ];
        
        // Calculate timeframe signal
        $signal = $this->calculateTimeframeSignal($indicators);
        $strength = $this->calculateSignalStrength($indicators);
        $confidence = $this->calculateConfidence($indicators, count($priceData));
        
        return [
            'timeframe' => $timeframe,
            'signal' => $signal,
            'strength' => $strength,
            'confidence' => $confidence,
            'indicators' => $indicators,
            'price_action' => $this->analyzePriceAction($priceData)
        ];
    }
    
    /**
     * Enhanced RSI Analysis
     */
    private function analyzeRSI($rsi) {
        if (empty($rsi)) {
            return ['signal' => 'neutral', 'value' => 50, 'condition' => 'insufficient_data'];
        }
        
        $currentRSI = end($rsi);
        $signal = 'neutral';
        $condition = 'normal';
        
        // Enhanced RSI levels
        if ($currentRSI >= 80) {
            $signal = 'bearish';
            $condition = 'extremely_overbought';
        } elseif ($currentRSI >= 70) {
            $signal = 'bearish';
            $condition = 'overbought';
        } elseif ($currentRSI <= 20) {
            $signal = 'bullish';
            $condition = 'extremely_oversold';
        } elseif ($currentRSI <= 30) {
            $signal = 'bullish';
            $condition = 'oversold';
        } elseif ($currentRSI >= 55) {
            $signal = 'bullish';
            $condition = 'bullish_momentum';
        } elseif ($currentRSI <= 45) {
            $signal = 'bearish';
            $condition = 'bearish_momentum';
        }
        
        // Check for divergences
        $divergence = $this->detectRSIDivergence($rsi);
        
        return [
            'signal' => $signal,
            'value' => $currentRSI,
            'condition' => $condition,
            'divergence' => $divergence,
            'strength' => $this->calculateRSIStrength($currentRSI)
        ];
    }
    
    /**
     * Enhanced MACD Analysis
     */
    private function analyzeMACD($macd) {
        if (empty($macd['macd']) || empty($macd['signal'])) {
            return ['signal' => 'neutral', 'condition' => 'insufficient_data'];
        }
        
        $macdLine = end($macd['macd']);
        $signalLine = end($macd['signal']);
        $histogram = end($macd['histogram']);
        
        $signal = 'neutral';
        $condition = 'consolidation';
        
        // MACD Signal Analysis
        if ($macdLine > $signalLine && $histogram > 0) {
            $signal = 'bullish';
            $condition = $histogram > 0.001 ? 'strong_bullish' : 'weak_bullish';
        } elseif ($macdLine < $signalLine && $histogram < 0) {
            $signal = 'bearish';
            $condition = $histogram < -0.001 ? 'strong_bearish' : 'weak_bearish';
        }
        
        // Check for crossovers
        $crossover = $this->detectMACDCrossover($macd);
        
        return [
            'signal' => $signal,
            'condition' => $condition,
            'macd_value' => $macdLine,
            'signal_value' => $signalLine,
            'histogram' => $histogram,
            'crossover' => $crossover,
            'strength' => abs($histogram) * 1000 // Normalize histogram strength
        ];
    }
    
    /**
     * Detect confluences across timeframes
     */
    private function detectConfluences($results) {
        $confluences = [];
        $signals = [];
        
        foreach ($results as $tf => $analysis) {
            $signals[$tf] = $analysis['signal'];
        }
        
        // Major timeframe confluence (4h, 1d, 1w)
        $majorTimeframes = ['4h', '1d', '1w'];
        $majorSignals = array_intersect_key($signals, array_flip($majorTimeframes));
        
        if (count(array_unique($majorSignals)) === 1 && !in_array('neutral', $majorSignals)) {
            $confluences[] = [
                'type' => 'major_timeframe_confluence',
                'signal' => reset($majorSignals),
                'timeframes' => $majorTimeframes,
                'strength' => 0.8
            ];
        }
        
        // All timeframe confluence
        $bullishCount = array_count_values($signals)['bullish'] ?? 0;
        $bearishCount = array_count_values($signals)['bearish'] ?? 0;
        $totalSignals = count($signals);
        
        if ($bullishCount >= $totalSignals * 0.7) {
            $confluences[] = [
                'type' => 'multi_timeframe_bullish',
                'signal' => 'bullish',
                'agreement' => $bullishCount / $totalSignals,
                'strength' => 0.9
            ];
        } elseif ($bearishCount >= $totalSignals * 0.7) {
            $confluences[] = [
                'type' => 'multi_timeframe_bearish',
                'signal' => 'bearish',
                'agreement' => $bearishCount / $totalSignals,
                'strength' => 0.9
            ];
        }
        
        return $confluences;
    }
    
    /**
     * Detect divergences across timeframes
     */
    private function detectDivergences($results) {
        $divergences = [];
        
        // Check for conflicting signals between major timeframes
        if (isset($results['1d']) && isset($results['4h']) && isset($results['1h'])) {
            $dailySignal = $results['1d']['signal'];
            $fourHourSignal = $results['4h']['signal'];
            $hourlySignal = $results['1h']['signal'];
            
            // Major divergence: Daily vs 4H vs 1H
            if ($dailySignal !== $fourHourSignal && $fourHourSignal !== $hourlySignal) {
                $divergences[] = [
                    'type' => 'major_timeframe_divergence',
                    'timeframes' => ['1d', '4h', '1h'],
                    'signals' => [$dailySignal, $fourHourSignal, $hourlySignal],
                    'risk_level' => 'high'
                ];
            }
        }
        
        return $divergences;
    }
    
    /**
     * Calculate overall signal from all timeframes
     */
    private function calculateOverallSignal($results) {
        $weightedScore = 0;
        $totalWeight = 0;
        
        foreach ($results as $tf => $analysis) {
            $weight = $this->weights[$tf] ?? 0;
            $score = 0;
            
            switch ($analysis['signal']) {
                case 'bullish':
                    $score = $analysis['strength'] * $analysis['confidence'];
                    break;
                case 'bearish':
                    $score = -$analysis['strength'] * $analysis['confidence'];
                    break;
                case 'neutral':
                default:
                    $score = 0;
                    break;
            }
            
            $weightedScore += $score * $weight;
            $totalWeight += $weight;
        }
        
        if ($totalWeight === 0) {
            return ['signal' => 'neutral', 'strength' => 0, 'confidence' => 0];
        }
        
        $finalScore = $weightedScore / $totalWeight;
        
        // Determine signal
        $signal = 'neutral';
        if ($finalScore > 0.3) {
            $signal = 'bullish';
        } elseif ($finalScore < -0.3) {
            $signal = 'bearish';
        }
        
        return [
            'signal' => $signal,
            'strength' => abs($finalScore),
            'confidence' => min(0.95, abs($finalScore) + 0.2),
            'score' => $finalScore
        ];
    }
    
    /**
     * Generate trading recommendation
     */
    private function generateRecommendation($overallSignal, $riskLevel) {
        $signal = $overallSignal['signal'];
        $strength = $overallSignal['strength'];
        $confidence = $overallSignal['confidence'];
        
        if ($riskLevel === 'high') {
            return [
                'action' => 'wait',
                'reason' => 'High risk due to timeframe divergences',
                'confidence' => max(0.3, $confidence - 0.4)
            ];
        }
        
        if ($signal === 'bullish' && $strength > 0.6 && $confidence > 0.7) {
            return [
                'action' => 'buy',
                'reason' => 'Strong bullish confluence across multiple timeframes',
                'confidence' => $confidence
            ];
        } elseif ($signal === 'bearish' && $strength > 0.6 && $confidence > 0.7) {
            return [
                'action' => 'sell',
                'reason' => 'Strong bearish confluence across multiple timeframes',
                'confidence' => $confidence
            ];
        } elseif ($signal === 'bullish' && $strength > 0.4) {
            return [
                'action' => 'buy_small',
                'reason' => 'Moderate bullish signal',
                'confidence' => $confidence
            ];
        } elseif ($signal === 'bearish' && $strength > 0.4) {
            return [
                'action' => 'sell_small',
                'reason' => 'Moderate bearish signal',
                'confidence' => $confidence
            ];
        }
        
        return [
            'action' => 'hold',
            'reason' => 'No clear directional bias',
            'confidence' => $confidence
        ];
    }
    
    // Helper methods for calculations
    private function calculateRSI($prices, $period = 14) {
        // Simplified RSI calculation
        if (count($prices) < $period + 1) return [];
        
        $gains = [];
        $losses = [];
        
        for ($i = 1; $i < count($prices); $i++) {
            $change = $prices[$i] - $prices[$i - 1];
            $gains[] = $change > 0 ? $change : 0;
            $losses[] = $change < 0 ? abs($change) : 0;
        }
        
        $rsi = [];
        for ($i = $period - 1; $i < count($gains); $i++) {
            $avgGain = array_sum(array_slice($gains, $i - $period + 1, $period)) / $period;
            $avgLoss = array_sum(array_slice($losses, $i - $period + 1, $period)) / $period;
            
            if ($avgLoss == 0) {
                $rsi[] = 100;
            } else {
                $rs = $avgGain / $avgLoss;
                $rsi[] = 100 - (100 / (1 + $rs));
            }
        }
        
        return $rsi;
    }
    
    private function calculateMACD($prices) {
        $ema12 = $this->calculateEMA($prices, 12);
        $ema26 = $this->calculateEMA($prices, 26);
        
        $macd = [];
        $minLength = min(count($ema12), count($ema26));
        
        for ($i = 0; $i < $minLength; $i++) {
            $macd[] = $ema12[$i] - $ema26[$i];
        }
        
        $signal = $this->calculateEMA($macd, 9);
        $histogram = [];
        
        for ($i = 0; $i < count($signal); $i++) {
            $histogram[] = $macd[$i] - $signal[$i];
        }
        
        return [
            'macd' => $macd,
            'signal' => $signal,
            'histogram' => $histogram
        ];
    }
    
    private function calculateEMA($prices, $period) {
        if (count($prices) < $period) return [];
        
        $ema = [];
        $multiplier = 2 / ($period + 1);
        
        // First EMA is SMA
        $sma = array_sum(array_slice($prices, 0, $period)) / $period;
        $ema[] = $sma;
        
        // Calculate subsequent EMAs
        for ($i = $period; $i < count($prices); $i++) {
            $ema[] = ($prices[$i] - $ema[count($ema) - 1]) * $multiplier + $ema[count($ema) - 1];
        }
        
        return $ema;
    }
    
    private function getPriceDataForTimeframe($symbol, $minutes, $limit) {
        // This would need to be implemented based on your data structure
        // For now, return sample data structure
        return [];
    }
    
    private function calculateTimeframeSignal($indicators) {
        $bullishCount = 0;
        $bearishCount = 0;
        
        foreach ($indicators as $indicator) {
            if ($indicator['signal'] === 'bullish') $bullishCount++;
            if ($indicator['signal'] === 'bearish') $bearishCount++;
        }
        
        if ($bullishCount > $bearishCount) return 'bullish';
        if ($bearishCount > $bullishCount) return 'bearish';
        return 'neutral';
    }
    
    private function calculateSignalStrength($indicators) {
        $totalStrength = 0;
        $count = 0;
        
        foreach ($indicators as $indicator) {
            if (isset($indicator['strength'])) {
                $totalStrength += $indicator['strength'];
                $count++;
            }
        }
        
        return $count > 0 ? $totalStrength / $count : 0;
    }
    
    private function calculateConfidence($indicators, $dataPoints) {
        $baseConfidence = min(0.9, $dataPoints / 100); // More data = higher confidence
        $indicatorAgreement = $this->calculateIndicatorAgreement($indicators);
        
        return min(0.95, $baseConfidence * $indicatorAgreement);
    }
    
    private function calculateIndicatorAgreement($indicators) {
        $signals = [];
        foreach ($indicators as $indicator) {
            $signals[] = $indicator['signal'];
        }
        
        $signalCounts = array_count_values($signals);
        $maxCount = max($signalCounts);
        $totalCount = count($signals);
        
        return $maxCount / $totalCount;
    }
    
    private function assessRiskLevel($results, $divergences) {
        if (!empty($divergences)) {
            foreach ($divergences as $div) {
                if ($div['risk_level'] === 'high') {
                    return 'high';
                }
            }
        }
        
        // Check for conflicting signals
        $signals = [];
        foreach ($results as $analysis) {
            $signals[] = $analysis['signal'];
        }
        
        $signalCounts = array_count_values($signals);
        $neutralCount = $signalCounts['neutral'] ?? 0;
        $totalSignals = count($signals);
        
        if ($neutralCount / $totalSignals > 0.5) {
            return 'medium';
        }
        
        return 'low';
    }
    
    // Additional helper methods would be implemented here...
    private function detectRSIDivergence($rsi) { return null; }
    private function detectMACDCrossover($macd) { return null; }
    private function analyzeEMACrossover($ema20, $ema50) { return ['signal' => 'neutral']; }
    private function analyzeBollingerBands($closes, $bb) { return ['signal' => 'neutral']; }
    private function analyzeSupportResistance($closes, $highs, $lows) { return ['signal' => 'neutral']; }
    private function analyzePriceAction($priceData) { return ['pattern' => 'none']; }
    private function calculateBollingerBands($closes) { return ['upper' => [], 'middle' => [], 'lower' => []]; }
    private function calculateRSIStrength($rsi) { return abs($rsi - 50) / 50; }
}

