<?php
/**
 * AI Continuous Learning Module
 * 
 * Tracks prediction accuracy and improves model over time
 * Analyzes past predictions vs actual outcomes
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/pattern_matcher.php';
require_once __DIR__ . '/auto_learner.php';

class AILearning {
    
    private $patternMatcher;
    private $autoLearner;
    private $silentMode = false;
    
    public function __construct() {
        $this->patternMatcher = new PatternMatcher();
        $this->autoLearner = new AutoLearner();
    }
    
    /**
     * Enable/disable silent mode (no echo output)
     */
    public function setSilentMode($silent = true) {
        $this->silentMode = $silent;
    }
    
    /**
     * Echo only if not in silent mode
     */
    private function output($message) {
        if (!$this->silentMode) {
            echo $message;
        }
    }
    
    /**
     * Learn from historical events and store patterns
     */
    public function learnFromHistory($symbol = null, $daysBack = 365) {
        $this->output("=== Learning from Historical Data ===\n\n");
        
        // Get events that happened at least 7 days ago (so we have outcome data)
        $whereSymbol = $symbol ? "AND mp.symbol = '$symbol'" : "";
        
        $sql = "SELECT DISTINCT ne.id, ne.title, ne.date, mp.symbol
                FROM news_events ne
                CROSS JOIN market_prices mp ON DATE(mp.timestamp) = DATE(ne.date)
                LEFT JOIN historical_patterns hp ON hp.news_id = ne.id AND hp.symbol = mp.symbol
                WHERE ne.date >= DATE_SUB(NOW(), INTERVAL ? DAY)
                AND ne.date <= DATE_SUB(NOW(), INTERVAL 1 DAY)
                AND hp.id IS NULL
                $whereSymbol
                ORDER BY ne.date DESC
                LIMIT 100";
        
        $events = fetchAll($sql, [$daysBack]);
        
        $stored = 0;
        foreach ($events as $event) {
            if ($this->patternMatcher->storeHistoricalPattern($event['id'], $event['symbol'])) {
                $stored++;
                $this->output("✓ Stored pattern: {$event['title']} ({$event['symbol']})\n");
            }
        }
        
        $this->output("\n✅ Learned from {$stored} historical events\n");
        
        // Update pattern category statistics
        $this->updateCategoryStatistics();
        
        return $stored;
    }
    
    /**
     * Analyze current event and find similar historical patterns
     */
    public function analyzeCurrentEvent($newsId, $symbol) {
        $this->output("=== Analyzing Current Event ===\n\n");
        
        $news = fetchOne("SELECT * FROM news_events WHERE id = ?", [$newsId]);
        if (!$news) {
            $this->output("❌ News not found\n");
            return null;
        }
        
        $this->output("Event: {$news['title']}\n");
        $this->output("Date: {$news['date']}\n");
        $this->output("Sentiment: {$news['sentiment']}\n\n");
        
        // Find similar patterns
        $similarPatterns = $this->patternMatcher->findSimilarPatterns($newsId, $symbol, 10);
        
        if (empty($similarPatterns)) {
            $this->output("ℹ️ No similar historical patterns found\n");
            return null;
        }
        
        $this->output("Found " . count($similarPatterns) . " similar historical patterns:\n\n");
        
        // Aggregate predictions
        $predictions = [
            'bullish' => ['count' => 0, 'total_change' => 0, 'confidence' => 0],
            'bearish' => ['count' => 0, 'total_change' => 0, 'confidence' => 0],
            'sideways' => ['count' => 0, 'total_change' => 0, 'confidence' => 0]
        ];
        
        foreach ($similarPatterns as $i => $match) {
            $pattern = $match['pattern'];
            $similarity = $match['similarity'];
            
            $this->output(($i + 1) . ". {$pattern['event_type']} - " . date('Y-m-d', strtotime($pattern['pattern_date'])) . "\n");
            $this->output("   Similarity: " . ($similarity['overall'] * 100) . "%\n");
            $this->output("   Direction: {$pattern['market_direction']}\n");
            $this->output("   Price Change (24h): {$pattern['price_change_24h']}%\n");
            $this->output("   Confidence: " . ($match['confidence'] * 100) . "%\n\n");
            
            // Aggregate
            $dir = $pattern['market_direction'];
            $predictions[$dir]['count']++;
            $predictions[$dir]['total_change'] += $pattern['price_change_24h'];
            $predictions[$dir]['confidence'] += $match['confidence'];
            
            // Store the match
            $this->patternMatcher->storePatternMatch(
                $newsId,
                $pattern['id'],
                $symbol,
                $similarity,
                [
                    'direction' => $pattern['market_direction'],
                    'price_change_24h' => $pattern['price_change_24h'],
                    'confidence' => $match['confidence']
                ]
            );
        }
        
        // Determine overall prediction
        $maxCount = 0;
        $predictedDirection = 'sideways';
        foreach ($predictions as $dir => $data) {
            if ($data['count'] > $maxCount) {
                $maxCount = $data['count'];
                $predictedDirection = $dir;
            }
        }
        
        $predData = $predictions[$predictedDirection];
        $avgChange = $predData['count'] > 0 ? $predData['total_change'] / $predData['count'] : 0;
        $avgConfidence = $predData['count'] > 0 ? $predData['confidence'] / $predData['count'] : 0;
        
        $this->output("=== PREDICTION BASED ON HISTORICAL PATTERNS ===\n");
        $this->output("Direction: " . strtoupper($predictedDirection) . "\n");
        $this->output("Expected Price Change (24h): " . round($avgChange, 2) . "%\n");
        $this->output("Confidence: " . round($avgConfidence * 100, 1) . "%\n");
        $this->output("Based on: {$predData['count']} similar patterns\n");
        
        return [
            'predicted_direction' => $predictedDirection,
            'predicted_change' => $avgChange,
            'confidence' => $avgConfidence,
            'pattern_count' => $predData['count'],
            'similar_patterns' => $similarPatterns
        ];
    }
    
    /**
     * Update category statistics
     */
    private function updateCategoryStatistics() {
        $sql = "UPDATE pattern_categories pc
                SET occurrence_count = (
                    SELECT COUNT(*) 
                    FROM historical_patterns hp 
                    WHERE hp.event_type = pc.category_name
                ),
                avg_price_change = (
                    SELECT AVG(price_change_24h)
                    FROM historical_patterns hp
                    WHERE hp.event_type = pc.category_name
                )";
        
        executeQuery($sql);
    }
    
    /**
     * Get historical learning summary for a symbol
     */
    public function getHistoricalLearningSummary($symbol) {
        // Get most common pattern types
        $sql = "SELECT 
                    event_type,
                    COUNT(*) as occurrence_count,
                    AVG(price_change_24h) as avg_price_change,
                    AVG(CASE WHEN market_direction = 'bullish' THEN 1 WHEN market_direction = 'bearish' THEN -1 ELSE 0 END) as avg_direction_score,
                    MAX(pattern_date) as last_occurrence
                FROM historical_patterns
                WHERE symbol = ?
                GROUP BY event_type
                ORDER BY occurrence_count DESC
                LIMIT 5";
        
        $patterns = fetchAll($sql, [$symbol]);
        
        // Get recent successful predictions
        $sql = "SELECT 
                    COUNT(*) as total_predictions,
                    SUM(CASE WHEN predicted_direction = actual_direction THEN 1 ELSE 0 END) as correct_predictions,
                    AVG(confidence_score) as avg_confidence,
                    AVG(prediction_accuracy) as avg_accuracy
                FROM pattern_matches
                WHERE symbol = ?
                AND actual_direction IS NOT NULL
                AND match_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        
        $performance = fetchOne($sql, [$symbol]);
        
        return [
            'symbol' => $symbol,
            'common_patterns' => $patterns,
            'prediction_performance' => $performance,
            'total_historical_patterns' => count($patterns)
        ];
    }
    
    /**
     * Evaluate past predictions
     */
    public function evaluatePredictions($days = 7) {
        $this->output("=== Evaluating AI Predictions (Last {$days} days) ===\n\n");
        
        // Set SQL_BIG_SELECTS for free hosting compatibility
        try {
            executeQuery("SET SQL_BIG_SELECTS=1");
        } catch (Exception $e) {
            // Ignore if setting fails
        }
        
        // Get predictions that should have results by now (limit to prevent timeout)
        $sql = "SELECT p.* 
                FROM ai_predictions p
                WHERE p.prediction_timestamp >= DATE_SUB(NOW(), INTERVAL ? DAY)
                AND p.target_timestamp <= NOW()
                AND p.accuracy_score IS NULL
                ORDER BY p.prediction_timestamp DESC
                LIMIT 50";
        
        $predictions = fetchAll($sql, [$days]);
        
        $evaluated = 0;
        $correctPredictions = 0;
        
        foreach ($predictions as $pred) {
            // Fetch prices separately to avoid large JOIN
            $priceAtPrediction = fetchOne(
                "SELECT close FROM market_prices 
                 WHERE symbol = ? 
                 AND timestamp <= ? 
                 AND timestamp >= DATE_SUB(?, INTERVAL 1 HOUR)
                 ORDER BY timestamp DESC LIMIT 1",
                [$pred['symbol'], $pred['prediction_timestamp'], $pred['prediction_timestamp']]
            );
            
            $priceAtTarget = fetchOne(
                "SELECT close FROM market_prices 
                 WHERE symbol = ? 
                 AND timestamp <= ? 
                 AND timestamp >= DATE_SUB(?, INTERVAL 1 HOUR)
                 ORDER BY timestamp DESC LIMIT 1",
                [$pred['symbol'], $pred['target_timestamp'], $pred['target_timestamp']]
            );
            
            if (!$priceAtPrediction || !$priceAtTarget) {
                continue;
            }
            
            // Calculate actual price change
            $actualChange = (($priceAtTarget['close'] - $priceAtPrediction['close']) / $priceAtPrediction['close']) * 100;
            
            // Determine actual signal
            if ($actualChange > 1) {
                $actualSignal = 'bullish';
            } elseif ($actualChange < -1) {
                $actualSignal = 'bearish';
            } else {
                $actualSignal = 'sideways';
            }
            
            // Check if prediction was correct
            $isCorrect = ($pred['predicted_signal'] === $actualSignal);
            if ($isCorrect) $correctPredictions++;
            
            // Calculate accuracy score
            $accuracyScore = $isCorrect ? $pred['confidence_score'] : (1 - $pred['confidence_score']);
            
            // 🧠 AUTO-LEARNING: Learn from this prediction
            try {
                $predictionData = [
                    'ai_signal' => $pred['predicted_signal'],
                    'confidence' => $pred['confidence_score']
                ];
                $this->autoLearner->learnFromPrediction($predictionData, $isCorrect);
            } catch (Exception $e) {
                // Silent fail - don't break evaluation if learning fails
            }
            
            // Update prediction with results
            $updateSql = "UPDATE ai_predictions 
                          SET actual_price = ?,
                              accuracy_score = ?
                          WHERE id = ?";
            
            executeQuery($updateSql, [
                $priceAtTarget['close'],
                $accuracyScore,
                $pred['id']
            ]);
            
            $evaluated++;
        }
        
        // Calculate overall accuracy
        $accuracyRate = $evaluated > 0 ? ($correctPredictions / $evaluated) * 100 : 0;
        
        $this->output("✓ Evaluated {$evaluated} predictions\n");
        $this->output("  Correct: {$correctPredictions}\n");
        $this->output("  Accuracy Rate: " . round($accuracyRate, 2) . "%\n");
        
        // Save performance metrics
        $this->savePerformanceMetrics($evaluated, $correctPredictions, $accuracyRate);
        
        return [
            'evaluated' => $evaluated,
            'correct' => $correctPredictions,
            'accuracy_rate' => $accuracyRate
        ];
    }
    
    /**
     * Save performance metrics
     */
    private function savePerformanceMetrics($total, $correct, $accuracyRate) {
        // Get model version from config
        try {
            $modelVersion = fetchOne("SELECT config_value FROM system_config WHERE config_key = 'model_version'");
            $version = $modelVersion ? $modelVersion['config_value'] : 'v1.0';
        } catch (Exception $e) {
            $version = 'v1.0';
        }
        
        $sql = "INSERT INTO ai_model_performance 
                (model_version, evaluation_date, total_predictions, correct_predictions, accuracy_rate)
                VALUES (?, CURDATE(), ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                total_predictions = total_predictions + VALUES(total_predictions),
                correct_predictions = correct_predictions + VALUES(correct_predictions),
                accuracy_rate = (correct_predictions / total_predictions)";
        
        try {
            executeQuery($sql, [
                $version,
                $total,
                $correct,
                $accuracyRate / 100
            ]);
        } catch (Exception $e) {
            // Table might not exist yet - skip
            $this->output("Note: Could not save performance metrics (table might not exist)\n");
        }
    }
    
    /**
     * Get model performance statistics
     */
    public function getPerformanceStats($days = 30) {
        try {
            $sql = "SELECT 
                        model_version,
                        SUM(total_predictions) as total,
                        SUM(correct_predictions) as correct,
                        AVG(accuracy_rate) as avg_accuracy,
                        MIN(evaluation_date) as first_eval,
                        MAX(evaluation_date) as last_eval
                    FROM ai_model_performance
                    WHERE evaluation_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
                    GROUP BY model_version
                    ORDER BY last_eval DESC";
            
            return fetchAll($sql, [$days]);
        } catch (Exception $e) {
            // Table might not exist yet
            return [];
        }
    }
    
    /**
     * Analyze prediction patterns
     */
    public function analyzePredictionPatterns() {
        $this->output("\n=== Analyzing Prediction Patterns ===\n\n");
        
        try {
            // Analyze by signal type
            $sql = "SELECT 
                        predicted_signal,
                        COUNT(*) as count,
                        AVG(confidence_score) as avg_confidence,
                        AVG(accuracy_score) as avg_accuracy,
                        SUM(CASE WHEN accuracy_score > 0.5 THEN 1 ELSE 0 END) as correct_count
                    FROM ai_predictions
                    WHERE accuracy_score IS NOT NULL
                    AND prediction_timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                    GROUP BY predicted_signal";
            
            $results = fetchAll($sql);
            
            if (empty($results)) {
                $this->output("No prediction data available for pattern analysis.\n");
                return [];
            }
            
            foreach ($results as $row) {
                $this->output("{$row['predicted_signal']} Predictions:\n");
                $this->output("  Total: {$row['count']}\n");
                $this->output("  Correct: {$row['correct_count']}\n");
                $this->output("  Accuracy: " . round(($row['correct_count'] / $row['count']) * 100, 2) . "%\n");
                $this->output("  Avg Confidence: " . round($row['avg_confidence'] * 100, 2) . "%\n\n");
            }
            
            return $results;
        } catch (Exception $e) {
            $this->output("Could not analyze prediction patterns: " . $e->getMessage() . "\n");
            return [];
        }
    }
    
    /**
     * Identify improvement areas
     */
    public function identifyImprovementAreas() {
        try {
            // Find patterns where predictions were wrong
            $sql = "SELECT 
                        symbol,
                        predicted_signal,
                        confidence_score,
                        top_factors
                    FROM ai_predictions
                    WHERE accuracy_score < 0.5
                    AND prediction_timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                    ORDER BY confidence_score DESC
                    LIMIT 10";
            
            $wrongPredictions = fetchAll($sql);
            
            $this->output("\n=== Areas for Improvement ===\n");
            $this->output("Recent incorrect high-confidence predictions: " . count($wrongPredictions) . "\n");
            
            if (empty($wrongPredictions)) {
                $this->output("No incorrect predictions found in recent data.\n");
                return [
                    'wrong_predictions' => [],
                    'common_factors' => []
                ];
            }
            
            // Analyze common factors in wrong predictions
            $factorFrequency = [];
            
            foreach ($wrongPredictions as $pred) {
                if (!$pred['top_factors']) continue;
                
                $factors = json_decode($pred['top_factors'], true);
                if (is_array($factors)) {
                    foreach ($factors as $factor) {
                        $factorName = $factor['factor'] ?? 'unknown';
                        if (!isset($factorFrequency[$factorName])) {
                            $factorFrequency[$factorName] = 0;
                        }
                        $factorFrequency[$factorName]++;
                    }
                }
            }
            
            arsort($factorFrequency);
            
            $this->output("\nMost common factors in incorrect predictions:\n");
            if (empty($factorFrequency)) {
                $this->output("  No factor data available.\n");
            } else {
                $i = 1;
                foreach (array_slice($factorFrequency, 0, 5, true) as $factor => $count) {
                    $this->output("  {$i}. {$factor}: {$count} times\n");
                    $i++;
                }
            }
            
            return [
                'wrong_predictions' => $wrongPredictions,
                'common_factors' => $factorFrequency
            ];
        } catch (Exception $e) {
            $this->output("Could not identify improvement areas: " . $e->getMessage() . "\n");
            return [
                'wrong_predictions' => [],
                'common_factors' => []
            ];
        }
    }
    
    /**
     * Generate learning report
     */
    public function generateLearningReport() {
        $report = [];
        
        // Overall performance
        $stats = $this->getPerformanceStats(30);
        $report['performance'] = $stats;
        
        // Pattern analysis
        $patterns = $this->analyzePredictionPatterns();
        $report['patterns'] = $patterns;
        
        // Improvement areas
        $improvements = $this->identifyImprovementAreas();
        $report['improvements'] = $improvements;
        
        // Recommendations
        $report['recommendations'] = $this->generateRecommendations($stats, $patterns);
        
        return $report;
    }
    
    /**
     * Generate recommendations for model improvement
     */
    private function generateRecommendations($stats, $patterns) {
        $recommendations = [];
        
        // Check if we have data
        if (empty($stats) && empty($patterns)) {
            $recommendations[] = "Not enough prediction data yet. Run analysis and wait for results to accumulate.";
            return $recommendations;
        }
        
        // Check overall accuracy
        if (!empty($stats) && isset($stats[0]['avg_accuracy']) && $stats[0]['avg_accuracy'] < 0.65) {
            $recommendations[] = "Overall accuracy is below 65%. Consider reviewing technical indicator weights.";
        }
        
        // Check signal-specific accuracy
        if (!empty($patterns)) {
            foreach ($patterns as $pattern) {
                if (isset($pattern['count']) && $pattern['count'] > 0) {
                    $accuracy = ($pattern['correct_count'] / $pattern['count']) * 100;
                    if ($accuracy < 55) {
                        $recommendations[] = "Low accuracy for {$pattern['predicted_signal']} signals (" . round($accuracy, 1) . "%). Review prediction rules for this signal type.";
                    }
                }
            }
            
            // Check confidence calibration
            foreach ($patterns as $pattern) {
                if (isset($pattern['count']) && $pattern['count'] > 0 && isset($pattern['avg_confidence'])) {
                    $confidenceAccuracyGap = abs(($pattern['avg_confidence'] * 100) - (($pattern['correct_count'] / $pattern['count']) * 100));
                    if ($confidenceAccuracyGap > 15) {
                        $recommendations[] = "Confidence scores are not well calibrated for {$pattern['predicted_signal']} signals. Consider adjusting confidence calculation.";
                    }
                }
            }
        }
        
        if (empty($recommendations)) {
            $recommendations[] = "Model performance is good. Continue monitoring and collecting data.";
        }
        
        return $recommendations;
    }
    
    /**
     * Export training data for external ML models
     */
    public function exportTrainingData($outputFile = 'data/training_data.csv') {
        $sql = "SELECT 
                    p.symbol,
                    p.prediction_timestamp,
                    p.predicted_signal,
                    p.confidence_score,
                    p.predicted_price,
                    p.actual_price,
                    p.accuracy_score,
                    ti.rsi,
                    ti.macd,
                    ti.ema_12,
                    ti.ema_26,
                    ti.sma_20,
                    ti.volatility,
                    ne.sentiment_score
                FROM ai_predictions p
                LEFT JOIN technical_indicators ti 
                    ON p.symbol = ti.symbol 
                    AND DATE(ti.timestamp) = DATE(p.prediction_timestamp)
                LEFT JOIN (
                    SELECT DATE(date) as date, AVG(sentiment_score) as sentiment_score
                    FROM news_events
                    GROUP BY DATE(date)
                ) ne ON DATE(p.prediction_timestamp) = ne.date
                WHERE p.accuracy_score IS NOT NULL
                ORDER BY p.prediction_timestamp DESC";
        
        $data = fetchAll($sql);
        
        if (empty($data)) {
            $this->output("No training data available\n");
            return false;
        }
        
        // Create CSV
        $fp = fopen($outputFile, 'w');
        
        // Write header
        fputcsv($fp, array_keys($data[0]));
        
        // Write data
        foreach ($data as $row) {
            fputcsv($fp, $row);
        }
        
        fclose($fp);
        
        $this->output("✓ Exported " . count($data) . " records to {$outputFile}\n");
        
        return true;
    }
}

// CLI Execution
if (php_sapi_name() === 'cli') {
    echo "=== AI Continuous Learning ===\n\n";
    
    $learning = new AILearning();
    
    // Evaluate recent predictions
    $results = $learning->evaluatePredictions(7);
    
    // Generate learning report
    $report = $learning->generateLearningReport();
    
    echo "\n=== Recommendations ===\n";
    foreach ($report['recommendations'] as $i => $rec) {
        echo ($i + 1) . ". {$rec}\n";
    }
}
?>

