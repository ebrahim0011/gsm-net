<?php
/**
 * Multi-Timeframe Analyzer
 * تحليل متعدد الأطر الزمنية
 * 
 * Features:
 * - Analysis across multiple timeframes (1m, 5m, 15m, 1h, 4h, 1d)
 * - Confluence detection (signal alignment)
 * - Trend strength across timeframes
 * - Support/Resistance across timeframes
 * - Divergence detection
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/cache.php';
require_once __DIR__ . '/technical_indicators.php';

class MultiTimeframeAnalyzer {
    
    private $cache;
    private $cacheTime = 180; // 3 minutes cache
    
    private $timeframes = [
        '1m' => ['minutes' => 1, 'periods' => 60, 'weight' => 0.5],
        '5m' => ['minutes' => 5, 'periods' => 60, 'weight' => 1.0],
        '15m' => ['minutes' => 15, 'periods' => 60, 'weight' => 1.5],
        '1h' => ['minutes' => 60, 'periods' => 48, 'weight' => 2.5],
        '4h' => ['minutes' => 240, 'periods' => 48, 'weight' => 3.0],
        '1d' => ['minutes' => 1440, 'periods' => 30, 'weight' => 4.0]
    ];
    
    public function __construct() {
        $this->cache = $GLOBALS['cache'];
    }
    
    /**
     * Get comprehensive multi-timeframe analysis
     */
    public function getComprehensiveAnalysis($symbol = 'BTC') {
        return $this->cache->getCachedAnalysis(
            $symbol,
            'multitimeframe',
            function() use ($symbol) {
                return $this->performAnalysis($symbol);
            },
            $this->cacheTime
        );
    }
    
    /**
     * Perform multi-timeframe analysis
     */
    private function performAnalysis($symbol) {
        $timeframeAnalysis = [];
        
        // Analyze each timeframe
        foreach ($this->timeframes as $tf => $config) {
            $timeframeAnalysis[$tf] = $this->analyzeTimeframe($symbol, $tf, $config);
        }
        
        // Detect confluence
        $confluence = $this->detectConfluence($timeframeAnalysis);
        
        // Calculate overall trend
        $overallTrend = $this->calculateOverallTrend($timeframeAnalysis);
        
        // Detect divergences
        $divergences = $this->detectDivergences($timeframeAnalysis);
        
        // Find best entry/exit timeframes
        $entryExitSignals = $this->findEntryExitSignals($timeframeAnalysis, $confluence);
        
        return [
            'timeframes' => $timeframeAnalysis,
            'confluence' => $confluence,
            'overall_trend' => $overallTrend,
            'divergences' => $divergences,
            'entry_exit_signals' => $entryExitSignals,
            'recommendation' => $this->generateRecommendation($confluence, $overallTrend),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Analyze single timeframe
     */
    private function analyzeTimeframe($symbol, $timeframe, $config) {
        $priceData = $this->getPriceData($symbol, $config['minutes'], $config['periods']);
        
        if (empty($priceData)) {
            return null;
        }
        
        $closes = array_column($priceData, 'close');
        $highs = array_column($priceData, 'high');
        $lows = array_column($priceData, 'low');
        $volumes = array_column($priceData, 'volume');
        
        // Calculate indicators
        $rsi = $this->calculateRSI($closes);
        $macd = $this->calculateMACD($closes);
        $ema = $this->calculateEMA($closes, 20);
        $sma = $this->calculateSMA($closes, 20);
        
        // Determine trend
        $trend = $this->determineTrend($closes, $ema, $sma);
        
        // Calculate momentum
        $momentum = $this->calculateMomentum($closes);
        
        // Support/Resistance
        $supportResistance = $this->findSupportResistance($priceData);
        
        return [
            'timeframe' => $timeframe,
            'trend' => $trend,
            'momentum' => $momentum,
            'rsi' => end($rsi),
            'macd' => [
                'value' => end($macd['macd']),
                'signal' => end($macd['signal']),
                'histogram' => end($macd['histogram'])
            ],
            'ema' => end($ema),
            'sma' => end($sma),
            'current_price' => end($closes),
            'support_resistance' => $supportResistance,
            'signal' => $this->getTimeframeSignal($trend, $rsi, $macd),
            'strength' => $this->calculateStrength($trend, $momentum, $rsi)
        ];
    }
    
    /**
     * Detect confluence across timeframes
     */
    private function detectConfluence($timeframeAnalysis) {
        $bullishCount = 0;
        $bearishCount = 0;
        $neutralCount = 0;
        $totalWeight = 0;
        $weightedScore = 0;
        
        $confluenceDetails = [];
        
        foreach ($timeframeAnalysis as $tf => $analysis) {
            if (!$analysis) continue;
            
            $signal = $analysis['signal'] ?? 'neutral';
            $weight = $this->timeframes[$tf]['weight'];
            $strength = $analysis['strength'] ?? 0.5;
            
            $totalWeight += $weight;
            
            if ($signal === 'bullish') {
                $bullishCount++;
                $weightedScore += $weight * $strength;
            } elseif ($signal === 'bearish') {
                $bearishCount++;
                $weightedScore -= $weight * $strength;
            } else {
                $neutralCount++;
            }
            
            $confluenceDetails[] = [
                'timeframe' => $tf,
                'signal' => $signal,
                'strength' => $strength,
                'weight' => $weight
            ];
        }
        
        // Calculate confluence strength
        $totalSignals = $bullishCount + $bearishCount + $neutralCount;
        $maxCount = max($bullishCount, $bearishCount, $neutralCount);
        $confluenceStrength = $totalSignals > 0 ? $maxCount / $totalSignals : 0;
        
        // Determine overall confluence signal
        if ($bullishCount > $bearishCount && $bullishCount > $neutralCount) {
            $confluenceSignal = 'bullish';
        } elseif ($bearishCount > $bullishCount && $bearishCount > $neutralCount) {
            $confluenceSignal = 'bearish';
        } else {
            $confluenceSignal = 'neutral';
        }
        
        // Calculate confidence
        $confidence = $totalWeight > 0 ? abs($weightedScore) / $totalWeight : 0;
        
        return [
            'signal' => $confluenceSignal,
            'strength' => round($confluenceStrength, 4),
            'confidence' => round($confidence, 4),
            'bullish_count' => $bullishCount,
            'bearish_count' => $bearishCount,
            'neutral_count' => $neutralCount,
            'weighted_score' => round($weightedScore, 2),
            'details' => $confluenceDetails,
            'alignment' => $confluenceStrength > 0.7 ? 'strong' : 
                          ($confluenceStrength > 0.5 ? 'moderate' : 'weak')
        ];
    }
    
    /**
     * Calculate overall trend
     */
    private function calculateOverallTrend($timeframeAnalysis) {
        $shortTerm = ['1m', '5m', '15m'];
        $mediumTerm = ['1h', '4h'];
        $longTerm = ['1d'];
        
        $shortTrendScore = $this->getTrendScore($timeframeAnalysis, $shortTerm);
        $mediumTrendScore = $this->getTrendScore($timeframeAnalysis, $mediumTerm);
        $longTrendScore = $this->getTrendScore($timeframeAnalysis, $longTerm);
        
        // Weighted average (long-term has more weight)
        $overallScore = ($shortTrendScore * 0.2) + ($mediumTrendScore * 0.3) + ($longTrendScore * 0.5);
        
        return [
            'short_term' => $this->scoreToTrend($shortTrendScore),
            'medium_term' => $this->scoreToTrend($mediumTrendScore),
            'long_term' => $this->scoreToTrend($longTrendScore),
            'overall' => $this->scoreToTrend($overallScore),
            'scores' => [
                'short' => round($shortTrendScore, 2),
                'medium' => round($mediumTrendScore, 2),
                'long' => round($longTrendScore, 2),
                'overall' => round($overallScore, 2)
            ]
        ];
    }
    
    /**
     * Detect divergences between timeframes
     */
    private function detectDivergences($timeframeAnalysis) {
        $divergences = [];
        
        // Check short-term vs long-term
        $shortTerm = $timeframeAnalysis['15m'] ?? null;
        $longTerm = $timeframeAnalysis['1d'] ?? null;
        
        if ($shortTerm && $longTerm) {
            $shortSignal = $shortTerm['signal'] ?? 'neutral';
            $longSignal = $longTerm['signal'] ?? 'neutral';
            
            if ($shortSignal !== $longSignal && $shortSignal !== 'neutral' && $longSignal !== 'neutral') {
                $divergences[] = [
                    'type' => 'timeframe_divergence',
                    'description' => "Short-term ({$shortSignal}) diverges from long-term ({$longSignal})",
                    'severity' => 'medium',
                    'timeframes' => ['15m', '1d'],
                    'interpretation' => $this->interpretDivergence($shortSignal, $longSignal)
                ];
            }
        }
        
        // Check RSI divergence
        $rsiDivergence = $this->detectRSIDivergence($timeframeAnalysis);
        if ($rsiDivergence) {
            $divergences[] = $rsiDivergence;
        }
        
        return [
            'has_divergence' => count($divergences) > 0,
            'divergences' => $divergences,
            'count' => count($divergences)
        ];
    }
    
    /**
     * Find best entry/exit signals
     */
    private function findEntryExitSignals($timeframeAnalysis, $confluence) {
        $signals = [];
        
        // Entry signal: confluence + short-term confirmation
        if ($confluence['signal'] === 'bullish' && $confluence['strength'] > 0.6) {
            $shortTerm = $timeframeAnalysis['5m'] ?? null;
            if ($shortTerm && $shortTerm['signal'] === 'bullish') {
                $signals['entry'] = [
                    'action' => 'BUY',
                    'timeframe' => '5m',
                    'confidence' => $confluence['confidence'],
                    'reason' => 'Bullish confluence with short-term confirmation'
                ];
            }
        } elseif ($confluence['signal'] === 'bearish' && $confluence['strength'] > 0.6) {
            $shortTerm = $timeframeAnalysis['5m'] ?? null;
            if ($shortTerm && $shortTerm['signal'] === 'bearish') {
                $signals['entry'] = [
                    'action' => 'SELL',
                    'timeframe' => '5m',
                    'confidence' => $confluence['confidence'],
                    'reason' => 'Bearish confluence with short-term confirmation'
                ];
            }
        }
        
        // Exit signal: divergence or weakening trend
        foreach ($timeframeAnalysis as $tf => $analysis) {
            if (!$analysis) continue;
            
            $rsi = $analysis['rsi'] ?? 50;
            
            if ($rsi > 75 || $rsi < 25) {
                $signals['exit'] = [
                    'action' => $rsi > 75 ? 'TAKE_PROFIT' : 'STOP_LOSS',
                    'timeframe' => $tf,
                    'reason' => "RSI extreme level: {$rsi}",
                    'urgency' => 'high'
                ];
                break;
            }
        }
        
        return $signals;
    }
    
    /**
     * Generate recommendation
     */
    private function generateRecommendation($confluence, $overallTrend) {
        $signal = $confluence['signal'];
        $strength = $confluence['strength'];
        $confidence = $confluence['confidence'];
        
        if ($signal === 'bullish' && $strength > 0.7) {
            return [
                'action' => 'STRONG BUY',
                'description' => 'Strong bullish confluence across multiple timeframes',
                'confidence' => $confidence,
                'risk_level' => 'medium'
            ];
        } elseif ($signal === 'bullish' && $strength > 0.5) {
            return [
                'action' => 'BUY',
                'description' => 'Moderate bullish signals across timeframes',
                'confidence' => $confidence,
                'risk_level' => 'medium-high'
            ];
        } elseif ($signal === 'bearish' && $strength > 0.7) {
            return [
                'action' => 'STRONG SELL',
                'description' => 'Strong bearish confluence across multiple timeframes',
                'confidence' => $confidence,
                'risk_level' => 'high'
            ];
        } elseif ($signal === 'bearish' && $strength > 0.5) {
            return [
                'action' => 'SELL',
                'description' => 'Moderate bearish signals across timeframes',
                'confidence' => $confidence,
                'risk_level' => 'medium-high'
            ];
        } else {
            return [
                'action' => 'WAIT',
                'description' => 'No clear direction - conflicting signals across timeframes',
                'confidence' => $confidence,
                'risk_level' => 'low'
            ];
        }
    }
    
    /**
     * Helper functions
     */
    
    private function getPriceData($symbol, $intervalMinutes, $periods) {
        $hours = ($intervalMinutes * $periods) / 60;
        
        $sql = "SELECT timestamp, open, high, low, close, volume 
                FROM market_prices 
                WHERE symbol = ? 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY timestamp ASC";
        
        return fetchAll($sql, [$symbol, $hours]);
    }
    
    private function calculateRSI($prices, $period = 14) {
        if (count($prices) < $period + 1) return [50];
        
        $gains = [];
        $losses = [];
        
        for ($i = 1; $i < count($prices); $i++) {
            $change = $prices[$i] - $prices[$i - 1];
            $gains[] = $change > 0 ? $change : 0;
            $losses[] = $change < 0 ? abs($change) : 0;
        }
        
        $avgGain = array_sum(array_slice($gains, -$period)) / $period;
        $avgLoss = array_sum(array_slice($losses, -$period)) / $period;
        
        if ($avgLoss == 0) return [100];
        
        $rs = $avgGain / $avgLoss;
        $rsi = 100 - (100 / (1 + $rs));
        
        return [$rsi];
    }
    
    private function calculateMACD($prices) {
        $ema12 = $this->calculateEMA($prices, 12);
        $ema26 = $this->calculateEMA($prices, 26);
        
        $macd = [];
        for ($i = 0; $i < min(count($ema12), count($ema26)); $i++) {
            $macd[] = $ema12[$i] - $ema26[$i];
        }
        
        $signal = $this->calculateEMA($macd, 9);
        $histogram = [];
        
        for ($i = 0; $i < count($signal); $i++) {
            $histogram[] = $macd[$i] - $signal[$i];
        }
        
        return [
            'macd' => $macd,
            'signal' => $signal,
            'histogram' => $histogram
        ];
    }
    
    private function calculateEMA($prices, $period) {
        if (empty($prices)) return [];
        
        $multiplier = 2 / ($period + 1);
        $ema = [array_sum(array_slice($prices, 0, $period)) / $period];
        
        for ($i = $period; $i < count($prices); $i++) {
            $ema[] = ($prices[$i] - $ema[count($ema) - 1]) * $multiplier + $ema[count($ema) - 1];
        }
        
        return $ema;
    }
    
    private function calculateSMA($prices, $period) {
        $sma = [];
        for ($i = $period - 1; $i < count($prices); $i++) {
            $sma[] = array_sum(array_slice($prices, $i - $period + 1, $period)) / $period;
        }
        return $sma;
    }
    
    private function determineTrend($closes, $ema, $sma) {
        if (empty($closes) || empty($ema) || empty($sma)) return 'neutral';
        
        $currentPrice = end($closes);
        $currentEma = end($ema);
        $currentSma = end($sma);
        
        if ($currentPrice > $currentEma && $currentEma > $currentSma) {
            return 'strong_uptrend';
        } elseif ($currentPrice > $currentEma) {
            return 'uptrend';
        } elseif ($currentPrice < $currentEma && $currentEma < $currentSma) {
            return 'strong_downtrend';
        } elseif ($currentPrice < $currentEma) {
            return 'downtrend';
        }
        
        return 'neutral';
    }
    
    private function calculateMomentum($prices) {
        if (count($prices) < 2) return 0;
        
        $recent = array_slice($prices, -5);
        $older = array_slice($prices, -10, 5);
        
        $recentAvg = array_sum($recent) / count($recent);
        $olderAvg = array_sum($older) / count($older);
        
        return $olderAvg > 0 ? (($recentAvg - $olderAvg) / $olderAvg) * 100 : 0;
    }
    
    private function findSupportResistance($priceData) {
        $highs = array_column($priceData, 'high');
        $lows = array_column($priceData, 'low');
        $closes = array_column($priceData, 'close');
        
        return [
            'resistance' => max($highs),
            'support' => min($lows),
            'current' => end($closes)
        ];
    }
    
    private function getTimeframeSignal($trend, $rsi, $macd) {
        $score = 0;
        
        // Trend
        if (strpos($trend, 'uptrend') !== false) $score += 1;
        if (strpos($trend, 'downtrend') !== false) $score -= 1;
        if ($trend === 'strong_uptrend') $score += 1;
        if ($trend === 'strong_downtrend') $score -= 1;
        
        // RSI
        if (isset($rsi)) {
            if ($rsi < 30) $score += 1;
            if ($rsi > 70) $score -= 1;
        }
        
        // MACD
        if (isset($macd['histogram']) && is_numeric($macd['histogram'])) {
            if ($macd['histogram'] > 0) $score += 1;
            if ($macd['histogram'] < 0) $score -= 1;
        }
        
        if ($score > 1) return 'bullish';
        if ($score < -1) return 'bearish';
        return 'neutral';
    }
    
    private function calculateStrength($trend, $momentum, $rsi) {
        $strength = 0.5;
        
        if ($trend === 'strong_uptrend' || $trend === 'strong_downtrend') {
            $strength += 0.2;
        }
        
        if (abs($momentum) > 5) {
            $strength += 0.15;
        }
        
        if (isset($rsi) && ($rsi > 70 || $rsi < 30)) {
            $strength += 0.15;
        }
        
        return min(1.0, $strength);
    }
    
    private function getTrendScore($timeframeAnalysis, $timeframes) {
        $score = 0;
        $count = 0;
        
        foreach ($timeframes as $tf) {
            if (isset($timeframeAnalysis[$tf]) && $timeframeAnalysis[$tf]) {
                $signal = $timeframeAnalysis[$tf]['signal'] ?? 'neutral';
                
                if ($signal === 'bullish') $score += 1;
                if ($signal === 'bearish') $score -= 1;
                
                $count++;
            }
        }
        
        return $count > 0 ? $score / $count : 0;
    }
    
    private function scoreToTrend($score) {
        if ($score > 0.5) return 'bullish';
        if ($score < -0.5) return 'bearish';
        return 'neutral';
    }
    
    private function detectRSIDivergence($timeframeAnalysis) {
        // Simplified RSI divergence detection
        return null;
    }
    
    private function interpretDivergence($shortSignal, $longSignal) {
        if ($shortSignal === 'bullish' && $longSignal === 'bearish') {
            return 'Short-term bounce in downtrend - potential reversal or correction';
        }
        if ($shortSignal === 'bearish' && $longSignal === 'bullish') {
            return 'Short-term pullback in uptrend - potential buying opportunity';
        }
        return 'Conflicting signals';
    }
}
?>

