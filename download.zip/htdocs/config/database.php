<?php
/**
 * Database Configuration
 * 
 * InfinityFree Compatible Settings
 * Update these values with your actual database credentials
 */

// Database Configuration
define('DB_HOST', 'sql308.infinityfree.com'); // InfinityFree DB host
define('DB_NAME', 'if0_40053752_crypto_ai_analyzer'); // InfinityFree DB name
define('DB_USER', 'if0_40053752'); // InfinityFree DB username
define('DB_PASS', 'YU58LXxgEZU2'); // InfinityFree DB password
define('DB_CHARSET', 'utf8mb4');

// PDO Connection Function
function getDatabaseConnection() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("Database Connection Failed: " . $e->getMessage());
        }
    }
    
    return $pdo;
}

// Helper function to execute queries
function executeQuery($sql, $params = []) {
    $pdo = getDatabaseConnection();
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

// Helper function to fetch all results
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

// Helper function to fetch single result
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}
?>

