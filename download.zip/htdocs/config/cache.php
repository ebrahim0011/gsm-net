<?php
/**
 * Cache Manager with Redis Support
 * نظام إدارة الذاكرة المؤقتة لتحسين الأداء
 * 
 * Features:
 * - Redis caching for fast data retrieval
 * - Fallback to file-based cache if Redis unavailable
 * - Automatic cache invalidation
 * - TTL (Time To Live) management
 */

class CacheManager {
    private $redis = null;
    private $redisAvailable = false;
    private $cacheDir = __DIR__ . '/../data/cache/';
    
    public function __construct() {
        // Try to connect to Redis
        if (class_exists('Redis')) {
            try {
                $this->redis = new Redis();
                $this->redisAvailable = $this->redis->connect('127.0.0.1', 6379, 2); // 2 sec timeout
                
                if ($this->redisAvailable) {
                    // Optional: Set auth if required
                    // $this->redis->auth('your-password');
                }
            } catch (Exception $e) {
                $this->redisAvailable = false;
            }
        }
        
        // Create cache directory if it doesn't exist
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }
    
    /**
     * Get cached data
     */
    public function get($key) {
        if ($this->redisAvailable) {
            return $this->getFromRedis($key);
        } else {
            return $this->getFromFile($key);
        }
    }
    
    /**
     * Set cached data with TTL
     */
    public function set($key, $data, $ttl = 300) {
        if ($this->redisAvailable) {
            return $this->setInRedis($key, $data, $ttl);
        } else {
            return $this->setInFile($key, $data, $ttl);
        }
    }
    
    /**
     * Delete cached data
     */
    public function delete($key) {
        if ($this->redisAvailable) {
            return $this->redis->del($key);
        } else {
            $filename = $this->cacheDir . md5($key) . '.cache';
            if (file_exists($filename)) {
                return unlink($filename);
            }
        }
        return false;
    }
    
    /**
     * Check if cache exists and is valid
     */
    public function exists($key) {
        if ($this->redisAvailable) {
            return $this->redis->exists($key);
        } else {
            $filename = $this->cacheDir . md5($key) . '.cache';
            if (!file_exists($filename)) {
                return false;
            }
            
            $data = json_decode(file_get_contents($filename), true);
            return isset($data['expires']) && $data['expires'] > time();
        }
    }
    
    /**
     * Clear all cache
     */
    public function clearAll() {
        if ($this->redisAvailable) {
            return $this->redis->flushDB();
        } else {
            $files = glob($this->cacheDir . '*.cache');
            foreach ($files as $file) {
                unlink($file);
            }
            return true;
        }
    }
    
    /**
     * Get cached analysis with automatic fetch if missing
     */
    public function getCachedAnalysis($symbol, $type, $callback, $ttl = 300) {
        $key = "analysis:{$symbol}:{$type}";
        $cached = $this->get($key);
        
        if ($cached !== null) {
            return $cached;
        }
        
        // Cache miss - execute callback to get fresh data
        $data = $callback();
        
        if ($data !== null) {
            $this->set($key, $data, $ttl);
        }
        
        return $data;
    }
    
    /**
     * Get from Redis
     */
    private function getFromRedis($key) {
        try {
            $data = $this->redis->get($key);
            if ($data === false) {
                return null;
            }
            return json_decode($data, true);
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Set in Redis
     */
    private function setInRedis($key, $data, $ttl) {
        try {
            $jsonData = json_encode($data);
            return $this->redis->setex($key, $ttl, $jsonData);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Get from file cache
     */
    private function getFromFile($key) {
        $filename = $this->cacheDir . md5($key) . '.cache';
        
        if (!file_exists($filename)) {
            return null;
        }
        
        $data = json_decode(file_get_contents($filename), true);
        
        // Check if expired
        if (isset($data['expires']) && $data['expires'] < time()) {
            unlink($filename);
            return null;
        }
        
        return $data['data'] ?? null;
    }
    
    /**
     * Set in file cache
     */
    private function setInFile($key, $data, $ttl) {
        $filename = $this->cacheDir . md5($key) . '.cache';
        
        $cacheData = [
            'data' => $data,
            'expires' => time() + $ttl,
            'created' => time()
        ];
        
        return file_put_contents($filename, json_encode($cacheData)) !== false;
    }
    
    /**
     * Check if Redis is available
     */
    public function isRedisAvailable() {
        return $this->redisAvailable;
    }
    
    /**
     * Get cache statistics
     */
    public function getStats() {
        if ($this->redisAvailable) {
            try {
                return [
                    'type' => 'redis',
                    'info' => $this->redis->info(),
                    'keys_count' => $this->redis->dbSize()
                ];
            } catch (Exception $e) {
                return ['type' => 'redis', 'error' => $e->getMessage()];
            }
        } else {
            $files = glob($this->cacheDir . '*.cache');
            $totalSize = 0;
            $validCount = 0;
            
            foreach ($files as $file) {
                $totalSize += filesize($file);
                $data = json_decode(file_get_contents($file), true);
                if (isset($data['expires']) && $data['expires'] > time()) {
                    $validCount++;
                }
            }
            
            return [
                'type' => 'file',
                'total_files' => count($files),
                'valid_files' => $validCount,
                'total_size_kb' => round($totalSize / 1024, 2)
            ];
        }
    }
}

// Global cache instance
$GLOBALS['cache'] = new CacheManager();

/**
 * Helper function to get cached data
 */
function getCache($key) {
    return $GLOBALS['cache']->get($key);
}

/**
 * Helper function to set cached data
 */
function setCache($key, $data, $ttl = 300) {
    return $GLOBALS['cache']->set($key, $data, $ttl);
}

/**
 * Helper function to delete cached data
 */
function deleteCache($key) {
    return $GLOBALS['cache']->delete($key);
}
?>

