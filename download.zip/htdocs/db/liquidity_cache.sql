-- Liquidity Cache Table
-- Stores liquidity analysis data with 5-minute cache

CREATE TABLE IF NOT EXISTS liquidity_cache (
    cache_key VARCHAR(100) PRIMARY KEY,
    cache_data TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

