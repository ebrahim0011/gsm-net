-- Crypto Market Analysis AI - Database Schema
-- Compatible with MySQL 5.7+ and InfinityFree
-- Import this file in phpMyAdmin after selecting your database

-- Table: news_events
-- Stores news articles and events from various crypto sources with credibility tracking
CREATE TABLE IF NOT EXISTS news_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    summary TEXT,
    content LONGTEXT,
    link VARCHAR(1000) UNIQUE,
    source VARCHAR(100),
    date DATETIME NOT NULL,
    sentiment ENUM('positive', 'negative', 'neutral') DEFAULT 'neutral',
    sentiment_score DECIMAL(5,4) DEFAULT 0,
    credibility DECIMAL(3,1) DEFAULT 8.0 COMMENT 'Source credibility (0.0-10.0)',
    impact_level ENUM('critical', 'high', 'medium', 'low') DEFAULT 'medium' COMMENT 'Market impact level',
    embedding TEXT,
    keywords TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date (date),
    INDEX idx_sentiment (sentiment),
    INDEX idx_source (source),
    INDEX idx_credibility (credibility),
    INDEX idx_impact (impact_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: market_prices
-- Stores historical and current cryptocurrency prices
CREATE TABLE IF NOT EXISTS market_prices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    timestamp DATETIME NOT NULL,
    open DECIMAL(20,8) NOT NULL,
    high DECIMAL(20,8) NOT NULL,
    low DECIMAL(20,8) NOT NULL,
    close DECIMAL(20,8) NOT NULL,
    volume DECIMAL(20,8),
    market_cap DECIMAL(30,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_price (symbol, timestamp),
    INDEX idx_symbol_timestamp (symbol, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: technical_indicators
-- Stores calculated technical indicators
CREATE TABLE IF NOT EXISTS technical_indicators (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    timestamp DATETIME NOT NULL,
    rsi DECIMAL(10,4),
    macd DECIMAL(20,8),
    macd_signal DECIMAL(20,8),
    macd_histogram DECIMAL(20,8),
    ema_12 DECIMAL(20,8),
    ema_26 DECIMAL(20,8),
    sma_20 DECIMAL(20,8),
    sma_50 DECIMAL(20,8),
    sma_200 DECIMAL(20,8),
    bb_upper DECIMAL(20,8),
    bb_middle DECIMAL(20,8),
    bb_lower DECIMAL(20,8),
    volatility DECIMAL(10,6),
    adx DECIMAL(10,4),
    ichimoku_tenkan DECIMAL(20,8),
    ichimoku_kijun DECIMAL(20,8),
    ichimoku_senkou_a DECIMAL(20,8),
    ichimoku_senkou_b DECIMAL(20,8),
    fib_0 DECIMAL(20,8),
    fib_236 DECIMAL(20,8),
    fib_382 DECIMAL(20,8),
    fib_50 DECIMAL(20,8),
    fib_618 DECIMAL(20,8),
    fib_100 DECIMAL(20,8),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_indicator (symbol, timestamp),
    INDEX idx_symbol_timestamp (symbol, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: event_price_links
-- Links news events to price movements
CREATE TABLE IF NOT EXISTS event_price_links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    news_id INT NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    event_timestamp DATETIME NOT NULL,
    price_before DECIMAL(20,8),
    price_after_1h DECIMAL(20,8),
    price_after_24h DECIMAL(20,8),
    price_after_7d DECIMAL(20,8),
    change_1h DECIMAL(10,4),
    change_24h DECIMAL(10,4),
    change_7d DECIMAL(10,4),
    impact_score DECIMAL(5,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (news_id) REFERENCES news_events(id) ON DELETE CASCADE,
    INDEX idx_news_id (news_id),
    INDEX idx_symbol (symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: ai_predictions
-- Stores AI predictions and their accuracy
CREATE TABLE IF NOT EXISTS ai_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    prediction_timestamp DATETIME NOT NULL,
    target_timestamp DATETIME NOT NULL,
    predicted_signal ENUM('bullish', 'bearish', 'sideways') NOT NULL,
    confidence_score DECIMAL(5,4) NOT NULL,
    predicted_price DECIMAL(20,8),
    actual_price DECIMAL(20,8),
    accuracy_score DECIMAL(5,4),
    top_factors TEXT,
    model_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_symbol_prediction (symbol, prediction_timestamp),
    INDEX idx_accuracy (accuracy_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: ai_model_performance
-- Tracks AI model performance over time
CREATE TABLE IF NOT EXISTS ai_model_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    model_version VARCHAR(50) NOT NULL,
    evaluation_date DATE NOT NULL,
    symbol VARCHAR(20),
    total_predictions INT DEFAULT 0,
    correct_predictions INT DEFAULT 0,
    accuracy_rate DECIMAL(5,4),
    avg_confidence DECIMAL(5,4),
    avg_error DECIMAL(10,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_model_version (model_version),
    INDEX idx_evaluation_date (evaluation_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: system_config
-- Stores system configuration and settings
CREATE TABLE IF NOT EXISTS system_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- UPGRADE SCRIPT: Add credibility and impact_level to existing tables
-- ====================================================================
-- Run this if you already have the database and want to add new fields

ALTER TABLE news_events 
ADD COLUMN IF NOT EXISTS credibility DECIMAL(3,1) DEFAULT 8.0 COMMENT 'Source credibility (0.0-10.0)' AFTER sentiment_score,
ADD COLUMN IF NOT EXISTS impact_level ENUM('critical', 'high', 'medium', 'low') DEFAULT 'medium' COMMENT 'Market impact level' AFTER credibility,
ADD INDEX IF NOT EXISTS idx_credibility (credibility),
ADD INDEX IF NOT EXISTS idx_impact (impact_level);

-- Insert default configuration
INSERT INTO system_config (config_key, config_value, description) VALUES
('last_news_fetch', '2025-01-01 00:00:00', 'Last time news were fetched'),
('last_price_fetch', '2025-01-01 00:00:00', 'Last time prices were fetched'),
('active_symbols', 'BTC,ETH,BNB,SOL,XRP', 'Comma-separated list of tracked symbols'),
('model_version', 'v1.0', 'Current AI model version'),
('scraping_interval', '300', 'Scraping interval in seconds'),
('min_confidence_threshold', '0.65', 'Minimum confidence score for predictions'),
('sentiment_weights', '{"positive": 1.5, "negative": -1.5, "neutral": 0}', 'Sentiment impact weights')
ON DUPLICATE KEY UPDATE config_key=config_key;

