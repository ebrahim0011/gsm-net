-- Translations Cache Table
-- لحفظ الترجمات وتسريع عرضها

CREATE TABLE IF NOT EXISTS translations_cache (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_text TEXT NOT NULL,
    source_lang VARCHAR(5) DEFAULT 'en',
    target_lang VARCHAR(5) DEFAULT 'ar',
    translated_text TEXT NOT NULL,
    text_hash VARCHAR(64) NOT NULL,
    translation_service VARCHAR(50) DEFAULT 'mymemory',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_count INT DEFAULT 1,
    last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_hash (text_hash),
    INDEX idx_langs (source_lang, target_lang),
    INDEX idx_last_used (last_used)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add translation fields to news_events table
ALTER TABLE news_events 
ADD COLUMN title_ar TEXT DEFAULT NULL,
ADD COLUMN summary_ar TEXT DEFAULT NULL;

-- Add translation fields to upcoming_events table
ALTER TABLE upcoming_events 
ADD COLUMN event_title_ar TEXT DEFAULT NULL,
ADD COLUMN event_description_ar TEXT DEFAULT NULL;

