-- Upcoming Events Table
CREATE TABLE IF NOT EXISTS upcoming_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_title VARCHAR(255) NOT NULL,
    event_description TEXT,
    event_type ENUM('fed_decision', 'interest_rate', 'cpi_data', 'earnings', 'halving', 'upgrade', 'conference', 'regulation', 'other') DEFAULT 'other',
    event_date DATETIME NOT NULL,
    importance ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    expected_impact ENUM('bullish', 'bearish', 'neutral', 'mixed') DEFAULT 'neutral',
    symbol VARCHAR(20),
    source VARCHAR(100),
    link VARCHAR(500),
    is_passed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_event_date (event_date),
    INDEX idx_event_type (event_type),
    INDEX idx_is_passed (is_passed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Events will be populated automatically by collector/events_scraper.php
-- Run: php collector/events_scraper.php
-- Or: open in browser with ?run=1

