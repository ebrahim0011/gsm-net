-- Historical Learning Schema for Smart Learning from the Past
-- SIMPLIFIED VERSION - Compatible with all MySQL versions including InfinityFree
-- Use this if the main schema file gives errors

-- Table: historical_patterns
CREATE TABLE IF NOT EXISTS historical_patterns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pattern_date DATETIME NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    event_type VARCHAR(100) COMMENT 'Type of event',
    event_description TEXT,
    news_id INT,
    
    price_before DECIMAL(20,8) NOT NULL,
    volume_before DECIMAL(20,8),
    
    rsi_before DECIMAL(10,4),
    macd_before DECIMAL(20,8),
    volatility_before DECIMAL(10,6),
    
    sentiment_before ENUM('positive', 'negative', 'neutral'),
    sentiment_score_before DECIMAL(5,4),
    
    price_change_1h DECIMAL(10,4) COMMENT 'Price change % after 1 hour',
    price_change_4h DECIMAL(10,4) COMMENT 'Price change % after 4 hours',
    price_change_24h DECIMAL(10,4) COMMENT 'Price change % after 24 hours',
    price_change_7d DECIMAL(10,4) COMMENT 'Price change % after 7 days',
    volume_change_24h DECIMAL(10,4) COMMENT 'Volume change % after 24 hours',
    
    market_direction ENUM('bullish', 'bearish', 'sideways') NOT NULL,
    volatility_change DECIMAL(10,4) COMMENT 'Change in volatility',
    
    pattern_strength DECIMAL(5,4) COMMENT 'Strength of the pattern (0-1)',
    reliability_score DECIMAL(5,4) COMMENT 'Historical reliability',
    
    event_embedding TEXT COMMENT 'JSON array of embeddings',
    keywords TEXT COMMENT 'Extracted keywords',
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_pattern_date (pattern_date),
    INDEX idx_symbol (symbol),
    INDEX idx_event_type (event_type),
    INDEX idx_market_direction (market_direction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: pattern_matches
CREATE TABLE IF NOT EXISTS pattern_matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    current_news_id INT NOT NULL,
    historical_pattern_id INT NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    match_date DATETIME NOT NULL,
    
    similarity_score DECIMAL(5,4) NOT NULL COMMENT 'Overall similarity (0-1)',
    text_similarity DECIMAL(5,4) COMMENT 'Text/semantic similarity',
    price_context_similarity DECIMAL(5,4) COMMENT 'Similar price context',
    indicator_similarity DECIMAL(5,4) COMMENT 'Similar technical indicators',
    sentiment_similarity DECIMAL(5,4) COMMENT 'Similar market sentiment',
    
    predicted_direction ENUM('bullish', 'bearish', 'sideways'),
    predicted_price_change_24h DECIMAL(10,4),
    confidence_score DECIMAL(5,4),
    
    actual_direction ENUM('bullish', 'bearish', 'sideways'),
    actual_price_change_24h DECIMAL(10,4),
    prediction_accuracy DECIMAL(5,4),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_current_news (current_news_id),
    INDEX idx_historical_pattern (historical_pattern_id),
    INDEX idx_match_date (match_date),
    INDEX idx_symbol (symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: learning_insights
CREATE TABLE IF NOT EXISTS learning_insights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    insight_date DATE NOT NULL,
    symbol VARCHAR(20),
    event_type VARCHAR(100),
    
    pattern_count INT COMMENT 'Number of similar patterns found',
    avg_price_change DECIMAL(10,4) COMMENT 'Average price change',
    success_rate DECIMAL(5,4) COMMENT 'Success rate of predictions',
    
    recommendation TEXT COMMENT 'AI-generated recommendation',
    risk_level ENUM('low', 'medium', 'high', 'critical'),
    confidence DECIMAL(5,4),
    
    supporting_patterns TEXT COMMENT 'JSON of supporting pattern IDs',
    key_factors TEXT COMMENT 'JSON of key factors',
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_insight_date (insight_date),
    INDEX idx_symbol (symbol),
    INDEX idx_event_type (event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: pattern_categories
CREATE TABLE IF NOT EXISTS pattern_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) UNIQUE NOT NULL,
    category_description TEXT,
    keywords TEXT COMMENT 'JSON of keywords',
    typical_impact ENUM('bullish', 'bearish', 'neutral', 'mixed'),
    avg_price_change DECIMAL(10,4) COMMENT 'Historical average price change',
    occurrence_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default pattern categories
INSERT INTO pattern_categories (category_name, category_description, keywords, typical_impact) VALUES
('Interest Rate Change', 'Central bank interest rate decisions', '["interest rate", "fed", "federal reserve", "monetary policy", "rate hike", "rate cut"]', 'mixed'),
('Regulatory News', 'Government regulations and legal developments', '["regulation", "SEC", "legal", "ban", "approval", "compliance", "lawsuit"]', 'mixed'),
('ETF Approval', 'ETF and institutional investment approvals', '["ETF", "spot ETF", "bitcoin ETF", "approval", "institutional"]', 'bullish'),
('Major Hack/Security', 'Security breaches and hacks', '["hack", "breach", "stolen", "security", "exploit", "vulnerability"]', 'bearish'),
('Adoption News', 'Mainstream adoption and partnerships', '["adoption", "partnership", "integration", "payment", "merchant", "accept"]', 'bullish'),
('Technical Upgrade', 'Blockchain upgrades and forks', '["upgrade", "fork", "hardfork", "update", "merge", "consensus"]', 'mixed'),
('Whale Movement', 'Large holder transactions', '["whale", "large transfer", "moved", "billion", "institutional buy"]', 'mixed'),
('Market Crash', 'Major market downturns', '["crash", "dump", "collapse", "panic", "liquidation", "margin call"]', 'bearish'),
('Bull Run', 'Strong upward market trends', '["bull run", "all-time high", "ATH", "rally", "surge", "pump"]', 'bullish'),
('Halving Event', 'Bitcoin halving and similar events', '["halving", "reward reduction", "supply shock"]', 'bullish')
ON DUPLICATE KEY UPDATE category_name=category_name;

-- Note: VIEW is not included in this version for maximum compatibility
-- You can query recent_pattern_performance data directly using:
-- SELECT pm.symbol, hp.event_type, COUNT(*) as match_count, ...
-- FROM pattern_matches pm JOIN historical_patterns hp ...

