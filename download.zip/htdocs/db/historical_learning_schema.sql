-- Historical Learning Schema for Smart Learning from the Past
-- Add these tables to your existing database

-- Table: historical_patterns
-- Stores historical market patterns and their outcomes
CREATE TABLE IF NOT EXISTS historical_patterns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pattern_date DATETIME NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    event_type VARCHAR(100) COMMENT 'Type of event (e.g., Interest Rate Hike, ETF Approval, Regulation)',
    event_description TEXT,
    news_id INT,
    
    -- Price data before event
    price_before DECIMAL(20,8) NOT NULL,
    volume_before DECIMAL(20,8),
    
    -- Technical indicators before event
    rsi_before DECIMAL(10,4),
    macd_before DECIMAL(20,8),
    volatility_before DECIMAL(10,6),
    
    -- Market sentiment before event
    sentiment_before ENUM('positive', 'negative', 'neutral'),
    sentiment_score_before DECIMAL(5,4),
    
    -- Market impact (measured after event)
    price_change_1h DECIMAL(10,4) COMMENT 'Price change % after 1 hour',
    price_change_4h DECIMAL(10,4) COMMENT 'Price change % after 4 hours',
    price_change_24h DECIMAL(10,4) COMMENT 'Price change % after 24 hours',
    price_change_7d DECIMAL(10,4) COMMENT 'Price change % after 7 days',
    volume_change_24h DECIMAL(10,4) COMMENT 'Volume change % after 24 hours',
    
    -- Market direction after event
    market_direction ENUM('bullish', 'bearish', 'sideways') NOT NULL,
    volatility_change DECIMAL(10,4) COMMENT 'Change in volatility',
    
    -- Pattern characteristics
    pattern_strength DECIMAL(5,4) COMMENT 'Strength of the pattern (0-1)',
    reliability_score DECIMAL(5,4) COMMENT 'Historical reliability of this pattern',
    
    -- AI embeddings for similarity matching
    event_embedding TEXT COMMENT 'JSON array of event text embeddings',
    keywords TEXT COMMENT 'Extracted keywords from event',
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Indexes
    INDEX idx_pattern_date (pattern_date),
    INDEX idx_symbol (symbol),
    INDEX idx_event_type (event_type),
    INDEX idx_market_direction (market_direction),
    FOREIGN KEY (news_id) REFERENCES news_events(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: pattern_matches
-- Stores matches between current events and historical patterns
CREATE TABLE IF NOT EXISTS pattern_matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    current_news_id INT NOT NULL,
    historical_pattern_id INT NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    match_date DATETIME NOT NULL,
    
    -- Similarity metrics
    similarity_score DECIMAL(5,4) NOT NULL COMMENT 'Overall similarity (0-1)',
    text_similarity DECIMAL(5,4) COMMENT 'Text/semantic similarity',
    price_context_similarity DECIMAL(5,4) COMMENT 'Similar price context',
    indicator_similarity DECIMAL(5,4) COMMENT 'Similar technical indicators',
    sentiment_similarity DECIMAL(5,4) COMMENT 'Similar market sentiment',
    
    -- Predicted outcome based on historical pattern
    predicted_direction ENUM('bullish', 'bearish', 'sideways'),
    predicted_price_change_24h DECIMAL(10,4),
    confidence_score DECIMAL(5,4),
    
    -- Actual outcome (filled later for validation)
    actual_direction ENUM('bullish', 'bearish', 'sideways'),
    actual_price_change_24h DECIMAL(10,4),
    prediction_accuracy DECIMAL(5,4),
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes
    INDEX idx_current_news (current_news_id),
    INDEX idx_historical_pattern (historical_pattern_id),
    INDEX idx_match_date (match_date),
    INDEX idx_symbol (symbol),
    FOREIGN KEY (current_news_id) REFERENCES news_events(id) ON DELETE CASCADE,
    FOREIGN KEY (historical_pattern_id) REFERENCES historical_patterns(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: learning_insights
-- Stores learned insights and recommendations
CREATE TABLE IF NOT EXISTS learning_insights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    insight_date DATE NOT NULL,
    symbol VARCHAR(20),
    event_type VARCHAR(100),
    
    -- Learning summary
    pattern_count INT COMMENT 'Number of similar patterns found',
    avg_price_change DECIMAL(10,4) COMMENT 'Average price change from historical patterns',
    success_rate DECIMAL(5,4) COMMENT 'Success rate of predictions',
    
    -- Recommendations
    recommendation TEXT COMMENT 'AI-generated recommendation',
    risk_level ENUM('low', 'medium', 'high', 'critical'),
    confidence DECIMAL(5,4),
    
    -- Supporting data
    supporting_patterns JSON COMMENT 'IDs of supporting historical patterns',
    key_factors JSON COMMENT 'Key factors influencing the insight',
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_insight_date (insight_date),
    INDEX idx_symbol (symbol),
    INDEX idx_event_type (event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: pattern_categories
-- Categorizes different types of market events
CREATE TABLE IF NOT EXISTS pattern_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) UNIQUE NOT NULL,
    category_description TEXT,
    keywords JSON COMMENT 'Keywords associated with this category',
    typical_impact ENUM('bullish', 'bearish', 'neutral', 'mixed'),
    avg_price_change DECIMAL(10,4) COMMENT 'Historical average price change',
    occurrence_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default pattern categories
INSERT INTO pattern_categories (category_name, category_description, keywords, typical_impact) VALUES
('Interest Rate Change', 'Central bank interest rate decisions', '["interest rate", "fed", "federal reserve", "monetary policy", "rate hike", "rate cut"]', 'mixed'),
('Regulatory News', 'Government regulations and legal developments', '["regulation", "SEC", "legal", "ban", "approval", "compliance", "lawsuit"]', 'mixed'),
('ETF Approval', 'ETF and institutional investment approvals', '["ETF", "spot ETF", "bitcoin ETF", "approval", "institutional"]', 'bullish'),
('Major Hack/Security', 'Security breaches and hacks', '["hack", "breach", "stolen", "security", "exploit", "vulnerability"]', 'bearish'),
('Adoption News', 'Mainstream adoption and partnerships', '["adoption", "partnership", "integration", "payment", "merchant", "accept"]', 'bullish'),
('Technical Upgrade', 'Blockchain upgrades and forks', '["upgrade", "fork", "hardfork", "update", "merge", "consensus"]', 'mixed'),
('Whale Movement', 'Large holder transactions', '["whale", "large transfer", "moved", "billion", "institutional buy"]', 'mixed'),
('Market Crash', 'Major market downturns', '["crash", "dump", "collapse", "panic", "liquidation", "margin call"]', 'bearish'),
('Bull Run', 'Strong upward market trends', '["bull run", "all-time high", "ATH", "rally", "surge", "pump"]', 'bullish'),
('Halving Event', 'Bitcoin halving and similar events', '["halving", "reward reduction", "supply shock"]', 'bullish')
ON DUPLICATE KEY UPDATE category_name=category_name;

-- View: recent_pattern_performance
-- Shows recent pattern matching performance
-- Note: If view already exists, drop it first manually or ignore the error
DROP VIEW IF EXISTS recent_pattern_performance;

CREATE VIEW recent_pattern_performance AS
SELECT 
    pm.symbol,
    hp.event_type,
    COUNT(*) as match_count,
    AVG(pm.similarity_score) as avg_similarity,
    AVG(pm.confidence_score) as avg_confidence,
    AVG(pm.prediction_accuracy) as avg_accuracy,
    SUM(CASE WHEN pm.predicted_direction = pm.actual_direction THEN 1 ELSE 0 END) as correct_predictions,
    DATE(pm.match_date) as match_date
FROM pattern_matches pm
JOIN historical_patterns hp ON pm.historical_pattern_id = hp.id
WHERE pm.match_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
AND pm.actual_direction IS NOT NULL
GROUP BY pm.symbol, hp.event_type, DATE(pm.match_date)
ORDER BY match_date DESC;

