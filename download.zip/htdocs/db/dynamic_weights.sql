-- Dynamic Weights Table for Auto-Learning
-- يحفظ الأوزان المتغيرة لكل عامل بناءً على الأداء

CREATE TABLE IF NOT EXISTS dynamic_weights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    factor_name VARCHAR(50) NOT NULL UNIQUE,
    current_weight DECIMAL(5,4) NOT NULL DEFAULT 0.2500,
    default_weight DECIMAL(5,4) NOT NULL,
    success_count INT DEFAULT 0,
    failure_count INT DEFAULT 0,
    accuracy_rate DECIMAL(5,2) DEFAULT 0.00,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_factor (factor_name)
);

-- Initialize default weights
INSERT INTO dynamic_weights (factor_name, current_weight, default_weight) VALUES
('ai_prediction', 0.2500, 0.2500),
('volume_analysis', 0.2000, 0.2000),
('fear_greed', 0.1500, 0.1500),
('technical', 0.2000, 0.2000),
('sentiment', 0.1500, 0.1500),
('patterns', 0.0500, 0.0500)
ON DUPLICATE KEY UPDATE factor_name=factor_name;

