-- ====================================================================
-- DATABASE UPGRADE: Add News Source Credibility & Impact Tracking
-- ====================================================================
-- Run this script in phpMyAdmin if you already have the database
-- This adds professional-grade source credibility tracking

-- Add credibility and impact_level columns to news_events
ALTER TABLE news_events 
ADD COLUMN credibility DECIMAL(3,1) DEFAULT 8.0 COMMENT 'Source credibility (0.0-10.0)' AFTER sentiment_score,
ADD COLUMN impact_level ENUM('critical', 'high', 'medium', 'low') DEFAULT 'medium' COMMENT 'Market impact level' AFTER credibility;

-- Add indexes for better query performance
ALTER TABLE news_events 
ADD INDEX idx_credibility (credibility),
ADD INDEX idx_impact (impact_level);

-- Update existing news with default credibility based on source
UPDATE news_events SET credibility = 9.8, impact_level = 'high' WHERE source = 'coindesk_markets';
UPDATE news_events SET credibility = 9.7, impact_level = 'high' WHERE source = 'theblock';
UPDATE news_events SET credibility = 9.5, impact_level = 'high' WHERE source = 'cointelegraph_markets';
UPDATE news_events SET credibility = 9.0, impact_level = 'high' WHERE source = 'decrypt';
UPDATE news_events SET credibility = 9.0, impact_level = 'medium' WHERE source = 'bitcoin_magazine';
UPDATE news_events SET credibility = 8.8, impact_level = 'high' WHERE source = 'cryptoslate';
UPDATE news_events SET credibility = 8.7, impact_level = 'medium' WHERE source = 'crypto_briefing';
UPDATE news_events SET credibility = 8.5, impact_level = 'medium' WHERE source = 'bitcoinist';
UPDATE news_events SET credibility = 8.3, impact_level = 'medium' WHERE source = 'newsbtc';
UPDATE news_events SET credibility = 8.0, impact_level = 'medium' WHERE source = 'coinmarketcap';
UPDATE news_events SET credibility = 7.8, impact_level = 'low' WHERE source = 'coingecko_news';
UPDATE news_events SET credibility = 10.0, impact_level = 'critical' WHERE source = 'reuters_crypto';
UPDATE news_events SET credibility = 10.0, impact_level = 'critical' WHERE source = 'bloomberg_crypto';

-- Done!
SELECT 'Database upgraded successfully! News source credibility tracking enabled.' AS status;

