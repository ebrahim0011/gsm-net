/**
 * Crypto Market AI - Main JavaScript
 */

// Global State
const CryptoAI = {
    currentSymbol: 'BTC',
    darkMode: true,
    autoRefresh: false,
    refreshInterval: null
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Initialize Application
 */
function initializeApp() {
    console.log('Crypto Market AI initialized');
    
    // Dark mode toggle
    setupDarkModeToggle();
    
    // Refresh button
    setupRefreshButton();
    
    // Auto-refresh if enabled
    if (CryptoAI.autoRefresh) {
        startAutoRefresh();
    }
    
    // Add animations
    animateElements();
    
    // Setup tooltips
    setupTooltips();
}

/**
 * Simple Dark/Light Mode Toggle
 */
function setupDarkModeToggle() {
    const toggleBtn = document.getElementById('darkModeToggle');
    
    if (!toggleBtn) return;
    
    // Check saved preference or default to dark
    const savedMode = localStorage.getItem('cryptoAI_darkMode');
    CryptoAI.darkMode = savedMode !== null ? savedMode === 'true' : true;
    
    // Apply initial theme
    applyTheme();
    
    // Add click event
    toggleBtn.addEventListener('click', function() {
        CryptoAI.darkMode = !CryptoAI.darkMode;
        localStorage.setItem('cryptoAI_darkMode', CryptoAI.darkMode);
        applyTheme();
        
        // Show feedback
        if (typeof showNotification === 'function') {
            showNotification(CryptoAI.darkMode ? '🌙 Dark Mode' : '☀️ Light Mode', 'info');
        }
    });
}

/**
 * Apply theme changes using CSS variables
 */
function applyTheme() {
    const toggleBtn = document.getElementById('darkModeToggle');
    const html = document.documentElement;
    
    if (CryptoAI.darkMode) {
        // === DARK MODE ===
        html.removeAttribute('data-theme');
        html.style.setProperty('--bg-primary', '#111827');
        html.style.setProperty('--bg-secondary', '#1f2937');
        html.style.setProperty('--bg-tertiary', '#374151');
        html.style.setProperty('--text-primary', '#f9fafb');
        html.style.setProperty('--text-secondary', '#d1d5db');
        html.style.setProperty('--border-color', '#4b5563');
        
        if (toggleBtn) {
            toggleBtn.innerHTML = '<i class="fas fa-moon text-blue-400"></i>';
            toggleBtn.className = 'p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition dark-mode-toggle';
        }
    } else {
        // === LIGHT MODE ===
        html.setAttribute('data-theme', 'light');
        html.style.setProperty('--bg-primary', '#f9fafb');
        html.style.setProperty('--bg-secondary', '#ffffff');
        html.style.setProperty('--bg-tertiary', '#f3f4f6');
        html.style.setProperty('--text-primary', '#111827');
        html.style.setProperty('--text-secondary', '#6b7280');
        html.style.setProperty('--border-color', '#e5e7eb');
        
        if (toggleBtn) {
            toggleBtn.innerHTML = '<i class="fas fa-sun text-yellow-500"></i>';
            toggleBtn.className = 'p-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition dark-mode-toggle';
        }
    }
    
    // Apply immediate style changes
    applyImmediateThemeChanges();
    
    // Update chart colors if chart exists
    setTimeout(updateChartTheme, 100);
}

/**
 * Apply immediate theme changes to current elements
 */
function applyImmediateThemeChanges() {
    if (CryptoAI.darkMode) {
        // Dark theme
        document.body.style.backgroundColor = '#111827';
        document.body.style.color = '#f9fafb';
        
        // Update existing cards
        document.querySelectorAll('.bg-white').forEach(el => {
            el.classList.remove('bg-white');
            el.classList.add('bg-gray-800');
        });
        
        document.querySelectorAll('.text-gray-800').forEach(el => {
            el.classList.remove('text-gray-800');
            el.classList.add('text-gray-100');
        });
    } else {
        // Light theme
        document.body.style.backgroundColor = '#f9fafb';
        document.body.style.color = '#111827';
        
        // Update existing cards
        document.querySelectorAll('.bg-gray-800').forEach(el => {
            el.classList.remove('bg-gray-800');
            el.classList.add('bg-white');
        });
        
        document.querySelectorAll('.text-gray-100').forEach(el => {
            el.classList.remove('text-gray-100');
            el.classList.add('text-gray-800');
        });
        
        // Update header and footer
        const header = document.querySelector('header');
        if (header) {
            header.style.backgroundColor = '#ffffff';
            header.style.borderBottom = '1px solid #e5e7eb';
        }
        
        const footer = document.querySelector('footer');
        if (footer) {
            footer.style.backgroundColor = '#ffffff';
            footer.style.borderTop = '1px solid #e5e7eb';
        }
    }
}

/**
 * Update chart theme colors
 */
function updateChartTheme() {
    if (typeof priceChart !== 'undefined' && priceChart) {
        const textColor = CryptoAI.darkMode ? '#d1d5db' : '#374151';
        const gridColor = CryptoAI.darkMode ? '#374151' : '#e5e7eb';
        
        priceChart.options.scales.x.ticks.color = textColor;
        priceChart.options.scales.y.ticks.color = textColor;
        priceChart.options.scales.x.grid.color = gridColor;
        priceChart.options.scales.y.grid.color = gridColor;
        priceChart.update();
    }
}

/**
 * Refresh Button
 */
function setupRefreshButton() {
    const refreshBtn = document.getElementById('refreshData');
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            refreshData();
        });
    }
}

/**
 * Refresh Data (Fetch Prices & News)
 */
async function refreshData() {
    showNotification('⏳ جاري جلب البيانات... / Fetching data...', 'info');
    
    try {
        const response = await fetch('api/fetch_data.php');
        const result = await response.json();
        
        if (result.success) {
            const message = `✅ تم الجلب بنجاح!\n📊 ${result.data.price_count} أسعار / prices\n📰 ${result.data.news_count} أخبار / news`;
            showNotification(message, 'success');
            
            // Reload page after 2 seconds
            setTimeout(() => {
                window.location.reload();
            }, 2000);
        } else {
            showNotification('❌ فشل / Failed: ' + result.message, 'error');
        }
    } catch (error) {
        showNotification('❌ خطأ / Error: ' + error.message, 'error');
    }
}

/**
 * Run AI Analysis (Calculate Indicators & Predictions)
 */
async function runAnalysis() {
    showNotification('⏳ جاري التحليل... قد يستغرق 1-2 دقيقة\n⏳ Running analysis... This may take 1-2 minutes', 'info');
    
    try {
        const response = await fetch('api/run_analysis.php');
        const result = await response.json();
        
        if (result.success) {
            const data = result.data;
            
            if (data.indicators_calculated === 0 && data.predictions_generated === 0) {
                showNotification('⚠️ فشل التحليل! / Analysis failed!\nتأكد من جلب البيانات أولاً\nMake sure to fetch data first', 'warning');
            } else if (data.indicators_calculated > 0) {
                let message = '✅ اكتمل التحليل! / Analysis Complete!\n';
                message += `📊 مؤشرات / Indicators: ${data.indicators_calculated}\n`;
                message += `🤖 تنبؤات / Predictions: ${data.predictions_generated}\n`;
                message += `📰 معنويات / Sentiment: ${data.sentiment_analyzed}`;
                showNotification(message, 'success');
                
                // Reload page after 3 seconds
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            } else {
                let message = `ℹ️ تحليل جزئي / Partial analysis\n`;
                message += `📰 ${data.sentiment_analyzed} articles analyzed`;
                showNotification(message, 'info');
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            }
        } else {
            showNotification('❌ فشل / Failed: ' + result.message, 'error');
        }
    } catch (error) {
        showNotification('❌ خطأ / Error: ' + error.message, 'error');
    }
}

/**
 * Show Notification
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg transform transition-all duration-300 ${
        type === 'success' ? 'bg-green-600' :
        type === 'error' ? 'bg-red-600' :
        type === 'warning' ? 'bg-yellow-600' :
        'bg-blue-600'
    } text-white max-w-md`;
    
    // Convert line breaks to <br>
    const formattedMessage = message.replace(/\n/g, '<br>');
    
    notification.innerHTML = `
        <div class="flex items-start gap-3">
            <i class="fas fa-${
                type === 'success' ? 'check-circle' :
                type === 'error' ? 'exclamation-circle' :
                type === 'warning' ? 'exclamation-triangle' :
                'info-circle'
            } mt-1"></i>
            <div class="flex-1 text-sm">${formattedMessage}</div>
            <button onclick="this.parentElement.parentElement.remove()" class="text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
    }, 100);
    
    // Remove after 8 seconds (longer for info messages)
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 8000);
}

/**
 * Animate Elements
 */
function animateElements() {
    // Fade in elements
    const elements = document.querySelectorAll('[data-animate="fade-in"]');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('opacity-100');
                entry.target.classList.remove('opacity-0');
            }
        });
    });
    
    elements.forEach(el => {
        el.classList.add('opacity-0', 'transition-opacity', 'duration-1000');
        observer.observe(el);
    });
}

/**
 * Setup Tooltips
 */
function setupTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(el => {
        const tooltipText = el.getAttribute('data-tooltip');
        
        const tooltip = document.createElement('div');
        tooltip.className = 'absolute hidden bg-gray-800 text-white text-xs rounded py-1 px-2 z-50';
        tooltip.textContent = tooltipText;
        
        el.style.position = 'relative';
        el.appendChild(tooltip);
        
        el.addEventListener('mouseenter', () => {
            tooltip.classList.remove('hidden');
        });
        
        el.addEventListener('mouseleave', () => {
            tooltip.classList.add('hidden');
        });
    });
}

/**
 * Auto Refresh
 */
function startAutoRefresh(interval = 300000) { // 5 minutes
    if (CryptoAI.refreshInterval) {
        clearInterval(CryptoAI.refreshInterval);
    }
    
    CryptoAI.refreshInterval = setInterval(() => {
        console.log('Auto-refreshing data...');
        refreshData();
    }, interval);
}

function stopAutoRefresh() {
    if (CryptoAI.refreshInterval) {
        clearInterval(CryptoAI.refreshInterval);
        CryptoAI.refreshInterval = null;
    }
}

/**
 * Format Number
 */
function formatNumber(num, decimals = 2) {
    return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    }).format(num);
}

/**
 * Format Currency
 */
function formatCurrency(num, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(num);
}

/**
 * Format Date
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

/**
 * Copy to Clipboard
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Copied to clipboard!', 'success');
    }).catch(err => {
        showNotification('Failed to copy', 'error');
    });
}

/**
 * Export Data
 */
function exportData(data, filename) {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    
    URL.revokeObjectURL(url);
    showNotification('Data exported successfully!', 'success');
}

/**
 * Debounce Function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle Function
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export for use in other scripts
window.CryptoAI = CryptoAI;
window.showNotification = showNotification;
window.formatNumber = formatNumber;
window.formatCurrency = formatCurrency;
window.formatDate = formatDate;
window.refreshData = refreshData;
window.runAnalysis = runAnalysis;

