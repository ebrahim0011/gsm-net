<?php
/**
 * Cron Job: Evaluate Predictions
 * 
 * Run this script daily via cron
 * Example: 0 2 * * * php /path/to/cron/evaluate_predictions.php
 */

// Allow browser execution for testing
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

echo "=== تقييم التنبؤات / Evaluate Predictions ===\n";
echo "=== Evaluation Job ===\n";
echo "بدأ في / Started at: " . date('Y-m-d H:i:s') . "\n\n";

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/ai_learning.php';

try {
    $learning = new AILearning();
    
    // Evaluate predictions from last 7 days
    echo "📊 تقييم التنبؤات من آخر 7 أيام...\n";
    echo "📊 Evaluating predictions from last 7 days...\n\n";
    
    $results = $learning->evaluatePredictions(7);
    
    echo "=== النتائج / Results ===\n";
    echo "✅ تم تقييمها / Evaluated: {$results['evaluated']}\n";
    echo "✅ صحيحة / Correct: {$results['correct']}\n";
    echo "✅ خاطئة / Wrong: " . ($results['evaluated'] - $results['correct']) . "\n";
    echo "📈 الدقة / Accuracy: " . round($results['accuracy_rate'], 2) . "%\n\n";
    
    if ($results['evaluated'] == 0) {
        echo "ℹ️ لا توجد تنبؤات للتقييم حالياً\n";
        echo "ℹ️ No predictions available for evaluation\n\n";
        echo "💡 للحصول على نتائج:\n";
        echo "💡 To get results:\n";
        echo "   1. قم بتشغيل \"تشغيل التحليل\" لإنشاء تنبؤات جديدة\n";
        echo "   1. Run \"Run Analysis\" to create new predictions\n";
        echo "   2. انتظر 24-48 ساعة لجمع البيانات الفعلية\n";
        echo "   2. Wait 24-48 hours to collect actual data\n";
        echo "   3. أعد تشغيل التقييم\n";
        echo "   3. Run evaluation again\n\n";
    } elseif ($results['accuracy_rate'] >= 70) {
        echo "🎉 أداء ممتاز! / Excellent Performance!\n\n";
    } elseif ($results['accuracy_rate'] >= 50) {
        echo "👍 أداء جيد / Good Performance\n\n";
    } else {
        echo "⚠️ يحتاج تحسين / Needs Improvement\n\n";
    }
    
    // Generate learning report
    echo "📋 توليد تقرير التعلم...\n";
    echo "📋 Generating learning report...\n\n";
    $report = $learning->generateLearningReport();
    
    echo "=== التوصيات / Recommendations ===\n";
    if (!empty($report['recommendations'])) {
        foreach ($report['recommendations'] as $i => $rec) {
            // Skip irrelevant recommendations when no data exists
            if ($results['evaluated'] == 0 && strpos($rec, 'accuracy is below') !== false) {
                continue;
            }
            echo "  " . ($i + 1) . ". {$rec}\n";
        }
    } else {
        echo "  لا توجد توصيات / No recommendations at this time\n";
    }
    
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "✅ اكتملت العملية بنجاح / Job completed successfully\n";
    echo "⏰ انتهى في / Finished at: " . date('Y-m-d H:i:s') . "\n";
    echo str_repeat("=", 50) . "\n";
    
} catch (Exception $e) {
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "❌ خطأ / Error: " . $e->getMessage() . "\n";
    echo "📍 الملف / File: " . $e->getFile() . "\n";
    echo "📍 السطر / Line: " . $e->getLine() . "\n";
    echo str_repeat("=", 50) . "\n";
    if (php_sapi_name() === 'cli') {
        exit(1);
    }
}
?>

