<?php
/**
 * Cron: Update Upcoming Events
 * Run daily to fetch new events
 */

// Enable output for browser
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
}

require_once __DIR__ . '/../collector/events_scraper.php';

echo "===========================================\n";
echo "   Update Upcoming Events - Cron          \n";
echo "===========================================\n";
echo "Started: " . date('Y-m-d H:i:s') . "\n\n";

$scraper = new EventsScraper();
$result = $scraper->run();

echo "\n===========================================\n";
echo "✅ Events update completed!\n";
echo "Total events found: {$result['total_found']}\n";
echo "New events saved: {$result['saved']}\n";
echo "Finished: " . date('Y-m-d H:i:s') . "\n";
echo "===========================================\n";
?>

