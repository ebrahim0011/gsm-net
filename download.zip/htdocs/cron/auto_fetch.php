<?php
/**
 * Cron Job: Auto Fetch Data
 * 
 * Run this script every 5-15 minutes via cron
 * Example: */15 * * * * php /path/to/cron/auto_fetch.php
 */

echo "=== Auto Fetch Data Job ===\n";
echo "Started at: " . date('Y-m-d H:i:s') . "\n\n";

require_once __DIR__ . '/../collector/news_scraper.php';
require_once __DIR__ . '/../collector/price_scraper.php';
require_once __DIR__ . '/../modules/sentiment_analyzer.php';

try {
    // 1. Fetch news
    echo "1. Fetching news...\n";
    $newsScraper = new NewsScraper();
    $news = $newsScraper->fetchAllNews();
    echo "   ✓ Fetched " . count($news) . " news articles\n\n";
    
    // 2. Fetch prices
    echo "2. Fetching prices...\n";
    $priceScraper = new PriceScraper();
    $prices = $priceScraper->fetchAllPrices();
    echo "   ✓ Fetched " . count($prices) . " price records\n\n";
    
    // 3. Analyze sentiment
    echo "3. Analyzing sentiment...\n";
    $sentiment = new SentimentAnalyzer();
    $analyzed = $sentiment->analyzeNewsInDatabase(50);
    echo "   ✓ Analyzed {$analyzed} articles\n\n";
    
    echo "✓ Job completed successfully\n";
    echo "Finished at: " . date('Y-m-d H:i:s') . "\n";
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>

