<?php
/**
 * Cron Job: Auto Analysis
 * 
 * Run this script every hour via cron
 * Example: 0 * * * * php /path/to/cron/auto_analyze.php
 */

echo "=== Auto Analysis Job ===\n";
echo "Started at: " . date('Y-m-d H:i:s') . "\n\n";

require_once __DIR__ . '/../modules/technical_indicators.php';
require_once __DIR__ . '/../modules/ai_engine.php';

try {
    $symbols = ['BTC', 'ETH', 'BNB', 'SOL', 'XRP', 'ADA', 'DOGE', 'AVAX', 'DOT', 'MATIC'];
    
    // 1. Calculate technical indicators
    echo "1. Calculating technical indicators...\n";
    $technical = new TechnicalIndicators();
    
    foreach ($symbols as $symbol) {
        echo "   - {$symbol}... ";
        $technical->calculateAll($symbol);
        echo "✓\n";
    }
    echo "\n";
    
    // 2. Generate AI predictions
    echo "2. Generating AI predictions...\n";
    $ai = new AIEngine();
    
    foreach ($symbols as $symbol) {
        echo "   - {$symbol}... ";
        $prediction = $ai->predict($symbol);
        if ($prediction) {
            echo "✓ {$prediction['signal']} ({$prediction['confidence']}%)\n";
        } else {
            echo "✗\n";
        }
    }
    echo "\n";
    
    echo "✓ Job completed successfully\n";
    echo "Finished at: " . date('Y-m-d H:i:s') . "\n";
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>

