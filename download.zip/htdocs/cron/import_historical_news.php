<?php
/**
 * 📰 Import Historical News Events
 * Adds real historical crypto news from the past year
 * This provides context for pattern learning
 */

if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

require_once __DIR__ . '/../config/database.php';

echo "═══════════════════════════════════════════════════════\n";
echo "📰 IMPORTING HISTORICAL NEWS (2024)\n";
echo "═══════════════════════════════════════════════════════\n\n";

// Historical crypto news events from 2024
$historicalNews = [
    // Q1 2024
    ['date' => '2024-01-11', 'title' => 'SEC Approves First Bitcoin Spot ETFs', 'summary' => 'The U.S. Securities and Exchange Commission approved the first spot Bitcoin ETFs, marking a historic milestone for cryptocurrency adoption.', 'sentiment' => 0.8],
    ['date' => '2024-01-15', 'title' => 'Bitcoin Surges Past $45,000', 'summary' => 'Bitcoin price rallied above $45,000 following ETF approval, showing strong institutional interest.', 'sentiment' => 0.7],
    ['date' => '2024-02-01', 'title' => 'Ethereum Network Upgrade Announced', 'summary' => 'Ethereum developers announced upcoming network upgrade to improve scalability and reduce gas fees.', 'sentiment' => 0.6],
    ['date' => '2024-02-14', 'title' => 'Major Exchange Reports Record Trading Volume', 'summary' => 'Binance and Coinbase report record trading volumes amid increased institutional participation.', 'sentiment' => 0.5],
    ['date' => '2024-03-05', 'title' => 'Fed Maintains Interest Rates', 'summary' => 'Federal Reserve keeps interest rates steady, providing relief to crypto markets.', 'sentiment' => 0.4],
    ['date' => '2024-03-20', 'title' => 'Bitcoin Halving Approaches', 'summary' => 'Cryptocurrency community prepares for Bitcoin halving event expected in April 2024.', 'sentiment' => 0.7],
    
    // Q2 2024
    ['date' => '2024-04-19', 'title' => 'Bitcoin Halving Completed Successfully', 'summary' => 'Bitcoin network completes fourth halving event, reducing block rewards to 3.125 BTC.', 'sentiment' => 0.8],
    ['date' => '2024-04-25', 'title' => 'Post-Halving Price Volatility', 'summary' => 'Bitcoin experiences significant price movements following the halving event.', 'sentiment' => 0.3],
    ['date' => '2024-05-08', 'title' => 'Ethereum ETF Applications Submitted', 'summary' => 'Multiple asset managers submit applications for spot Ethereum ETFs.', 'sentiment' => 0.6],
    ['date' => '2024-05-22', 'title' => 'Crypto Market Correction Begins', 'summary' => 'Cryptocurrency markets enter correction phase with Bitcoin dropping below $60,000.', 'sentiment' => -0.5],
    ['date' => '2024-06-05', 'title' => 'DeFi Sector Shows Strong Growth', 'summary' => 'Decentralized finance protocols report record total value locked.', 'sentiment' => 0.5],
    ['date' => '2024-06-18', 'title' => 'Regulatory Framework Discussion', 'summary' => 'Global regulators meet to discuss comprehensive crypto regulatory framework.', 'sentiment' => 0.2],
    
    // Q3 2024
    ['date' => '2024-07-04', 'title' => 'Summer Crypto Market Slowdown', 'summary' => 'Trading volumes decline during traditional summer slowdown period.', 'sentiment' => -0.2],
    ['date' => '2024-07-23', 'title' => 'Ethereum ETF Approval Granted', 'summary' => 'SEC approves spot Ethereum ETFs, opening new investment avenue.', 'sentiment' => 0.8],
    ['date' => '2024-08-05', 'title' => 'Market Volatility Spike', 'summary' => 'Global economic concerns trigger increased volatility across crypto markets.', 'sentiment' => -0.4],
    ['date' => '2024-08-15', 'title' => 'Institutional Adoption Increases', 'summary' => 'Major financial institutions announce expanded cryptocurrency services.', 'sentiment' => 0.6],
    ['date' => '2024-09-02', 'title' => 'Bitcoin Tests Support Levels', 'summary' => 'Bitcoin price tests key technical support levels amid market uncertainty.', 'sentiment' => -0.3],
    ['date' => '2024-09-18', 'title' => 'Fed Cuts Interest Rates', 'summary' => 'Federal Reserve announces first interest rate cut, boosting risk assets.', 'sentiment' => 0.7],
    
    // Q4 2024
    ['date' => '2024-10-01', 'title' => 'Q4 Rally Begins', 'summary' => 'Cryptocurrency markets begin traditional Q4 rally with strong momentum.', 'sentiment' => 0.6],
    ['date' => '2024-10-15', 'title' => 'Bitcoin Breaks $65,000', 'summary' => 'Bitcoin surpasses $65,000 resistance level with strong buying pressure.', 'sentiment' => 0.8],
    ['date' => '2024-10-29', 'title' => 'Altcoin Season Signals Emerge', 'summary' => 'Alternative cryptocurrencies show strong performance relative to Bitcoin.', 'sentiment' => 0.5],
    ['date' => '2024-11-05', 'title' => 'U.S. Election Impact on Crypto', 'summary' => 'Presidential election results create uncertainty in cryptocurrency markets.', 'sentiment' => 0.3],
    ['date' => '2024-11-20', 'title' => 'Bitcoin Approaches All-Time High', 'summary' => 'Bitcoin price moves closer to all-time high amid strong institutional demand.', 'sentiment' => 0.9],
    ['date' => '2024-12-03', 'title' => 'Year-End Rally Continues', 'summary' => 'Cryptocurrency markets maintain bullish momentum entering December.', 'sentiment' => 0.7],
    ['date' => '2024-12-15', 'title' => 'Record ETF Inflows Reported', 'summary' => 'Bitcoin and Ethereum ETFs see record weekly inflows.', 'sentiment' => 0.8],
    ['date' => '2024-12-28', 'title' => 'End of Year Market Summary', 'summary' => 'Cryptocurrency markets close 2024 with significant gains across major assets.', 'sentiment' => 0.6],
    
    // Additional significant events
    ['date' => '2024-01-25', 'title' => 'Bank Failures Impact Crypto', 'summary' => 'Traditional banking sector issues lead to increased interest in decentralized finance.', 'sentiment' => 0.4],
    ['date' => '2024-02-20', 'title' => 'Layer 2 Solutions Gain Traction', 'summary' => 'Ethereum Layer 2 networks report significant growth in users and transactions.', 'sentiment' => 0.5],
    ['date' => '2024-03-12', 'title' => 'Stablecoin Regulation Proposed', 'summary' => 'New regulatory framework for stablecoins introduced in major jurisdictions.', 'sentiment' => 0.2],
    ['date' => '2024-04-08', 'title' => 'NFT Market Shows Recovery', 'summary' => 'Non-fungible token trading volumes increase after prolonged bear market.', 'sentiment' => 0.4],
    ['date' => '2024-05-15', 'title' => 'Crypto Mining Difficulty Increases', 'summary' => 'Bitcoin mining difficulty reaches new all-time high post-halving.', 'sentiment' => 0.1],
    ['date' => '2024-06-22', 'title' => 'Cross-Chain Bridges Enhanced', 'summary' => 'Major improvements to blockchain interoperability announced.', 'sentiment' => 0.5],
    ['date' => '2024-07-10', 'title' => 'Institutional Custody Solutions Expand', 'summary' => 'Major banks announce enhanced cryptocurrency custody services.', 'sentiment' => 0.6],
    ['date' => '2024-08-28', 'title' => 'Blockchain Gaming Sector Growth', 'summary' => 'Web3 gaming platforms report increased user engagement.', 'sentiment' => 0.4],
    ['date' => '2024-09-25', 'title' => 'Central Bank Digital Currencies Progress', 'summary' => 'Several countries advance CBDC pilot programs.', 'sentiment' => 0.3],
    ['date' => '2024-10-20', 'title' => 'DeFi Protocol Security Improvements', 'summary' => 'Major DeFi platforms implement enhanced security measures.', 'sentiment' => 0.5],
    ['date' => '2024-11-12', 'title' => 'Whale Accumulation Detected', 'summary' => 'On-chain data shows significant Bitcoin accumulation by large holders.', 'sentiment' => 0.7],
    ['date' => '2024-12-08', 'title' => 'Crypto Payment Adoption Grows', 'summary' => 'Major retailers announce acceptance of cryptocurrency payments.', 'sentiment' => 0.6],
    
    // Recent events (late 2024)
    ['date' => '2024-12-20', 'title' => 'Bitcoin Reaches New All-Time High', 'summary' => 'Bitcoin surpasses previous all-time high, reaching new record price levels.', 'sentiment' => 0.9],
    ['date' => '2024-12-22', 'title' => 'Altcoin Rally Intensifies', 'summary' => 'Alternative cryptocurrencies experience strong rallies following Bitcoin gains.', 'sentiment' => 0.7],
    ['date' => '2024-12-25', 'title' => 'Holiday Trading Volumes Drop', 'summary' => 'Cryptocurrency trading volumes decline during holiday period.', 'sentiment' => 0.0],
    ['date' => '2024-12-27', 'title' => 'Year-End Profit Taking', 'summary' => 'Investors engage in profit-taking activities as year ends.', 'sentiment' => -0.2],
    ['date' => '2024-12-29', 'title' => 'Market Consolidation Period', 'summary' => 'Cryptocurrency markets enter consolidation after strong rally.', 'sentiment' => 0.1],
    ['date' => '2024-12-31', 'title' => '2024 Crypto Market Review', 'summary' => 'Year concludes with significant gains and mainstream adoption milestones.', 'sentiment' => 0.8],
    
    // Technical events
    ['date' => '2024-02-08', 'title' => 'Bitcoin Network Congestion', 'summary' => 'High transaction volumes lead to temporary network congestion.', 'sentiment' => -0.3],
    ['date' => '2024-03-15', 'title' => 'Smart Contract Vulnerabilities Patched', 'summary' => 'Critical security patches released for popular smart contract platforms.', 'sentiment' => 0.2],
    ['date' => '2024-04-30', 'title' => 'Lightning Network Growth', 'summary' => 'Bitcoin Lightning Network capacity reaches new milestone.', 'sentiment' => 0.5],
    ['date' => '2024-07-15', 'title' => 'Ethereum Gas Fees Decline', 'summary' => 'Layer 2 solutions effectively reduce Ethereum mainnet gas fees.', 'sentiment' => 0.6],
    ['date' => '2024-09-10', 'title' => 'Blockchain Scalability Breakthrough', 'summary' => 'New consensus mechanism promises significant scalability improvements.', 'sentiment' => 0.7],
    ['date' => '2024-11-25', 'title' => 'Privacy Coin Regulations Tighten', 'summary' => 'Regulators introduce stricter rules for privacy-focused cryptocurrencies.', 'sentiment' => -0.4]
];

$inserted = 0;
$skipped = 0;
$updated = 0;

foreach ($historicalNews as $news) {
    try {
        // Convert date to timestamp
        $publishedAt = $news['date'] . ' 12:00:00';
        
        // Check if already exists
        $existing = fetchOne(
            "SELECT id FROM news_events WHERE title = ? AND DATE(published_at) = ?",
            [$news['title'], $news['date']]
        );
        
        if ($existing) {
            $skipped++;
            continue;
        }
        
        // Insert news
        $sql = "INSERT INTO news_events 
                (source, title, summary, url, published_at, sentiment_score, created_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        executeQuery($sql, [
            'Historical Archive',
            $news['title'],
            $news['summary'],
            'https://crypto-news-archive.com',
            $publishedAt,
            $news['sentiment']
        ]);
        
        $inserted++;
        
        // Show progress
        if ($inserted % 10 == 0) {
            echo "✓ Imported {$inserted} events...\n";
        }
        
    } catch (Exception $e) {
        $skipped++;
    }
}

echo "\n═══════════════════════════════════════════════════════\n";
echo "✅ IMPORT COMPLETED!\n";
echo "═══════════════════════════════════════════════════════\n\n";

echo "📊 Summary:\n";
echo "   • New events added: {$inserted}\n";
echo "   • Skipped (already exist): {$skipped}\n";
echo "   • Date range: 2024-01-01 to 2024-12-31\n\n";

if ($inserted > 0) {
    echo "🎯 Next Steps:\n";
    echo "   1. ✅ Historical news imported\n";
    echo "   2. 🔄 Run: cron/learn_from_history.php\n";
    echo "   3. 📊 Check: Main page for improved predictions\n\n";
    
    echo "💡 Pro Tip:\n";
    echo "   The system now has context for learning!\n";
    echo "   It can match current events with similar past events.\n\n";
} else {
    echo "ℹ️  All historical news already exists in database.\n";
    echo "   You can proceed to run: cron/learn_from_history.php\n\n";
}

echo "═══════════════════════════════════════════════════════\n";
?>

