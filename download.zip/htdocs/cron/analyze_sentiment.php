<?php
/**
 * Cron: Analyze Sentiment of News
 * Run every hour to keep sentiment data updated
 */

// Enable output for browser
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/sentiment_analyzer.php';

echo "===========================================\n";
echo "   Sentiment Analysis - Auto Update       \n";
echo "===========================================\n";
echo "Started: " . date('Y-m-d H:i:s') . "\n\n";

$analyzer = new SentimentAnalyzer();

// Analyze unanalyzed news
echo "Analyzing unanalyzed news...\n";
$analyzed = $analyzer->analyzeNewsInDatabase(100);
echo "✅ Analyzed {$analyzed} articles\n\n";

// Get current market sentiment
$sentiment = $analyzer->getMarketSentiment(24);

echo "===========================================\n";
echo "Current Market Sentiment (24h):\n";
echo "===========================================\n";
echo "Overall: " . strtoupper($sentiment['overall_sentiment']) . "\n";
echo "Score: " . $sentiment['average_score'] . "\n";
echo "Total Articles: " . $sentiment['total_articles'] . "\n\n";

echo "Breakdown:\n";
echo "  🟢 Positive: " . $sentiment['positive_percentage'] . "% ({$sentiment['breakdown']['positive']} articles)\n";
echo "  🔴 Negative: " . $sentiment['negative_percentage'] . "% ({$sentiment['breakdown']['negative']} articles)\n";
echo "  🟡 Neutral: " . $sentiment['neutral_percentage'] . "% ({$sentiment['breakdown']['neutral']} articles)\n";

echo "\n===========================================\n";
echo "✅ Sentiment analysis completed!\n";
echo "Finished: " . date('Y-m-d H:i:s') . "\n";
echo "===========================================\n";
?>

