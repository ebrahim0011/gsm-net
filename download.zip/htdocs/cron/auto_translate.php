<?php
/**
 * Simple Auto-Translate Script
 * سكريبت بسيط للترجمة التلقائية
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/simple_translator.php';

// For browser execution
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
}

echo "=== ترجمة تلقائية / Auto Translation ===\n\n";

// Translate news
echo "📰 ترجمة الأخبار...\n";
$newsCount = SimpleTranslator::autoTranslateNews();
echo "✅ تم ترجمة {$newsCount} خبر\n\n";

// Translate events
echo "📅 ترجمة الأحداث...\n";
$eventsCount = SimpleTranslator::autoTranslateEvents();
echo "✅ تم ترجمة {$eventsCount} حدث\n\n";

echo "==================================\n";
echo "✅ اكتمل! Total: " . ($newsCount + $eventsCount) . "\n";
echo "==================================\n";

// Return JSON if called via AJAX
if (isset($_GET['json'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'news' => $newsCount,
        'events' => $eventsCount,
        'total' => $newsCount + $eventsCount
    ]);
}
?>

