<?php
/**
 * Cron Job: Learn from Historical Data
 * 
 * Automatically learns from past events and builds pattern database
 * Run this periodically (e.g., daily) to keep learning from new data
 * 
 * Usage:
 * php cron/learn_from_history.php
 * 
 * Or via cron:
 * 0 2 * * * /usr/bin/php /path/to/cron/learn_from_history.php >> /path/to/logs/learning.log 2>&1
 */

// Enable output for browser viewing
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/ai_learning.php';
require_once __DIR__ . '/../modules/pattern_matcher.php';

echo "===========================================\n";
echo "   Crypto AI - Historical Learning Cron   \n";
echo "===========================================\n";
echo "Started: " . date('Y-m-d H:i:s') . "\n\n";

try {
    $aiLearning = new AILearning();
    $patternMatcher = new PatternMatcher();
    
    // Step 1: Learn from historical events
    echo "STEP 1: Learning from historical events...\n";
    echo "-------------------------------------------\n";
    
    $symbols = ['BTC', 'ETH', 'BNB', 'SOL', 'XRP'];
    $totalPatternsStored = 0;
    
    foreach ($symbols as $symbol) {
        echo "\nProcessing {$symbol}...\n";
        $stored = $aiLearning->learnFromHistory($symbol, 90);
        $totalPatternsStored += $stored;
    }
    
    echo "\n✅ Total patterns stored: {$totalPatternsStored}\n\n";
    
    // Step 2: Analyze recent events against historical patterns
    echo "STEP 2: Analyzing recent events...\n";
    echo "-------------------------------------------\n";
    
    // Get recent news from last 24 hours
    $sql = "SELECT id, title, date 
            FROM news_events 
            WHERE date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ORDER BY date DESC
            LIMIT 10";
    
    $recentNews = fetchAll($sql);
    
    if (empty($recentNews)) {
        echo "ℹ️ No recent news to analyze\n";
    } else {
        echo "Found " . count($recentNews) . " recent news items\n\n";
        
        foreach ($recentNews as $news) {
            echo "Analyzing: {$news['title']}\n";
            
            foreach ($symbols as $symbol) {
                // Find similar patterns
                $matches = $patternMatcher->findSimilarPatterns($news['id'], $symbol, 5);
                
                if (!empty($matches)) {
                    echo "  └─ {$symbol}: Found " . count($matches) . " similar patterns\n";
                    
                    // Store pattern matches
                    foreach ($matches as $match) {
                        $patternMatcher->storePatternMatch(
                            $news['id'],
                            $match['pattern']['id'],
                            $symbol,
                            $match['similarity'],
                            [
                                'direction' => $match['predicted_direction'],
                                'price_change_24h' => $match['predicted_change'],
                                'confidence' => $match['confidence']
                            ]
                        );
                    }
                }
            }
            echo "\n";
        }
    }
    
    // Step 3: Update pattern match results
    echo "STEP 3: Updating pattern match results...\n";
    echo "-------------------------------------------\n";
    
    // Find pattern matches that should now have results
    $sql = "SELECT pm.id, pm.symbol, pm.match_date, pm.predicted_direction, pm.predicted_price_change_24h
            FROM pattern_matches pm
            WHERE pm.actual_direction IS NULL
            AND pm.match_date <= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            LIMIT 100";
    
    $pendingMatches = fetchAll($sql);
    
    if (empty($pendingMatches)) {
        echo "ℹ️ No pending matches to evaluate\n";
    } else {
        $evaluated = 0;
        
        foreach ($pendingMatches as $match) {
            // Get price before and after
            $priceBefore = fetchOne(
                "SELECT close FROM market_prices 
                 WHERE symbol = ? AND timestamp <= ?
                 ORDER BY timestamp DESC LIMIT 1",
                [$match['symbol'], $match['match_date']]
            );
            
            $priceAfter = fetchOne(
                "SELECT close FROM market_prices 
                 WHERE symbol = ? 
                 AND timestamp >= DATE_ADD(?, INTERVAL 24 HOUR)
                 AND timestamp <= DATE_ADD(?, INTERVAL 26 HOUR)
                 ORDER BY timestamp ASC LIMIT 1",
                [$match['symbol'], $match['match_date'], $match['match_date']]
            );
            
            if ($priceBefore && $priceAfter) {
                $actualChange = (($priceAfter['close'] - $priceBefore['close']) / $priceBefore['close']) * 100;
                
                // Determine actual direction
                if ($actualChange > 2) {
                    $actualDirection = 'bullish';
                } elseif ($actualChange < -2) {
                    $actualDirection = 'bearish';
                } else {
                    $actualDirection = 'sideways';
                }
                
                // Calculate accuracy
                $directionCorrect = ($match['predicted_direction'] === $actualDirection) ? 1 : 0;
                $changeError = abs($match['predicted_price_change_24h'] - $actualChange);
                $accuracy = $directionCorrect * max(0, 1 - ($changeError / 100));
                
                // Update
                $updateSql = "UPDATE pattern_matches 
                             SET actual_direction = ?,
                                 actual_price_change_24h = ?,
                                 prediction_accuracy = ?
                             WHERE id = ?";
                
                executeQuery($updateSql, [
                    $actualDirection,
                    $actualChange,
                    $accuracy,
                    $match['id']
                ]);
                
                $evaluated++;
            }
        }
        
        echo "✅ Evaluated {$evaluated} pattern matches\n";
    }
    
    // Step 4: Generate performance report
    echo "\nSTEP 4: Performance Report\n";
    echo "-------------------------------------------\n";
    
    $performanceSql = "SELECT 
                          symbol,
                          COUNT(*) as total,
                          AVG(prediction_accuracy) as avg_accuracy,
                          SUM(CASE WHEN predicted_direction = actual_direction THEN 1 ELSE 0 END) / COUNT(*) as success_rate
                       FROM pattern_matches
                       WHERE actual_direction IS NOT NULL
                       AND match_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                       GROUP BY symbol
                       ORDER BY success_rate DESC";
    
    $performance = fetchAll($performanceSql);
    
    if (!empty($performance)) {
        echo "\n📊 Last 7 Days Performance:\n\n";
        foreach ($performance as $perf) {
            echo "{$perf['symbol']}:\n";
            echo "  Predictions: {$perf['total']}\n";
            echo "  Success Rate: " . round($perf['success_rate'] * 100, 1) . "%\n";
            echo "  Avg Accuracy: " . round($perf['avg_accuracy'] * 100, 1) . "%\n\n";
        }
    }
    
    // Step 5: Cleanup old data (optional)
    echo "STEP 5: Cleanup\n";
    echo "-------------------------------------------\n";
    
    // Delete pattern matches older than 90 days
    $deleteSql = "DELETE FROM pattern_matches 
                  WHERE match_date < DATE_SUB(NOW(), INTERVAL 90 DAY)";
    executeQuery($deleteSql);
    
    echo "✅ Cleaned up old pattern matches\n";
    
    echo "\n===========================================\n";
    echo "✅ Learning process completed successfully!\n";
    echo "Finished: " . date('Y-m-d H:i:s') . "\n";
    echo "===========================================\n";
    
} catch (Exception $e) {
    echo "\n❌ ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
?>

