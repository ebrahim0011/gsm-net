<?php
/**
 * Import Historical Data - One Time Setup
 * Fetches 3 months of historical prices and news
 */

// Enable output for browser
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=utf-8');
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
    set_time_limit(300); // 5 minutes
}

require_once __DIR__ . '/../config/database.php';

echo "===========================================\n";
echo "   Import Historical Data (3 Months)      \n";
echo "===========================================\n\n";

$symbols = ['BTC', 'ETH', 'BNB', 'SOL', 'XRP'];
$days = 90; // 3 months
$totalPrices = 0;

// CoinGecko API (Free - no key needed)
function fetchHistoricalPrices($symbol, $days) {
    $coinIds = [
        'BTC' => 'bitcoin',
        'ETH' => 'ethereum',
        'BNB' => 'binancecoin',
        'SOL' => 'solana',
        'XRP' => 'ripple'
    ];
    
    $coinId = $coinIds[$symbol] ?? strtolower($symbol);
    $url = "https://api.coingecko.com/api/v3/coins/{$coinId}/market_chart?vs_currency=usd&days={$days}&interval=daily";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response) {
        return json_decode($response, true);
    }
    return null;
}

foreach ($symbols as $symbol) {
    echo "\nFetching {$symbol} historical data...\n";
    echo "-------------------------------------------\n";
    
    $data = fetchHistoricalPrices($symbol, $days);
    
    if (!$data || !isset($data['prices'])) {
        echo "❌ Failed to fetch data for {$symbol}\n";
        continue;
    }
    
    $prices = $data['prices'];
    $volumes = $data['total_volumes'] ?? [];
    
    $stored = 0;
    
    foreach ($prices as $index => $priceData) {
        $timestamp = date('Y-m-d H:i:s', $priceData[0] / 1000);
        $close = $priceData[1];
        $volume = isset($volumes[$index]) ? $volumes[$index][1] : 0;
        
        // Use close as open/high/low (simplified)
        $open = $close;
        $high = $close * 1.01; // Approximate
        $low = $close * 0.99;
        
        try {
            $sql = "INSERT INTO market_prices 
                    (symbol, timestamp, open, high, low, close, volume, market_cap)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                    close = VALUES(close),
                    volume = VALUES(volume)";
            
            executeQuery($sql, [
                $symbol,
                $timestamp,
                $open,
                $high,
                $low,
                $close,
                $volume,
                0
            ]);
            
            $stored++;
            
            if ($stored % 10 == 0) {
                echo ".";
            }
            
        } catch (Exception $e) {
            // Skip duplicates silently
        }
    }
    
    echo "\n✅ Stored {$stored} price records for {$symbol}\n";
    $totalPrices += $stored;
    
    // Rate limiting (CoinGecko: 10-50 calls/minute)
    sleep(2);
}

echo "\n\n===========================================\n";
echo "✅ Total: {$totalPrices} price records imported\n";
echo "===========================================\n\n";

// Sample historical news (manually added for context)
echo "Adding sample historical news...\n";
echo "-------------------------------------------\n";

$sampleNews = [
    [
        'title' => 'Bitcoin ETF Approval Wave Continues',
        'summary' => 'Major institutional ETF approvals drive market optimism',
        'date' => date('Y-m-d H:i:s', strtotime('-60 days')),
        'sentiment' => 'positive',
        'sentiment_score' => 0.85
    ],
    [
        'title' => 'Fed Raises Interest Rates',
        'summary' => 'Federal Reserve increases rates affecting crypto markets',
        'date' => date('Y-m-d H:i:s', strtotime('-45 days')),
        'sentiment' => 'negative',
        'sentiment_score' => -0.65
    ],
    [
        'title' => 'Major Exchange Security Breach',
        'summary' => 'Security incident causes market volatility',
        'date' => date('Y-m-d H:i:s', strtotime('-30 days')),
        'sentiment' => 'negative',
        'sentiment_score' => -0.80
    ],
    [
        'title' => 'Institutional Adoption Increases',
        'summary' => 'Major corporations announce crypto integration',
        'date' => date('Y-m-d H:i:s', strtotime('-15 days')),
        'sentiment' => 'positive',
        'sentiment_score' => 0.75
    ],
    [
        'title' => 'Blockchain Upgrade Successfully Completed',
        'summary' => 'Major network upgrade improves scalability',
        'date' => date('Y-m-d H:i:s', strtotime('-7 days')),
        'sentiment' => 'positive',
        'sentiment_score' => 0.70
    ]
];

$newsStored = 0;
foreach ($sampleNews as $news) {
    try {
        $sql = "INSERT INTO news_events 
                (title, summary, content, link, source, date, sentiment, sentiment_score, credibility, impact_level)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        executeQuery($sql, [
            $news['title'],
            $news['summary'],
            $news['summary'],
            'https://example.com/' . md5($news['title']),
            'Historical Data',
            $news['date'],
            $news['sentiment'],
            $news['sentiment_score'],
            7.0,
            'medium'
        ]);
        
        $newsStored++;
        echo "✓ Added: {$news['title']}\n";
        
    } catch (Exception $e) {
        // Skip duplicates
    }
}

echo "\n✅ Added {$newsStored} sample news items\n";

echo "\n\n===========================================\n";
echo "🎉 Import Complete!                        \n";
echo "===========================================\n";
echo "Total Prices: {$totalPrices}\n";
echo "Total News: {$newsStored}\n";
echo "\nNext Steps:\n";
echo "1. Run: cron/learn_from_history.php\n";
echo "2. Open: index.php\n";
echo "===========================================\n";
?>

