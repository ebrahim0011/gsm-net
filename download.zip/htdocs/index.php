<!DOCTYPE html>
<?php
// Language switcher
$lang = $_GET['lang'] ?? $_COOKIE['lang'] ?? 'ar';
setcookie('lang', $lang, time() + (86400 * 30), '/');
$isRTL = ($lang === 'ar');
?>
<html lang="<?= $lang ?>" dir="<?= $isRTL ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $isRTL ? 'تحليل سوق العملات الرقمية بالذكاء الاصطناعي' : 'Crypto Market AI Analysis' ?></title>
    <!-- Arabic Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        body[dir="rtl"] { font-family: 'Cairo', sans-serif; }
        .rtl-flip { transform: scaleX(-1); }
        [dir="rtl"] .chart-container { direction: ltr; }
        
        /* Tabs styling */
        .tab-btn {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .tab-btn:hover {
            color: #60a5fa !important;
        }
        
        /* Countdown animation */
        .countdown-timer .seconds {
            animation: pulse 1s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Enhanced Dark/Light Mode Support */
        .theme-transition * {
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease !important;
        }
        
        /* Dark Mode Toggle Animation */
        .dark-mode-toggle {
            transition: all 0.3s ease !important;
        }
        
        .dark-mode-toggle:hover {
            transform: rotate(15deg) scale(1.1);
        }
        
        /* Progress Step Animations */
        .progress-step .step-active {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6) !important;
            color: white !important;
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.6);
            animation: pulse-glow 1.5s ease-in-out infinite;
        }
        
        .progress-step .step-completed {
            background: linear-gradient(135deg, #10b981, #059669) !important;
            color: white !important;
            animation: check-bounce 0.6s ease-out;
        }
        
        .progress-step .text-active {
            color: #60a5fa !important;
            font-weight: 600;
        }
        
        .progress-step .text-completed {
            color: #10b981 !important;
        }
        
        .connector-active {
            background: linear-gradient(90deg, #3b82f6, #8b5cf6) !important;
            box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
        }
        
        .connector-completed {
            background: linear-gradient(90deg, #10b981, #059669) !important;
        }
        
        @keyframes pulse-glow {
            0%, 100% { 
                transform: scale(1);
                box-shadow: 0 0 20px rgba(59, 130, 246, 0.6);
            }
            50% { 
                transform: scale(1.1);
                box-shadow: 0 0 30px rgba(59, 130, 246, 0.9);
            }
        }
        
        @keyframes check-bounce {
            0% { transform: scale(0.8); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
        
        @keyframes slide-in {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        #smartUpdateProgress {
            animation: slide-in 0.3s ease-out;
        }
        
        /* Light Mode Overrides */
        [data-theme="light"] .bg-gray-900 { background-color: #f9fafb !important; }
        [data-theme="light"] .bg-gray-800 { background-color: #ffffff !important; border: 1px solid #e5e7eb !important; }
        [data-theme="light"] .bg-gray-700 { background-color: #f3f4f6 !important; }
        [data-theme="light"] .text-gray-100 { color: #111827 !important; }
        [data-theme="light"] .text-gray-400 { color: #6b7280 !important; }
        [data-theme="light"] .text-gray-300 { color: #4b5563 !important; }
        
        /* Chart container theme */
        .chart-container {
            transition: background-color 0.3s ease;
        }
        
        [data-theme="light"] .chart-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
        }
    </style>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-900 text-gray-100 theme-transition">
    
    <?php
    require_once __DIR__ . '/config/database.php';
    require_once __DIR__ . '/modules/ai_engine.php';
    require_once __DIR__ . '/modules/sentiment_analyzer.php';
    require_once __DIR__ . '/modules/technical_indicators.php';
    require_once __DIR__ . '/modules/pattern_matcher.php';
    require_once __DIR__ . '/modules/ai_learning.php';
    require_once __DIR__ . '/collector/price_scraper.php';
    require_once __DIR__ . '/collector/news_scraper.php';
    
    // Get selected symbol (default BTC)
    $selectedSymbol = $_GET['symbol'] ?? 'BTC';
    
    // Get AI prediction
    $ai = new AIEngine();
    $prediction = $ai->getLatestPrediction($selectedSymbol);
    
    // Debug: Count total predictions in database
    $totalPredictions = fetchOne("SELECT COUNT(*) as count FROM ai_predictions")['count'] ?? 0;
    
    // Get market sentiment
    $sentiment = new SentimentAnalyzer();
    
    // Auto-analyze unanalyzed news (max 20 per page load)
    $sentiment->analyzeNewsInDatabase(20);
    
    $marketSentiment = $sentiment->getMarketSentiment(24);
    
    // Get technical indicators
    $technical = new TechnicalIndicators();
    $indicators = $technical->getLatestIndicators($selectedSymbol);
    
    // Get price data
    $priceScraper = new PriceScraper();
    $latestPrice = $priceScraper->getLatestPrice($selectedSymbol);
    $priceHistory = $priceScraper->getRecentPrices($selectedSymbol, 168); // 7 days
    
    // Get recent news (with translations if Arabic)
    $newsScraper = new NewsScraper();
    $recentNews = $newsScraper->getRecentNews(10, 48);
    
    // Include simple translator for Arabic
    if ($isRTL) {
        require_once __DIR__ . '/modules/simple_translator.php';
    }
    
    // Get historical learning data
    $patternMatcher = new PatternMatcher();
    $historicalLearning = null;
    try {
        $historicalLearning = $patternMatcher->getLearningSum($selectedSymbol);
    } catch (Exception $e) {
        // Handle gracefully if no patterns exist yet
        $historicalLearning = null;
    }
    
    // Available symbols (matching price_scraper.php)
    $symbols = [
        'BTC', 'ETH', 'BNB', 'SOL', 'XRP', 'ADA', 'DOGE', 'AVAX', 'DOT', 'MATIC',
        'LINK', 'UNI', 'LTC', 'ATOM', 'TRX', 'SHIB', 'FTM', 'ALGO', 'VET', 'NEAR'
    ];
    
    // Translations
    $t = [
        'title' => $isRTL ? 'تحليل سوق الكريبتو بالذكاء الاصطناعي' : 'Crypto Market AI',
        'refresh' => $isRTL ? 'تحديث' : 'Refresh',
        'price' => $isRTL ? 'السعر' : 'Price',
        'volume' => $isRTL ? 'حجم التداول' : 'Volume',
        'technical_indicators' => $isRTL ? 'المؤشرات الفنية' : 'Technical Indicators',
        'ai_signal' => $isRTL ? 'إشارة الذكاء الاصطناعي' : 'AI Market Signal',
        'confidence' => $isRTL ? 'نسبة الثقة' : 'Confidence Score',
        'market_sentiment' => $isRTL ? 'معنويات السوق' : 'Market Sentiment',
        'recent_news' => $isRTL ? 'آخر الأخبار' : 'Recent News',
        'bullish' => $isRTL ? 'صاعد' : 'Bullish',
        'bearish' => $isRTL ? 'هابط' : 'Bearish',
        'sideways' => $isRTL ? 'جانبي' : 'Sideways',
        'positive' => $isRTL ? 'إيجابي' : 'Positive',
        'negative' => $isRTL ? 'سلبي' : 'Negative',
        'neutral' => $isRTL ? 'محايد' : 'Neutral',
        'key_factors' => $isRTL ? 'العوامل الرئيسية' : 'Key Factors',
        'quick_actions' => $isRTL ? 'إجراءات سريعة' : 'Quick Actions',
        'fetch_data' => $isRTL ? 'جلب أحدث البيانات' : 'Fetch Latest Data',
        'run_analysis' => $isRTL ? 'تشغيل التحليل' : 'Run AI Analysis',
        'admin_panel' => $isRTL ? 'لوحة الإدارة' : 'Admin Dashboard'
    ];
    ?>
    
    <!-- Header -->
    <header class="bg-gray-800 shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <i class="fas fa-brain text-blue-500 text-3xl"></i>
                    <h1 class="text-2xl font-bold text-white"><?= $t['title'] ?></h1>
                </div>
                
                <div class="flex items-center gap-3">
                    <a href="?lang=<?= $isRTL ? 'en' : 'ar' ?>&symbol=<?= $selectedSymbol ?>" class="px-3 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition">
                        <i class="fas fa-language"></i> <?= $isRTL ? 'EN' : 'ع' ?>
                    </a>
                    <button id="darkModeToggle" class="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 dark-mode-toggle" title="Toggle Dark/Light Mode">
                        <i class="fas fa-moon text-blue-400"></i>
                    </button>
                    <button id="refreshData" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg">
                        <i class="fas fa-sync-alt"></i> <?= $t['refresh'] ?>
                    </button>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Main Content -->
    <main class="container mx-auto px-4 py-6">
        
        <!-- Symbol Selector -->
        <div class="mb-6">
            <div class="flex items-center space-x-2 overflow-x-auto pb-2">
                <?php foreach ($symbols as $symbol): ?>
                    <a href="?symbol=<?= $symbol ?>" 
                       class="px-4 py-2 rounded-lg <?= $symbol === $selectedSymbol ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700' ?> whitespace-nowrap">
                        <?= $symbol ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Main Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <!-- Left Column - Charts & Analysis -->
            <div class="lg:col-span-2 space-y-6">
                
                <!-- Price Card -->
                <div class="bg-gray-800 rounded-xl shadow-xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h2 class="text-3xl font-bold"><?= $selectedSymbol ?>/USD</h2>
                            <p class="text-4xl font-bold text-white mt-2" id="livePrice">
                                <span class="loading-pulse">$<?= $latestPrice ? number_format($latestPrice['close'], 2) : '...' ?></span>
                                </p>
                                <p class="text-gray-400 text-sm mt-1">
                                <span id="priceTime"><?= $isRTL ? 'مباشر' : 'Live' ?></span>
                                <span class="ml-2 px-2 py-1 bg-green-600 rounded-full text-xs animate-pulse">●</span>
                                </p>
                        </div>
                        <div class="text-right">
                            <div class="text-sm text-gray-400">24h Volume</div>
                            <div class="text-xl font-bold">
                                $<?= $latestPrice ? number_format($latestPrice['volume'], 0) : '0' ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Price Chart -->
                    <div class="h-80">
                        <canvas id="priceChart"></canvas>
                    </div>
                </div>
                
                <!-- Market Forecast Card - NEW -->
                <div class="bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 rounded-xl shadow-2xl p-6 border-2 border-purple-400">
                    <h3 class="text-2xl font-bold mb-4 text-center">
                        <i class="fas fa-crystal-ball text-purple-300"></i>
                        <?= $isRTL ? '📊 توقع السوق الشامل' : '📊 Comprehensive Market Forecast' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-purple-600 rounded-full animate-pulse"><?= $isRTL ? 'جديد' : 'NEW' ?></span>
                    </h3>
                    
                    <div id="market-forecast-content" class="space-y-4">
                        <div class="text-center py-8">
                            <div class="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-purple-300"></div>
                            <p class="text-gray-300 mt-2"><?= $isRTL ? 'جارٍ تحليل السوق...' : 'Analyzing market...' ?></p>
                        </div>
                    </div>
                    
                    <!-- Quick Actions Integrated -->
                    <div class="mt-6 border-t-2 border-purple-500 pt-6">
                        <h4 class="text-lg font-bold mb-3 text-purple-300 flex items-center gap-2">
                            <i class="fas fa-bolt"></i>
                            <?= $isRTL ? '⚡ إجراءات سريعة' : '⚡ Quick Actions' ?>
                        </h4>
                        
                        <!-- Smart Update Button -->
                        <button onclick="smartUpdate()" id="smartUpdateBtn" class="w-full px-6 py-4 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 rounded-lg transition font-bold shadow-lg hover:shadow-xl transform hover:scale-105 text-lg">
                            <i class="fas fa-magic"></i> <?= $isRTL ? '✨ تحديث ذكي شامل' : '✨ Smart Full Update' ?>
                            <div class="text-xs mt-1 opacity-80"><?= $isRTL ? '(البيانات + التحليل + التوقع)' : '(Data + Analysis + Forecast)' ?></div>
                        </button>
                        
                        <!-- Progress Bar -->
                        <div id="smartUpdateProgress" class="mt-4 hidden">
                            <div class="bg-gray-700 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-3">
                                    <span class="text-sm font-bold" id="progressTitle">
                                        <?= $isRTL ? '⚡ جاري التحديث الذكي...' : '⚡ Smart Update in Progress...' ?>
                                    </span>
                                    <span class="text-xs text-gray-400" id="progressPercent">0%</span>
                                </div>
                                
                                <!-- Progress Steps -->
                                <div class="flex items-center justify-between mb-4 gap-2">
                                    <!-- Step 1: Fetch Data -->
                                    <div class="flex-1 flex flex-col items-center progress-step" id="step1">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all duration-500 bg-gray-600 text-gray-400">
                                            <i class="fas fa-download text-sm"></i>
                                        </div>
                                        <div class="text-xs text-center text-gray-400 transition-colors duration-500">
                                            <?= $isRTL ? 'جلب البيانات' : 'Fetch Data' ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Connector 1 -->
                                    <div class="flex-grow h-1 bg-gray-600 rounded transition-all duration-500" id="connector1"></div>
                                    
                                    <!-- Step 2: Analysis -->
                                    <div class="flex-1 flex flex-col items-center progress-step" id="step2">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all duration-500 bg-gray-600 text-gray-400">
                                            <i class="fas fa-brain text-sm"></i>
                                        </div>
                                        <div class="text-xs text-center text-gray-400 transition-colors duration-500">
                                            <?= $isRTL ? 'التحليل' : 'Analysis' ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Connector 2 -->
                                    <div class="flex-grow h-1 bg-gray-600 rounded transition-all duration-500" id="connector2"></div>
                                    
                                    <!-- Step 3: Result -->
                                    <div class="flex-1 flex flex-col items-center progress-step" id="step3">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all duration-500 bg-gray-600 text-gray-400">
                                            <i class="fas fa-chart-line text-sm"></i>
                                        </div>
                                        <div class="text-xs text-center text-gray-400 transition-colors duration-500">
                                            <?= $isRTL ? 'النتيجة' : 'Result' ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Overall Progress Bar -->
                                <div class="w-full bg-gray-600 rounded-full h-2 overflow-hidden">
                                    <div id="overallProgressBar" class="bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 h-full rounded-full transition-all duration-700 ease-out" style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Admin Panel Link -->
                        <div class="mt-4">
                            <a href="admin.php" class="block w-full px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-center transition text-sm">
                                <i class="fas fa-cog"></i> <?= $isRTL ? '⚙️ لوحة الإدارة' : '⚙️ Admin Panel' ?>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Technical Indicators -->
                <div class="bg-gray-800 rounded-xl shadow-xl p-6">
                    <h3 class="text-xl font-bold mb-4">
                        <i class="fas fa-chart-line text-blue-500"></i> <?= $t['technical_indicators'] ?>
                    </h3>
                    
                    <?php if ($indicators): ?>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div class="bg-gray-700 rounded-lg p-4">
                                <div class="text-sm text-gray-400">RSI (14)</div>
                                <div class="text-2xl font-bold mt-1 <?= $indicators['rsi'] < 30 ? 'text-green-500' : ($indicators['rsi'] > 70 ? 'text-red-500' : 'text-yellow-500') ?>">
                                    <?= number_format($indicators['rsi'], 2) ?>
                                </div>
                                <div class="text-xs mt-1 <?= $indicators['rsi'] < 30 ? 'text-green-400' : ($indicators['rsi'] > 70 ? 'text-red-400' : 'text-yellow-400') ?>">
                                    <?= $indicators['rsi'] < 30 ? 'Oversold' : ($indicators['rsi'] > 70 ? 'Overbought' : 'Neutral') ?>
                                </div>
                            </div>
                            
                            <div class="bg-gray-700 rounded-lg p-4">
                                <div class="text-sm text-gray-400">MACD</div>
                                <div class="text-2xl font-bold mt-1 <?= $indicators['macd'] > $indicators['macd_signal'] ? 'text-green-500' : 'text-red-500' ?>">
                                    <?= number_format($indicators['macd'], 2) ?>
                                </div>
                                <div class="text-xs mt-1 <?= $indicators['macd'] > $indicators['macd_signal'] ? 'text-green-400' : 'text-red-400' ?>">
                                    <?= $indicators['macd'] > $indicators['macd_signal'] ? 'Bullish' : 'Bearish' ?>
                                </div>
                            </div>
                            
                            <div class="bg-gray-700 rounded-lg p-4">
                                <div class="text-sm text-gray-400">EMA 12</div>
                                <div class="text-2xl font-bold mt-1 text-blue-500">
                                    $<?= number_format($indicators['ema_12'], 2) ?>
                                </div>
                            </div>
                            
                            <div class="bg-gray-700 rounded-lg p-4">
                                <div class="text-sm text-gray-400">Volatility</div>
                                <div class="text-2xl font-bold mt-1 text-purple-500">
                                    <?= number_format($indicators['volatility'], 4) ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Bollinger Bands -->
                        <div class="mt-4 bg-gray-700 rounded-lg p-4">
                            <div class="text-sm text-gray-400 mb-2">Bollinger Bands</div>
                            <div class="flex items-center justify-between text-sm">
                                <div>
                                    <span class="text-gray-400"><?= $isRTL ? 'العلوي:' : 'Upper:' ?></span>
                                    <span class="font-bold ml-2 text-red-400">$<?= number_format($indicators['bb_upper'], 2) ?></span>
                                </div>
                                <div>
                                    <span class="text-gray-400"><?= $isRTL ? 'الوسط:' : 'Middle:' ?></span>
                                    <span class="font-bold ml-2 text-blue-400">$<?= number_format($indicators['bb_middle'], 2) ?></span>
                                </div>
                                <div>
                                    <span class="text-gray-400"><?= $isRTL ? 'السفلي:' : 'Lower:' ?></span>
                                    <span class="font-bold ml-2 text-green-400">$<?= number_format($indicators['bb_lower'], 2) ?></span>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-400"><?= $isRTL ? 'لا توجد مؤشرات متاحة. يرجى تشغيل الحاسبة.' : 'No technical indicators available. Please run the calculator.' ?></p>
                    <?php endif; ?>
                </div>
                
                <!-- AI Historical Learning Section -->
                <div class="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-xl shadow-xl p-6 border-2 border-purple-500">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-xl font-bold">
                        <i class="fas fa-brain text-purple-400"></i> <?= $isRTL ? 'التعلم الذكي من الماضي' : 'AI Learning from History' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-purple-600 rounded-full"><?= $isRTL ? 'جديد' : 'NEW' ?></span>
                    </h3>
                        <button onclick="toggleLearningContent()" class="px-3 py-1 bg-purple-600 hover:bg-purple-700 rounded-lg text-sm transition-colors duration-200 flex items-center gap-2">
                            <i id="learningToggleIcon" class="fas fa-eye"></i>
                            <span id="learningToggleText"><?= $isRTL ? 'إظهار' : 'Show' ?></span>
                        </button>
                    </div>
                    
                    <div id="learningContent" class="hidden">
                    
                    <?php if ($historicalLearning && $historicalLearning['pattern_count'] > 0): ?>
                        <?php
                        $hlDirection = $historicalLearning['predicted_direction'];
                        $hlChange = $historicalLearning['predicted_change'];
                        $hlConfidence = $historicalLearning['confidence'] * 100;
                        $hlColor = $hlDirection === 'bullish' ? 'green' : ($hlDirection === 'bearish' ? 'red' : 'gray');
                        ?>
                        
                        <!-- Main Prediction from History -->
                        <div class="bg-gray-900 bg-opacity-50 rounded-lg p-4 mb-4">
                            <div class="flex items-center justify-between mb-3">
                                <div>
                                    <div class="text-sm text-gray-300 mb-1">
                                        <?= $isRTL ? 'التوقع المستند إلى' : 'Based on' ?> 
                                        <span class="font-bold text-purple-400"><?= $historicalLearning['pattern_count'] ?></span>
                                        <?= $isRTL ? 'نمط تاريخي مشابه' : 'similar historical patterns' ?>
                                    </div>
                                    <div class="inline-block px-4 py-2 rounded-lg bg-<?= $hlColor ?>-600 text-white font-bold">
                                        <?= $hlDirection === 'bullish' ? ($isRTL ? '🚀 صاعد' : '🚀 Bullish') : ($hlDirection === 'bearish' ? ($isRTL ? '📉 هابط' : '📉 Bearish') : ($isRTL ? '➡️ جانبي' : '➡️ Sideways')) ?>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-sm text-gray-400"><?= $isRTL ? 'التغير المتوقع (24 ساعة)' : 'Expected Change (24h)' ?></div>
                                    <div class="text-2xl font-bold text-<?= $hlColor ?>-400">
                                        <?= $hlChange > 0 ? '+' : '' ?><?= number_format($hlChange, 2) ?>%
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Confidence Bar -->
                            <div class="mb-3">
                                <div class="flex justify-between text-xs text-gray-400 mb-1">
                                    <span><?= $isRTL ? 'مستوى الثقة' : 'Confidence Level' ?></span>
                                    <span><?= number_format($hlConfidence, 1) ?>%</span>
                                </div>
                                <div class="h-2 bg-gray-700 rounded-full overflow-hidden">
                                    <div class="h-full bg-purple-500" style="width: <?= $hlConfidence ?>%"></div>
                                </div>
                            </div>
                            
                            <!-- Recommendation -->
                            <div class="mt-3 p-3 bg-gray-800 bg-opacity-70 rounded-lg border-l-4 border-<?= $hlColor ?>-500">
                                <div class="text-sm text-gray-300">
                                    <?= htmlspecialchars($historicalLearning['recommendation']) ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Analysis Breakdown - WHY this prediction? -->
                        <div class="bg-indigo-900 bg-opacity-40 rounded-lg p-4 mb-4 border border-indigo-500">
                            <div class="text-sm font-bold text-indigo-300 mb-3 flex items-center gap-2">
                                <i class="fas fa-lightbulb"></i>
                                <?= $isRTL ? '🔍 لماذا هذا التوقع؟' : '🔍 Why this prediction?' ?>
                            </div>
                            
                            <div class="grid grid-cols-2 gap-3 text-xs">
                                <?php 
                                // Calculate similarity factors breakdown
                                $patterns = $historicalLearning['similar_patterns'];
                                $avgSimilarity = isset($patterns[0]) ? $patterns[0]['similarity'] : [];
                                ?>
                                
                                <!-- Event Type Match -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                    <div class="text-gray-400 mb-1"><?= $isRTL ? 'نوع الحدث' : 'Event Type' ?></div>
                                    <div class="flex items-center gap-2">
                                        <?php $eventScore = ($avgSimilarity['event_type'] ?? 0.7) * 100; ?>
                                        <div class="flex-1 h-1.5 bg-gray-700 rounded-full">
                                            <div class="h-full bg-purple-500 rounded-full" style="width: <?= $eventScore ?>%"></div>
                                        </div>
                                        <span class="text-white font-bold"><?= number_format($eventScore, 0) ?>%</span>
                                    </div>
                                </div>
                                
                                <!-- Keywords Match -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                    <div class="text-gray-400 mb-1"><?= $isRTL ? 'الكلمات المفتاحية' : 'Keywords' ?></div>
                                    <div class="flex items-center gap-2">
                                        <?php $keywordScore = ($avgSimilarity['keywords'] ?? 0.65) * 100; ?>
                                        <div class="flex-1 h-1.5 bg-gray-700 rounded-full">
                                            <div class="h-full bg-blue-500 rounded-full" style="width: <?= $keywordScore ?>%"></div>
                                        </div>
                                        <span class="text-white font-bold"><?= number_format($keywordScore, 0) ?>%</span>
                                    </div>
                                </div>
                                
                                <!-- Technical Indicators -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                    <div class="text-gray-400 mb-1"><?= $isRTL ? 'المؤشرات الفنية' : 'Technical' ?></div>
                                    <div class="flex items-center gap-2">
                                        <?php $techScore = ($avgSimilarity['technical'] ?? 0.72) * 100; ?>
                                        <div class="flex-1 h-1.5 bg-gray-700 rounded-full">
                                            <div class="h-full bg-green-500 rounded-full" style="width: <?= $techScore ?>%"></div>
                                        </div>
                                        <span class="text-white font-bold"><?= number_format($techScore, 0) ?>%</span>
                                    </div>
                                </div>
                                
                                <!-- Sentiment Match -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                    <div class="text-gray-400 mb-1"><?= $isRTL ? 'المعنويات' : 'Sentiment' ?></div>
                                    <div class="flex items-center gap-2">
                                        <?php $sentScore = ($avgSimilarity['sentiment'] ?? 0.68) * 100; ?>
                                        <div class="flex-1 h-1.5 bg-gray-700 rounded-full">
                                            <div class="h-full bg-yellow-500 rounded-full" style="width: <?= $sentScore ?>%"></div>
                                        </div>
                                        <span class="text-white font-bold"><?= number_format($sentScore, 0) ?>%</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-3 text-xs text-gray-300 bg-gray-800 bg-opacity-30 rounded p-2">
                                <i class="fas fa-info-circle text-indigo-400"></i>
                                <?= $isRTL ? 'يستخدم النظام هذه العوامل لإيجاد أنماط مشابهة من الماضي' : 'The system uses these factors to find similar patterns from the past' ?>
                            </div>
                        </div>
                        
                        <!-- Pattern Statistics -->
                        <div class="bg-gray-900 bg-opacity-50 rounded-lg p-3 mb-4">
                            <div class="text-sm font-semibold text-gray-300 mb-3 flex items-center gap-2">
                                <i class="fas fa-chart-pie"></i>
                                <?= $isRTL ? '📊 توزيع الأنماط المشابهة' : '📊 Pattern Distribution' ?>
                            </div>
                            
                            <?php
                            // Calculate pattern direction distribution
                            $bullishCount = 0;
                            $bearishCount = 0;
                            $sidewaysCount = 0;
                            foreach ($historicalLearning['similar_patterns'] as $p) {
                                if ($p['pattern']['market_direction'] === 'bullish') $bullishCount++;
                                elseif ($p['pattern']['market_direction'] === 'bearish') $bearishCount++;
                                else $sidewaysCount++;
                            }
                            $total = $bullishCount + $bearishCount + $sidewaysCount;
                            ?>
                            
                            <div class="grid grid-cols-3 gap-2 text-xs">
                                <div class="text-center bg-green-900 bg-opacity-30 rounded p-2">
                                    <div class="text-2xl font-bold text-green-400"><?= $bullishCount ?></div>
                                    <div class="text-gray-400"><?= $isRTL ? 'صاعدة' : 'Bullish' ?></div>
                                    <div class="text-green-400 text-xs"><?= $total > 0 ? number_format(($bullishCount/$total)*100, 0) : 0 ?>%</div>
                                </div>
                                <div class="text-center bg-red-900 bg-opacity-30 rounded p-2">
                                    <div class="text-2xl font-bold text-red-400"><?= $bearishCount ?></div>
                                    <div class="text-gray-400"><?= $isRTL ? 'هابطة' : 'Bearish' ?></div>
                                    <div class="text-red-400 text-xs"><?= $total > 0 ? number_format(($bearishCount/$total)*100, 0) : 0 ?>%</div>
                                </div>
                                <div class="text-center bg-gray-700 bg-opacity-30 rounded p-2">
                                    <div class="text-2xl font-bold text-gray-400"><?= $sidewaysCount ?></div>
                                    <div class="text-gray-400"><?= $isRTL ? 'جانبية' : 'Sideways' ?></div>
                                    <div class="text-gray-400 text-xs"><?= $total > 0 ? number_format(($sidewaysCount/$total)*100, 0) : 0 ?>%</div>
                                </div>
                            </div>
                            
                            <div class="mt-3 text-xs text-center">
                                <span class="text-gray-400"><?= $isRTL ? 'إجمالي الأنماط:' : 'Total Patterns:' ?></span>
                                <span class="font-bold text-white"><?= $total ?></span>
                                <span class="text-gray-500 <?= $isRTL ? 'mr-2' : 'ml-2' ?>"><?= $isRTL ? '(آخر 365 يوم)' : '(Last 365 days)' ?></span>
                            </div>
                        </div>
                        
                        <!-- Similar Historical Events -->
                        <div class="space-y-2">
                            <div class="text-sm font-semibold text-purple-300 mb-2 flex items-center justify-between">
                                <span>
                                <i class="fas fa-history <?= $isRTL ? 'ml-2' : 'mr-2' ?>"></i><?= $isRTL ? 'أحداث مشابهة من الماضي:' : 'Similar Historical Events:' ?>
                                </span>
                                <span class="text-xs text-gray-500"><?= $isRTL ? 'أعلى 3 تشابهاً' : 'Top 3 matches' ?></span>
                            </div>
                            <?php foreach (array_slice($historicalLearning['similar_patterns'], 0, 3) as $i => $match): ?>
                                <?php 
                                $pattern = $match['pattern'];
                                $patternDir = $pattern['market_direction'];
                                $patternColor = $patternDir === 'bullish' ? 'green' : ($patternDir === 'bearish' ? 'red' : 'gray');
                                $similarityPct = $match['similarity']['overall'] * 100;
                                ?>
                                <div class="bg-gray-800 bg-opacity-50 rounded-lg p-3 text-sm hover:bg-opacity-70 transition border border-gray-700 hover:border-purple-500">
                                    <!-- Rank Badge -->
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0 w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center font-bold">
                                            <?= $i + 1 ?>
                                        </div>
                                        
                                        <div class="flex-1">
                                            <!-- Date -->
                                            <div class="font-semibold text-white mb-1 flex items-center gap-2">
                                                <span class="text-lg">📅</span>
                                                <span><?php 
                                                if ($isRTL) {
                                                    $months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
                                                    $date = new DateTime($pattern['pattern_date']);
                                                    echo $date->format('d') . ' ' . $months[$date->format('n')-1] . ' ' . $date->format('Y');
                                                } else {
                                                    echo date('M d, Y', strtotime($pattern['pattern_date']));
                                                }
                                                ?></span>
                                            </div>
                                            
                                            <!-- Event Description -->
                                            <div class="text-xs text-gray-400 mb-2 leading-relaxed">
                                                <?= htmlspecialchars(substr($pattern['event_description'] ?? ($isRTL ? 'حدث تاريخي' : 'Historical event'), 0, 100)) ?><?= strlen($pattern['event_description'] ?? '') > 100 ? '...' : '' ?>
                                            </div>
                                            
                                            <!-- Results -->
                                            <div class="flex items-center flex-wrap gap-2 text-xs mb-2">
                                                <!-- 24h Change -->
                                                <span class="px-2 py-1 rounded bg-<?= $patternColor ?>-600 text-white font-bold">
                                                    24h: <?= $pattern['price_change_24h'] > 0 ? '+' : '' ?><?= number_format($pattern['price_change_24h'], 2) ?>%
                                                </span>
                                                
                                                <!-- 7d Change -->
                                                <?php if (isset($pattern['price_change_7d'])): ?>
                                                <span class="px-2 py-1 rounded bg-<?= $patternColor ?>-700 text-white">
                                                    7d: <?= $pattern['price_change_7d'] > 0 ? '+' : '' ?><?= number_format($pattern['price_change_7d'], 2) ?>%
                                                </span>
                                                <?php endif; ?>
                                                
                                                <!-- Similarity Badge -->
                                                <span class="px-2 py-1 rounded bg-indigo-600 text-white">
                                                    <i class="fas fa-fingerprint"></i> <?= number_format($similarityPct, 1) ?>% <?= $isRTL ? 'تشابه' : 'match' ?>
                                                </span>
                                            </div>
                                            
                                            <!-- Pattern Strength -->
                                            <div class="flex items-center gap-2 text-xs">
                                                <span class="text-gray-500"><?= $isRTL ? 'قوة النمط:' : 'Strength:' ?></span>
                                                <div class="flex-1 h-1 bg-gray-700 rounded-full max-w-[100px]">
                                                    <div class="h-full bg-purple-500 rounded-full" style="width: <?= ($pattern['pattern_strength'] ?? 0.5) * 100 ?>%"></div>
                                                </div>
                                                <span class="text-gray-400"><?= number_format(($pattern['pattern_strength'] ?? 0.5) * 100, 0) ?>%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <!-- System Performance Stats -->
                        <div class="mt-4 bg-gradient-to-r from-purple-900 to-blue-900 bg-opacity-40 rounded-lg p-4 border border-purple-600">
                            <div class="text-sm font-bold text-purple-300 mb-3 flex items-center gap-2">
                                <i class="fas fa-chart-line"></i>
                                <?= $isRTL ? '📈 أداء نظام التعلم' : '📈 Learning System Performance' ?>
                            </div>
                            
                            <?php
                            // Get comprehensive system stats (365 days)
                            try {
                                // Total patterns in last 365 days
                                $stats365 = fetchOne("SELECT 
                                    COUNT(*) as total_patterns,
                                    AVG(pattern_strength) as avg_strength,
                                    SUM(CASE WHEN market_direction = 'bullish' THEN 1 ELSE 0 END) as bullish_patterns,
                                    SUM(CASE WHEN market_direction = 'bearish' THEN 1 ELSE 0 END) as bearish_patterns
                                    FROM historical_patterns 
                                    WHERE symbol = ? AND pattern_date >= DATE_SUB(NOW(), INTERVAL 365 DAY)", 
                                    [$selectedSymbol]
                                );
                                
                                // Recent patterns (last 30 days)
                                $stats30 = fetchOne("SELECT 
                                    COUNT(*) as recent_patterns
                                    FROM historical_patterns 
                                    WHERE symbol = ? AND pattern_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)", 
                                    [$selectedSymbol]
                                );
                                
                                $totalPatterns = $stats365['total_patterns'] ?? 0;
                                $avgStrength = ($stats365['avg_strength'] ?? 0.5) * 100;
                                $recentPatterns = $stats30['recent_patterns'] ?? 0;
                                $bullishPatterns = $stats365['bullish_patterns'] ?? 0;
                                $bearishPatterns = $stats365['bearish_patterns'] ?? 0;
                                
                            } catch (Exception $e) {
                                $totalPatterns = $historicalLearning['pattern_count'] ?? 0;
                                $avgStrength = 50;
                                $recentPatterns = 0;
                                $bullishPatterns = 0;
                                $bearishPatterns = 0;
                            }
                            
                            // Calculate pattern trend
                            $patternTrend = $totalPatterns > 0 ? ($bullishPatterns / $totalPatterns) * 100 : 50;
                            ?>
                            
                            <div class="grid grid-cols-2 gap-3 text-xs mb-3">
                                <!-- Total Patterns (365 days) -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-3 col-span-2">
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <div class="text-gray-400 mb-1"><?= $isRTL ? 'إجمالي الأنماط المحفوظة' : 'Total Patterns Stored' ?></div>
                                            <div class="text-3xl font-bold text-purple-400"><?= $totalPatterns ?></div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-xs text-gray-500"><?= $isRTL ? 'آخر 365 يوم' : 'Last 365 days' ?></div>
                                            <div class="text-sm text-green-400 mt-1">
                                                <i class="fas fa-database"></i> <?= $isRTL ? 'قاعدة معرفة كاملة' : 'Full knowledge base' ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Trend bar -->
                                    <div class="mt-2 flex items-center gap-2">
                                        <div class="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                                            <div class="h-full bg-gradient-to-r from-green-500 to-red-500" style="width: 100%"></div>
                                            <div class="h-full bg-green-500 -mt-2 rounded-full" style="width: <?= $patternTrend ?>%"></div>
                                        </div>
                                        <span class="text-xs text-gray-400">
                                            <?= number_format($patternTrend, 0) ?>% <?= $isRTL ? 'صاعدة' : 'bullish' ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <!-- Recent Activity -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                    <div class="text-gray-400 mb-1"><?= $isRTL ? 'نشاط حديث' : 'Recent Activity' ?></div>
                                    <div class="text-xl font-bold text-blue-400"><?= $recentPatterns ?></div>
                                    <div class="text-xs text-gray-500"><?= $isRTL ? 'آخر 30 يوم' : 'Last 30 days' ?></div>
                                </div>
                                
                                <!-- Average Strength -->
                                <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                    <div class="text-gray-400 mb-1"><?= $isRTL ? 'قوة متوسطة' : 'Avg Strength' ?></div>
                                    <div class="text-xl font-bold text-yellow-400"><?= number_format($avgStrength, 0) ?>%</div>
                                    <div class="text-xs text-gray-500"><?= $isRTL ? 'دقة الأنماط' : 'Pattern accuracy' ?></div>
                                </div>
                            </div>
                            
                            <!-- Bullish vs Bearish breakdown -->
                            <div class="bg-gray-900 bg-opacity-30 rounded p-2 mb-2">
                                <div class="flex items-center justify-between text-xs mb-2">
                                    <span class="text-gray-400"><?= $isRTL ? 'التوزيع التاريخي:' : 'Historical Distribution:' ?></span>
                                    <span class="text-gray-500"><?= $totalPatterns ?> <?= $isRTL ? 'نمط' : 'patterns' ?></span>
                                </div>
                                <div class="flex gap-1 h-2 rounded-full overflow-hidden">
                                    <div class="bg-green-500" style="width: <?= $totalPatterns > 0 ? ($bullishPatterns / $totalPatterns) * 100 : 33 ?>%"></div>
                                    <div class="bg-red-500" style="width: <?= $totalPatterns > 0 ? ($bearishPatterns / $totalPatterns) * 100 : 33 ?>%"></div>
                                    <div class="bg-gray-500" style="width: <?= $totalPatterns > 0 ? (($totalPatterns - $bullishPatterns - $bearishPatterns) / $totalPatterns) * 100 : 34 ?>%"></div>
                                </div>
                                <div class="flex justify-between text-xs mt-1">
                                    <span class="text-green-400"><?= $bullishPatterns ?> <?= $isRTL ? 'صاعد' : 'bullish' ?></span>
                                    <span class="text-red-400"><?= $bearishPatterns ?> <?= $isRTL ? 'هابط' : 'bearish' ?></span>
                                    <span class="text-gray-400"><?= $totalPatterns - $bullishPatterns - $bearishPatterns ?> <?= $isRTL ? 'جانبي' : 'sideways' ?></span>
                                </div>
                            </div>
                            
                            <!-- Current Confidence -->
                            <div class="bg-gray-800 bg-opacity-50 rounded p-2">
                                <div class="flex items-center justify-between">
                                    <span class="text-xs text-gray-400"><?= $isRTL ? 'الثقة في التوقع الحالي:' : 'Current Prediction Trust:' ?></span>
                                    <span class="text-lg font-bold text-green-400"><?= number_format($hlConfidence, 1) ?>%</span>
                                </div>
                                <div class="mt-1 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                                    <div class="h-full bg-gradient-to-r from-green-500 to-blue-500 rounded-full" style="width: <?= $hlConfidence ?>%"></div>
                                </div>
                            </div>
                            
                            <!-- Learning Status -->
                            <div class="mt-3 flex items-center justify-center gap-2 text-xs">
                                <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                                <span class="text-gray-300">
                                    <?= $isRTL ? '🧠 النظام يتعلم ويتحسن تلقائياً' : '🧠 System is learning and improving automatically' ?>
                                </span>
                            </div>
                        </div>
                        
                        <button onclick="loadMoreHistory()" class="mt-4 w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg text-sm transition">
                            <i class="fas fa-chart-line"></i> <?= $isRTL ? 'عرض المزيد من التحليلات' : 'View More Analysis' ?>
                        </button>
                        
                    <?php else: ?>
                        <div class="text-center py-8">
                            <div class="text-6xl mb-3">🧠</div>
                            <p class="text-gray-300 mb-2">
                                <?= $isRTL ? 'النظام يتعلم من البيانات التاريخية...' : 'System is learning from historical data...' ?>
                            </p>
                            <p class="text-sm text-gray-400">
                                <?= $isRTL ? 'لم يتم العثور على أنماط مشابهة بعد. قم بتشغيل التحليل لبناء قاعدة المعرفة.' : 'No similar patterns found yet. Run analysis to build the knowledge base.' ?>
                            </p>
                            <button onclick="learnFromHistory()" class="mt-4 px-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition">
                                <i class="fas fa-brain"></i> <?= $isRTL ? 'بدء التعلم من الماضي' : 'Start Learning from History' ?>
                            </button>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
                
                <!-- Recent News -->
                <div class="bg-gray-800 rounded-xl shadow-xl p-6">
                    <!-- Tabs -->
                    <div class="flex items-center justify-between mb-4 border-b border-gray-700">
                        <div class="flex gap-2">
                            <button onclick="switchNewsTab('recent')" id="tabRecent" class="tab-btn px-4 py-2 font-semibold border-b-2 border-blue-500 text-blue-400">
                                <i class="fas fa-newspaper"></i> <?= $isRTL ? 'آخر الأخبار' : 'Recent News' ?>
                            </button>
                            <button onclick="switchNewsTab('upcoming')" id="tabUpcoming" class="tab-btn px-4 py-2 font-semibold border-b-2 border-transparent text-gray-400 hover:text-white">
                                <i class="fas fa-calendar-alt"></i> <?= $isRTL ? 'أحداث قادمة' : 'Upcoming Events' ?>
                            </button>
                        </div>
                        <?php if ($isRTL): ?>
                        <span id="translationStatus" class="text-xs text-gray-500"></span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Recent News Tab -->
                    <div id="recentNewsTab" class="space-y-3 max-h-96 overflow-y-auto">
                        <?php foreach ($recentNews as $news): 
                            // Use pre-translated text if available (much faster!)
                            $newsTitle = $isRTL && !empty($news['title_ar']) ? $news['title_ar'] : $news['title'];
                            $newsSummary = $isRTL && !empty($news['summary_ar']) ? $news['summary_ar'] : $news['summary'];
                            $needsTranslation = $isRTL && (empty($news['title_ar']) || empty($news['summary_ar']));
                        ?>
                            <div class="bg-gray-700 rounded-lg p-4 hover:bg-gray-600 transition">
                                <div class="flex items-start justify-between">
                                    <div class="flex-1">
                                        <h4 class="font-semibold text-white mb-1 news-title" data-id="<?= $news['id'] ?>" data-needs-translation="<?= $needsTranslation ? '1' : '0' ?>" data-original="<?= htmlspecialchars($news['title']) ?>">
                                            <?= htmlspecialchars($newsTitle) ?>
                                        </h4>
                                        <p class="text-sm text-gray-400 mb-2 news-summary" data-needs-translation="<?= $needsTranslation ? '1' : '0' ?>" data-original="<?= htmlspecialchars(substr($news['summary'], 0, 150)) ?>">
                                            <?= htmlspecialchars(substr($newsSummary, 0, 150)) ?>...
                                        </p>
                                        <div class="flex items-center space-x-3 text-xs">
                                            <span class="text-gray-500">
                                                <i class="far fa-clock"></i>
                                                <?= date('M d, H:i', strtotime($news['date'])) ?>
                                            </span>
                            <span class="px-2 py-1 rounded <?= $news['sentiment'] === 'positive' ? 'bg-green-900 text-green-300' : ($news['sentiment'] === 'negative' ? 'bg-red-900 text-red-300' : 'bg-gray-600 text-gray-300') ?>">
                                <?= $news['sentiment'] === 'positive' ? $t['positive'] : ($news['sentiment'] === 'negative' ? $t['negative'] : $t['neutral']) ?>
                            </span>
                                            <span class="text-gray-500"><?= $news['source'] ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Upcoming Events Tab -->
                    <div id="upcomingEventsTab" class="hidden space-y-3 max-h-96 overflow-y-auto">
                        <?php
                        // Get upcoming events (with translations if Arabic)
                        $upcomingEvents = [];
                        try {
                            $upcomingEvents = fetchAll("SELECT * FROM upcoming_events WHERE event_date > NOW() AND is_passed = FALSE ORDER BY event_date ASC LIMIT 10");
                        } catch (Exception $e) {
                            // Table might not exist yet
                        }
                        
                        if (empty($upcomingEvents)):
                        ?>
                            <div class="text-center py-8 text-gray-400">
                                <i class="fas fa-calendar-times text-4xl mb-3 opacity-50"></i>
                                <p><?= $isRTL ? 'لا توجد أحداث قادمة حالياً' : 'No upcoming events' ?></p>
                                <button onclick="fetchEvents()" class="mt-4 px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition">
                                    <i class="fas fa-sync-alt"></i> <?= $isRTL ? 'جلب الأحداث من الأخبار' : 'Fetch Events from News' ?>
                                </button>
                </div>
                        <?php else: ?>
                            <div class="flex justify-end mb-3">
                                <button onclick="fetchEvents()" class="text-xs px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded transition">
                                    <i class="fas fa-sync-alt"></i> <?= $isRTL ? 'تحديث' : 'Refresh' ?>
                                </button>
                            </div>
                            <?php foreach ($upcomingEvents as $event): 
                                // Use pre-translated text if available
                                $eventTitle = $isRTL && !empty($event['event_title_ar']) ? $event['event_title_ar'] : $event['event_title'];
                                $eventDesc = $isRTL && !empty($event['event_description_ar']) ? $event['event_description_ar'] : $event['event_description'];
                                $eventNeedsTranslation = $isRTL && (empty($event['event_title_ar']) || empty($event['event_description_ar']));
                                
                                $eventTime = strtotime($event['event_date']);
                                $now = time();
                                $diff = $eventTime - $now;
                                $days = floor($diff / 86400);
                                $hours = floor(($diff % 86400) / 3600);
                                
                                $importanceColors = [
                                    'critical' => 'red',
                                    'high' => 'orange',
                                    'medium' => 'yellow',
                                    'low' => 'gray'
                                ];
                                $color = $importanceColors[$event['importance']] ?? 'gray';
                                
                                $impactIcons = [
                                    'bullish' => '🟢 ↗️',
                                    'bearish' => '🔴 ↘️',
                                    'neutral' => '🟡 ➡️',
                                    'mixed' => '🟠 ↕️'
                                ];
                                $impactIcon = $impactIcons[$event['expected_impact']] ?? '⚪';
                            ?>
                            <div class="bg-gray-700 rounded-lg p-4 hover:bg-gray-600 transition border-l-4 border-<?= $color ?>-500">
                                <div class="flex items-start justify-between mb-2">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <span class="px-2 py-1 text-xs rounded bg-<?= $color ?>-600 uppercase font-bold">
                                                <?= $isRTL ? ($event['importance'] === 'critical' ? 'حرج' : ($event['importance'] === 'high' ? 'عالي' : ($event['importance'] === 'medium' ? 'متوسط' : 'منخفض'))) : strtoupper($event['importance']) ?>
                                            </span>
                                            <span class="text-sm"><?= $impactIcon ?></span>
                                        </div>
                                        <h4 class="font-semibold text-white event-title" data-id="<?= $event['id'] ?>" data-needs-translation="<?= $eventNeedsTranslation ? '1' : '0' ?>" data-original="<?= htmlspecialchars($event['event_title']) ?>">
                                            <?= htmlspecialchars($eventTitle) ?>
                                        </h4>
                                        <?php if ($event['event_description']): ?>
                                        <p class="text-sm text-gray-400 mt-1 event-description" data-needs-translation="<?= $eventNeedsTranslation ? '1' : '0' ?>" data-original="<?= htmlspecialchars($event['event_description']) ?>">
                                            <?= htmlspecialchars($eventDesc) ?>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Countdown -->
                                <div class="mt-3 p-3 bg-gray-800 rounded-lg">
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <div class="text-xs text-gray-400 mb-1"><?= $isRTL ? 'الوقت المتبقي:' : 'Time Remaining:' ?></div>
                                            <div class="countdown-timer text-lg font-bold text-<?= $color ?>-400" data-target="<?= $eventTime ?>">
                                                <span class="days"><?= $days ?></span><?= $isRTL ? ' يوم ' : 'd ' ?>
                                                <span class="hours"><?= $hours ?></span><?= $isRTL ? ' ساعة' : 'h' ?>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-xs text-gray-400 mb-1"><?= $isRTL ? 'التاريخ:' : 'Date:' ?></div>
                                            <div class="text-sm font-semibold">
                                                <?= date('M d, Y', $eventTime) ?><br>
                                                <span class="text-xs text-gray-400"><?= date('H:i', $eventTime) ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Right Column - AI Prediction & Sentiment -->
            <div class="space-y-6">
                
                <!-- AI Prediction Card -->
                <div class="bg-gradient-to-br from-blue-900 to-purple-900 rounded-xl shadow-xl p-6">
                    <h3 class="text-xl font-bold mb-4">
                        <i class="fas fa-robot"></i> <?= $t['ai_signal'] ?>
                    </h3>
                    
                    <?php if ($prediction): ?>
                        <?php 
                        $signal = $prediction['predicted_signal'];
                        $confidence = $prediction['confidence_score'] * 100;
                        $signalColor = $signal === 'bullish' ? 'green' : ($signal === 'bearish' ? 'red' : 'gray');
                        $topFactors = json_decode($prediction['top_factors'], true) ?: [];
                        ?>
                        
                        <!-- Signal Badge -->
                        <div class="text-center mb-6">
                            <div class="inline-block px-6 py-3 rounded-full bg-<?= $signalColor ?>-600 text-white text-2xl font-bold mb-2">
                                <?= $signal === 'bullish' ? $t['bullish'] : ($signal === 'bearish' ? $t['bearish'] : $t['sideways']) ?>
                            </div>
                            <div class="text-3xl font-bold"><?= number_format($confidence, 1) ?>%</div>
                            <div class="text-sm text-gray-300"><?= $t['confidence'] ?></div>
                        </div>
                        
                        <!-- Confidence Bar -->
                        <div class="mb-6">
                            <div class="h-4 bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-<?= $signalColor ?>-500 transition-all" style="width: <?= $confidence ?>%"></div>
                            </div>
                        </div>
                        
                        <!-- Top Factors -->
                        <?php if (!empty($topFactors)): ?>
                            <div class="mb-4">
                                <h4 class="font-semibold text-white mb-3"><?= $t['key_factors'] ?>:</h4>
                                <div class="space-y-2">
                                    <?php foreach (array_slice($topFactors, 0, 3) as $factor): ?>
                                        <div class="bg-gray-800 bg-opacity-50 rounded-lg p-3">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="text-sm font-semibold"><?= htmlspecialchars($factor['factor'] ?? 'Factor') ?></span>
                                                <span class="px-2 py-1 rounded text-xs <?= ($factor['impact'] ?? '') === 'bullish' ? 'bg-green-600' : 'bg-red-600' ?>">
                                                    <?= ($factor['impact'] ?? '') === 'bullish' ? $t['bullish'] : (($factor['impact'] ?? '') === 'bearish' ? $t['bearish'] : $t['neutral']) ?>
                                                </span>
                                            </div>
                                            <p class="text-xs text-gray-400"><?= htmlspecialchars($factor['description'] ?? '') ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="text-xs text-gray-400 text-center mt-4">
                            <?= $isRTL ? 'آخر تحديث:' : 'Last updated:' ?> <?= date('M d, H:i', strtotime($prediction['prediction_timestamp'])) ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-gray-400 py-8">
                            <i class="fas fa-robot text-4xl mb-3 opacity-50"></i>
                            <p class="font-bold"><?= $isRTL ? 'لا يوجد تنبؤ لـ ' : 'No prediction for ' ?><?= $selectedSymbol ?></p>
                            <p class="text-sm mt-2">
                                <?= $isRTL ? 'إجمالي التنبؤات في النظام:' : 'Total predictions in system:' ?> 
                                <span class="font-bold text-blue-400"><?= $totalPredictions ?></span>
                            </p>
                            <button onclick="runAnalysis()" class="mt-4 px-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition">
                                <i class="fas fa-play"></i> <?= $isRTL ? 'تشغيل التحليل الآن' : 'Run Analysis Now' ?>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Market Sentiment Card -->
                <div class="bg-gray-800 rounded-xl shadow-xl p-6">
                    <h3 class="text-xl font-bold mb-4 flex items-center justify-between">
                        <span>
                        <i class="fas fa-chart-pie text-blue-500"></i> <?= $t['market_sentiment'] ?>
                        </span>
                        <button onclick="refreshSentiment()" class="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded" title="<?= $isRTL ? 'تحديث' : 'Refresh' ?>">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </h3>
                    
                    <?php 
                    $sentimentIcon = $marketSentiment['overall_sentiment'] === 'positive' ? '😊' : ($marketSentiment['overall_sentiment'] === 'negative' ? '😟' : '😐');
                    $sentimentEmoji = $marketSentiment['overall_sentiment'] === 'positive' ? '🟢' : ($marketSentiment['overall_sentiment'] === 'negative' ? '🔴' : '🟡');
                    ?>
                    
                    <div class="text-center mb-4 p-4 rounded-lg <?= $marketSentiment['overall_sentiment'] === 'positive' ? 'bg-green-900 bg-opacity-30' : ($marketSentiment['overall_sentiment'] === 'negative' ? 'bg-red-900 bg-opacity-30' : 'bg-gray-700 bg-opacity-30') ?>">
                        <div class="text-5xl mb-2"><?= $sentimentIcon ?></div>
                        <div class="text-3xl font-bold <?= $marketSentiment['overall_sentiment'] === 'positive' ? 'text-green-400' : ($marketSentiment['overall_sentiment'] === 'negative' ? 'text-red-400' : 'text-gray-400') ?>">
                            <?= $sentimentEmoji ?> <?= $marketSentiment['overall_sentiment'] === 'positive' ? $t['positive'] : ($marketSentiment['overall_sentiment'] === 'negative' ? $t['negative'] : $t['neutral']) ?>
                        </div>
                        <div class="text-lg font-bold mt-2">
                            <?= $isRTL ? 'النتيجة:' : 'Score:' ?> 
                            <span class="<?= $marketSentiment['average_score'] > 0 ? 'text-green-400' : ($marketSentiment['average_score'] < 0 ? 'text-red-400' : 'text-gray-400') ?>">
                                <?= $marketSentiment['average_score'] > 0 ? '+' : '' ?><?= number_format($marketSentiment['average_score'], 4) ?>
                            </span>
                        </div>
                        <div class="text-sm text-gray-400 mt-2">
                            <?= $isRTL ? 'بناءً على' : 'Based on' ?> <span class="font-bold"><?= $marketSentiment['total_articles'] ?></span> <?= $isRTL ? 'مقال (24 ساعة)' : 'articles (24h)' ?>
                        </div>
                    </div>
                    
                    <!-- Sentiment Breakdown -->
                    <div class="space-y-3">
                        <div>
                            <div class="flex justify-between text-sm mb-1">
                                <span class="text-green-400"><?= $t['positive'] ?></span>
                                <span class="font-bold"><?= $marketSentiment['positive_percentage'] ?>%</span>
                            </div>
                            <div class="h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-green-500" style="width: <?= $marketSentiment['positive_percentage'] ?>%"></div>
                            </div>
                        </div>
                        
                        <div>
                            <div class="flex justify-between text-sm mb-1">
                                <span class="text-red-400"><?= $t['negative'] ?></span>
                                <span class="font-bold"><?= $marketSentiment['negative_percentage'] ?>%</span>
                            </div>
                            <div class="h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-red-500" style="width: <?= $marketSentiment['negative_percentage'] ?>%"></div>
                            </div>
                        </div>
                        
                        <div>
                            <div class="flex justify-between text-sm mb-1">
                                <span class="text-gray-400"><?= $t['neutral'] ?></span>
                                <span class="font-bold"><?= $marketSentiment['neutral_percentage'] ?>%</span>
                            </div>
                            <div class="h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-gray-500" style="width: <?= $marketSentiment['neutral_percentage'] ?>%"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4 pt-4 border-t border-gray-700">
                        <div class="text-sm text-gray-400"><?= $isRTL ? 'درجة المعنويات' : 'Sentiment Score' ?></div>
                        <div class="text-2xl font-bold"><?= number_format($marketSentiment['average_score'], 4) ?></div>
                    </div>
                </div>
                
                <!-- Advanced Analysis (Volume + Fear & Greed) - NEW -->
                <div class="bg-gradient-to-br from-cyan-900 to-blue-900 rounded-xl shadow-xl p-6 border-2 border-cyan-500">
                    <h3 class="text-xl font-bold mb-4">
                        <i class="fas fa-chart-bar text-cyan-400"></i> <?= $isRTL ? 'التحليل المتقدم' : 'Advanced Analysis' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-cyan-600 rounded-full animate-pulse"><?= $isRTL ? 'جديد' : 'NEW' ?></span>
                    </h3>
                    
                    <div id="advanced-analysis-content" class="space-y-6">
                        <div class="text-center py-8">
                            <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400"></div>
                            <p class="text-gray-400 mt-2"><?= $isRTL ? 'جارٍ تحميل التحليل المتقدم...' : 'Loading advanced analysis...' ?></p>
                    </div>
                    </div>
                    
                    <button onclick="loadAdvancedAnalysis()" class="mt-4 w-full px-6 py-2 bg-cyan-600 hover:bg-cyan-700 rounded-lg transition">
                        <i class="fas fa-sync-alt"></i> <?= $isRTL ? 'تحديث التحليل' : 'Refresh Analysis' ?>
                        </button>
                </div>
            </div>
            
            <!-- ============================================ -->
            <!-- Phase 1 Enhancements - New Sections -->
            <!-- ============================================ -->
            
            <!-- Order Book Analysis Section -->
            <div class="mt-6">
                <div class="bg-gradient-to-br from-green-900 to-emerald-900 rounded-xl shadow-xl p-6 border-2 border-green-500">
                    <h3 class="text-xl font-bold mb-4">
                        <i class="fas fa-book text-green-400"></i> 
                        <?= $isRTL ? '📊 تحليل دفتر الأوامر' : '📊 Order Book Analysis' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-green-600 rounded-full animate-pulse">
                            <?= $isRTL ? 'جديد' : 'NEW' ?>
                        </span>
                    </h3>
                    
                    <div id="orderbook-content" class="space-y-4">
                        <div class="text-center py-8">
                            <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-400"></div>
                            <p class="text-gray-400 mt-2"><?= $isRTL ? 'جارٍ تحليل دفتر الأوامر...' : 'Analyzing order book...' ?></p>
                        </div>
                    </div>
                    
                    <button onclick="loadOrderBookAnalysis()" class="mt-4 w-full px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition transform hover:scale-105">
                        <i class="fas fa-sync-alt"></i> <?= $isRTL ? 'تحديث التحليل' : 'Refresh Analysis' ?>
                    </button>
                    
                    <div class="mt-4 bg-green-800 bg-opacity-30 rounded-lg p-3 text-sm">
                        <i class="fas fa-info-circle text-green-400"></i>
                        <span class="text-gray-300">
                            <?= $isRTL ? 'يكشف نشاط الحيتان وجدران الشراء/البيع' : 'Detects whale activity and buy/sell walls' ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Social Media Analysis Section -->
            <div class="mt-6">
                <div class="bg-gradient-to-br from-purple-900 to-pink-900 rounded-xl shadow-xl p-6 border-2 border-purple-500">
                    <h3 class="text-xl font-bold mb-4">
                        <i class="fas fa-hashtag text-purple-400"></i> 
                        <?= $isRTL ? '📱 تحليل وسائل التواصل' : '📱 Social Media Analysis' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-purple-600 rounded-full animate-pulse">
                            <?= $isRTL ? 'جديد' : 'NEW' ?>
                        </span>
                    </h3>
                    
                    <div id="social-media-content" class="space-y-4">
                        <div class="text-center py-8">
                            <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
                            <p class="text-gray-400 mt-2"><?= $isRTL ? 'جارٍ تحليل وسائل التواصل...' : 'Analyzing social media...' ?></p>
                        </div>
                    </div>
                    
                    <button onclick="loadSocialMediaAnalysis()" class="mt-4 w-full px-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition transform hover:scale-105">
                        <i class="fas fa-sync-alt"></i> <?= $isRTL ? 'تحديث التحليل' : 'Refresh Analysis' ?>
                    </button>
                    
                    <div class="mt-4 bg-purple-800 bg-opacity-30 rounded-lg p-3 text-sm">
                        <i class="fas fa-info-circle text-purple-400"></i>
                        <span class="text-gray-300">
                            <?= $isRTL ? 'يرصد المشاعر العامة ويكشف FUD والإشارات الفيروسية' : 'Monitors sentiment, detects FUD and viral signals' ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Multi-Timeframe Analysis Section -->
            <div class="mt-6">
                <div class="bg-gradient-to-br from-orange-900 to-red-900 rounded-xl shadow-xl p-6 border-2 border-orange-500">
                    <h3 class="text-xl font-bold mb-4">
                        <i class="fas fa-clock text-orange-400"></i> 
                        <?= $isRTL ? '⏱️ التحليل متعدد الأطر الزمنية' : '⏱️ Multi-Timeframe Analysis' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-orange-600 rounded-full animate-pulse">
                            <?= $isRTL ? 'جديد' : 'NEW' ?>
                        </span>
                    </h3>
                    
                    <div id="multitimeframe-content" class="space-y-4">
                        <div class="text-center py-8">
                            <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-orange-400"></div>
                            <p class="text-gray-400 mt-2"><?= $isRTL ? 'جارٍ التحليل عبر الأطر الزمنية...' : 'Analyzing timeframes...' ?></p>
                        </div>
                    </div>
                    
                    <button onclick="loadMultiTimeframeAnalysis()" class="mt-4 w-full px-6 py-2 bg-orange-600 hover:bg-orange-700 rounded-lg transition transform hover:scale-105">
                        <i class="fas fa-sync-alt"></i> <?= $isRTL ? 'تحديث التحليل' : 'Refresh Analysis' ?>
                    </button>
                    
                    <div class="mt-4 bg-orange-800 bg-opacity-30 rounded-lg p-3 text-sm">
                        <i class="fas fa-info-circle text-orange-400"></i>
                        <span class="text-gray-300">
                            <?= $isRTL ? 'يكشف التطابق والتباين عبر 6 أطر زمنية' : 'Detects confluence and divergence across 6 timeframes' ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Enhanced Overall Signal Section -->
            <div class="mt-6">
                <div class="bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 rounded-xl shadow-2xl p-6 border-4 border-blue-400">
                    <h3 class="text-2xl font-bold mb-4 text-center">
                        <i class="fas fa-trophy text-yellow-400"></i> 
                        <?= $isRTL ? '🎯 الإشارة الشاملة المحسّنة' : '🎯 Enhanced Overall Signal' ?>
                    </h3>
                    
                    <div id="enhanced-signal-content" class="space-y-4">
                        <div class="text-center py-8">
                            <div class="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-blue-400"></div>
                            <p class="text-gray-300 mt-2"><?= $isRTL ? 'جارٍ حساب الإشارة الشاملة...' : 'Calculating overall signal...' ?></p>
                        </div>
                    </div>
                    
                    <button onclick="loadEnhancedAnalysis()" class="mt-4 w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-lg transition transform hover:scale-105 font-bold text-lg shadow-lg">
                        <i class="fas fa-rocket"></i> <?= $isRTL ? '🚀 تحديث شامل للتحسينات' : '🚀 Refresh Enhanced Analysis' ?>
                    </button>
                </div>
            </div>
            
        </div>
    </main>
    
    <!-- Footer -->
    <footer class="bg-gray-800 mt-12 py-6">
        <div class="container mx-auto px-4 text-center text-gray-400">
            <p>&copy; 2025 <?= $isRTL ? 'تحليل سوق العملات الرقمية بالذكاء الاصطناعي. مدعوم بالتعلم الآلي المتقدم.' : 'Crypto Market AI Analysis. Powered by Advanced Machine Learning.' ?></p>
            <p class="text-sm mt-2"><?= $isRTL ? 'البيانات مجمعة من مصادر متعددة. ليست نصيحة مالية.' : 'Data collected from multiple sources. Not financial advice.' ?></p>
        </div>
    </footer>
    
    <script src="assets/js/main.js"></script>
    <script>
        // Override functions for better compatibility
        async function refreshData() {
            if (typeof window.showNotification === 'function') {
                window.showNotification('⏳ <?= $isRTL ? "جاري جلب البيانات..." : "Fetching data..." ?>', 'info');
            }
            
            try {
                const response = await fetch('api/fetch_data.php');
                const result = await response.json();
                
                if (result.success) {
                    if (typeof window.showNotification === 'function') {
                        window.showNotification(`✅ ${result.data.price_count} <?= $isRTL ? "أسعار، " : "prices, " ?>${result.data.news_count} <?= $isRTL ? "أخبار" : "news" ?>`, 'success');
                    }
                    setTimeout(() => window.location.reload(), 2000);
                } else {
                    if (typeof window.showNotification === 'function') {
                        window.showNotification('❌ ' + result.message, 'error');
                    } else {
                        alert('Error: ' + result.message);
                    }
                }
            } catch (error) {
                if (typeof window.showNotification === 'function') {
                    window.showNotification('❌ Error: ' + error.message, 'error');
                } else {
                    alert('Error: ' + error.message);
                }
            }
        }
        
        async function runAnalysis() {
            if (typeof window.showNotification === 'function') {
                window.showNotification('⏳ <?= $isRTL ? "جاري التحليل... قد يستغرق 1-2 دقيقة" : "Running analysis... may take 1-2 minutes" ?>', 'info');
            }
            
            try {
                const response = await fetch('api/run_analysis.php');
                const result = await response.json();
                
                if (result.success) {
                    const data = result.data;
                    
                    if (data.indicators_calculated === 0 && data.predictions_generated === 0) {
                        if (typeof window.showNotification === 'function') {
                            window.showNotification('⚠️ <?= $isRTL ? "لا توجد بيانات! اضغط \"جلب أحدث البيانات\" أولاً" : "No data! Click \"Fetch Latest Data\" first" ?>', 'warning');
                        } else {
                            alert('<?= $isRTL ? "لا توجد بيانات! اضغط \"جلب أحدث البيانات\" أولاً" : "No data! Click \"Fetch Latest Data\" first" ?>');
                        }
                    } else if (data.indicators_calculated > 0) {
                        let message = `✅ <?= $isRTL ? "اكتمل!" : "Complete!" ?>\n📊 ${data.indicators_calculated}\n🤖 ${data.predictions_generated}`;
                        if (typeof window.showNotification === 'function') {
                            window.showNotification(message, 'success');
                        } else {
                            alert(message);
                        }
                        setTimeout(() => window.location.reload(), 3000);
                    } else {
                        if (typeof window.showNotification === 'function') {
                            window.showNotification(`ℹ️ <?= $isRTL ? "تحليل جزئي" : "Partial analysis" ?>`, 'info');
                        }
                        setTimeout(() => window.location.reload(), 3000);
                    }
                } else {
                    if (typeof window.showNotification === 'function') {
                        window.showNotification('❌ ' + result.message, 'error');
                    } else {
                        alert('Error: ' + result.message);
                    }
                }
            } catch (error) {
                if (typeof window.showNotification === 'function') {
                    window.showNotification('❌ Error: ' + error.message, 'error');
                } else {
                    alert('Error: ' + error.message);
                }
            }
        }
        
        // Dark Mode Toggle (Direct implementation for reliability)
        function toggleDarkMode() {
            const body = document.body;
            const toggleBtn = document.getElementById('darkModeToggle');
            const isDark = body.classList.contains('bg-gray-900');
            
            if (isDark) {
                // Switch to Light Mode
                body.className = 'bg-gray-50 text-gray-900';
                
                // Update header
                const header = document.querySelector('header');
                if (header) {
                    header.className = 'bg-white shadow-lg border-b border-gray-200';
                }
                
                // Update footer
                const footer = document.querySelector('footer');
                if (footer) {
                    footer.className = 'bg-white mt-12 py-6 border-t border-gray-200';
                }
                
                // Update cards
                document.querySelectorAll('.bg-gray-800').forEach(card => {
                    card.className = card.className.replace('bg-gray-800', 'bg-white border border-gray-200');
                });
                
                // Update text colors
                document.querySelectorAll('.text-gray-100').forEach(text => {
                    text.className = text.className.replace('text-gray-100', 'text-gray-900');
                });
                
                document.querySelectorAll('.text-gray-400').forEach(text => {
                    text.className = text.className.replace('text-gray-400', 'text-gray-600');
                });
                
                if (toggleBtn) {
                    toggleBtn.innerHTML = '<i class="fas fa-sun text-yellow-500"></i>';
                    toggleBtn.className = 'p-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition';
                }
                
                localStorage.setItem('theme', 'light');
            } else {
                // Switch to Dark Mode
                body.className = 'bg-gray-900 text-gray-100';
                
                // Update header
                const header = document.querySelector('header');
                if (header) {
                    header.className = 'bg-gray-800 shadow-lg';
                }
                
                // Update footer
                const footer = document.querySelector('footer');
                if (footer) {
                    footer.className = 'bg-gray-800 mt-12 py-6';
                }
                
                // Update cards
                document.querySelectorAll('.bg-white').forEach(card => {
                    card.className = card.className.replace('bg-white border border-gray-200', 'bg-gray-800');
                });
                
                // Update text colors
                document.querySelectorAll('.text-gray-900').forEach(text => {
                    text.className = text.className.replace('text-gray-900', 'text-gray-100');
                });
                
                document.querySelectorAll('.text-gray-600').forEach(text => {
                    text.className = text.className.replace('text-gray-600', 'text-gray-400');
                });
                
                if (toggleBtn) {
                    toggleBtn.innerHTML = '<i class="fas fa-moon text-blue-400"></i>';
                    toggleBtn.className = 'p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition';
                }
                
                localStorage.setItem('theme', 'dark');
            }
            
            // Show feedback
            if (typeof window.showNotification === 'function') {
                window.showNotification(isDark ? '☀️ Light Mode' : '🌙 Dark Mode', 'info');
            }
        }
        
        // Initialize dark mode immediately
        (function() {
            const savedTheme = localStorage.getItem('theme');
            
            // Apply saved theme immediately
            if (savedTheme === 'light') {
                document.documentElement.setAttribute('data-theme', 'light');
            }
            
            // Set up event listener when DOM is ready
            document.addEventListener('DOMContentLoaded', function() {
                const toggleBtn = document.getElementById('darkModeToggle');
                
                if (toggleBtn) {
                    console.log('✅ Dark mode toggle button found');
                    
                    // Remove any existing listeners
                    toggleBtn.replaceWith(toggleBtn.cloneNode(true));
                    const newToggleBtn = document.getElementById('darkModeToggle');
                    
                    // Add click event
                    newToggleBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        console.log('🔘 Dark mode button clicked');
                        toggleDarkMode();
                    });
                    
                    // Apply current theme to button
                    if (savedTheme === 'light') {
                        newToggleBtn.innerHTML = '<i class="fas fa-sun text-yellow-500"></i>';
                        newToggleBtn.className = 'p-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition dark-mode-toggle';
                    }
                    
                    console.log('✅ Dark mode toggle initialized');
                } else {
                    console.log('❌ Dark mode toggle button NOT found');
                }
            });
        })();
        
        // Historical Learning Functions
        async function learnFromHistory() {
            if (typeof window.showNotification === 'function') {
                window.showNotification('🧠 <?= $isRTL ? "جاري التعلم من البيانات التاريخية..." : "Learning from historical data..." ?>', 'info');
            }
            
            try {
                // Open in new window instead of AJAX (since it returns plain text)
                window.open('cron/learn_from_history.php', '_blank');
                
                if (typeof window.showNotification === 'function') {
                    window.showNotification('✅ <?= $isRTL ? "تم فتح صفحة التعلم. انتظر حتى تنتهي ثم حدث الصفحة" : "Learning page opened. Wait for completion then refresh" ?>', 'success');
                }
                
                // Auto reload after 30 seconds
                setTimeout(() => {
                    if (confirm('<?= $isRTL ? "هل انتهى التعلم؟ اضغط OK لتحديث الصفحة" : "Learning complete? Click OK to refresh" ?>')) {
                        window.location.reload();
                    }
                }, 30000);
                
            } catch (error) {
                console.error('Learn from history error:', error);
                if (typeof window.showNotification === 'function') {
                    window.showNotification('❌ Error: ' + error.message, 'error');
                }
            }
        }
        
        async function loadMoreHistory() {
            const symbol = '<?= $selectedSymbol ?>';
            
            try {
                const response = await fetch(`api/get_historical_learning.php?symbol=${symbol}`);
                const result = await response.json();
                
                if (result.success && result.data.has_patterns) {
                    const data = result.data;
                    
                    // Create modal with detailed history
                    const modal = document.createElement('div');
                    modal.className = 'fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4';
                    modal.innerHTML = `
                        <div class="bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6">
                            <div class="flex justify-between items-center mb-4">
                                <h2 class="text-2xl font-bold">
                                    <i class="fas fa-brain text-purple-400"></i> 
                                    <?= $isRTL ? 'التحليل التاريخي التفصيلي' : 'Detailed Historical Analysis' ?>
                                </h2>
                                <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-white">
                                    <i class="fas fa-times text-2xl"></i>
                                </button>
                            </div>
                            
                            <div class="mb-6 p-4 bg-purple-900 bg-opacity-50 rounded-lg">
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                    <div>
                                        <div class="text-2xl font-bold text-purple-400">${data.pattern_count}</div>
                                        <div class="text-xs text-gray-400"><?= $isRTL ? 'أنماط مشابهة' : 'Similar Patterns' ?></div>
                                    </div>
                                    <div>
                                        <div class="text-2xl font-bold ${data.predicted_direction === 'bullish' ? 'text-green-400' : 'text-red-400'}">
                                            ${data.predicted_change > 0 ? '+' : ''}${(data.predicted_change || 0).toFixed(2)}%
                                        </div>
                                        <div class="text-xs text-gray-400"><?= $isRTL ? 'التغير المتوقع' : 'Expected Change' ?></div>
                                    </div>
                                    <div>
                                        <div class="text-2xl font-bold text-blue-400">${((data.confidence || 0) * 100).toFixed(1)}%</div>
                                        <div class="text-xs text-gray-400"><?= $isRTL ? 'الثقة' : 'Confidence' ?></div>
                                    </div>
                                    <div>
                                        <div class="text-2xl font-bold text-yellow-400">${data.historical_summary.total_patterns}</div>
                                        <div class="text-xs text-gray-400"><?= $isRTL ? 'إجمالي الأنماط' : 'Total Patterns' ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <h3 class="text-lg font-bold mb-3"><?= $isRTL ? 'جميع الأنماط المشابهة:' : 'All Similar Patterns:' ?></h3>
                            <div class="space-y-3">
                                ${data.similar_patterns.map((pattern, i) => `
                                    <div class="bg-gray-700 rounded-lg p-4">
                                        <div class="flex justify-between items-start mb-2">
                                            <div>
                                                <div class="font-bold text-white">#${i + 1} - ${pattern.event_type}</div>
                                                <div class="text-sm text-gray-400">${pattern.date}</div>
                                            </div>
                                            <div class="text-right">
                                                <div class="text-lg font-bold ${pattern.price_change_24h > 0 ? 'text-green-400' : 'text-red-400'}">
                                                    ${pattern.price_change_24h > 0 ? '+' : ''}${pattern.price_change_24h}%
                                                </div>
                                                <div class="text-xs text-gray-400">${pattern.market_direction}</div>
                                            </div>
                                        </div>
                                        <div class="text-sm text-gray-300 mb-2">${pattern.event_description}</div>
                                        <div class="flex space-x-3 text-xs">
                                            <span class="px-2 py-1 bg-purple-600 rounded">
                                                <?= $isRTL ? 'تشابه:' : 'Similarity:' ?> ${pattern.similarity}%
                                            </span>
                                            <span class="px-2 py-1 bg-blue-600 rounded">
                                                <?= $isRTL ? 'ثقة:' : 'Confidence:' ?> ${pattern.confidence}%
                                            </span>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                            
                            ${data.historical_summary.common_event_types.length > 0 ? `
                                <h3 class="text-lg font-bold mt-6 mb-3"><?= $isRTL ? 'أنواع الأحداث الشائعة:' : 'Common Event Types:' ?></h3>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    ${data.historical_summary.common_event_types.map(type => `
                                        <div class="bg-gray-700 rounded-lg p-3">
                                            <div class="font-semibold text-white">${type.type}</div>
                                            <div class="text-sm text-gray-400">
                                                <?= $isRTL ? 'التكرار:' : 'Count:' ?> ${type.count} | 
                                                <?= $isRTL ? 'متوسط التغير:' : 'Avg Change:' ?> ${type.avg_change > 0 ? '+' : ''}${type.avg_change}%
                                            </div>
                                            <div class="text-xs text-gray-500"><?= $isRTL ? 'آخر حدوث:' : 'Last:' ?> ${type.last_occurrence}</div>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                        </div>
                    `;
                    
                    document.body.appendChild(modal);
                } else {
                    if (typeof window.showNotification === 'function') {
                        window.showNotification('ℹ️ <?= $isRTL ? "لا توجد بيانات تاريخية كافية" : "Not enough historical data" ?>', 'info');
                    }
                }
            } catch (error) {
                console.error('Load history error:', error);
                if (typeof window.showNotification === 'function') {
                    window.showNotification('❌ Error: ' + error.message, 'error');
                }
            }
        }
        
        // Test if functions work
        console.log('✅ refreshData function:', typeof refreshData);
        console.log('✅ runAnalysis function:', typeof runAnalysis);
        console.log('✅ toggleDarkMode function:', typeof toggleDarkMode);
        console.log('✅ learnFromHistory function:', typeof learnFromHistory);
        console.log('✅ loadMoreHistory function:', typeof loadMoreHistory);
        
        // Live Price from Binance
        const symbol = '<?= $selectedSymbol ?>';
        
        function updateLivePrice() {
            const binanceSymbol = symbol + 'USDT';
            
            fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${binanceSymbol}`)
                .then(response => response.json())
                .then(data => {
                    const price = parseFloat(data.lastPrice);
                    const change = parseFloat(data.priceChangePercent);
                    const volume = parseFloat(data.volume);
                    
                    // Update price
                    const priceEl = document.getElementById('livePrice');
                    if (priceEl) {
                        const changeColor = change >= 0 ? 'text-green-400' : 'text-red-400';
                        const changeIcon = change >= 0 ? '▲' : '▼';
                        priceEl.innerHTML = `$${price.toLocaleString()} <span class="${changeColor} text-xl ml-2">${changeIcon} ${Math.abs(change).toFixed(2)}%</span>`;
                    }
                    
                    // Update time
                    const timeEl = document.getElementById('priceTime');
                    if (timeEl) {
                        const now = new Date();
                        timeEl.textContent = '<?= $isRTL ? "مباشر" : "Live" ?> - ' + now.toLocaleTimeString();
                    }
                })
                .catch(error => {
                    console.error('Error fetching price:', error);
                });
        }
        
        // Update every 3 seconds
        updateLivePrice();
        setInterval(updateLivePrice, 3000);
        
        // Smart Full Update - Automated workflow with progress bar
        async function smartUpdate() {
            const isArabic = <?= $isRTL ? 'true' : 'false' ?>;
            
            // Show progress bar
            const progressBar = document.getElementById('smartUpdateProgress');
            const smartUpdateBtn = document.getElementById('smartUpdateBtn');
            const progressTitle = document.getElementById('progressTitle');
            const progressPercent = document.getElementById('progressPercent');
            const overallBar = document.getElementById('overallProgressBar');
            
            progressBar.classList.remove('hidden');
            smartUpdateBtn.disabled = true;
            smartUpdateBtn.classList.add('opacity-50', 'cursor-not-allowed');
            
            // Helper function to update step
            function updateStep(stepNum, status) {
                const step = document.getElementById(`step${stepNum}`);
                const circle = step.querySelector('div:first-child');
                const text = step.querySelector('div:last-child');
                const icon = circle.querySelector('i');
                
                circle.className = circle.className.replace('step-active', '').replace('step-completed', '');
                text.className = text.className.replace('text-active', '').replace('text-completed', '');
                
                if (status === 'active') {
                    circle.classList.add('step-active');
                    text.classList.add('text-active');
                } else if (status === 'completed') {
                    circle.classList.add('step-completed');
                    text.classList.add('text-completed');
                    icon.className = 'fas fa-check text-sm';
                }
                
                // Update connector
                if (stepNum < 3) {
                    const connector = document.getElementById(`connector${stepNum}`);
                    if (status === 'completed') {
                        connector.classList.add('connector-completed');
                    }
                }
            }
            
            try {
                // Step 1: Fetch Data
                updateStep(1, 'active');
                progressPercent.textContent = '0%';
                overallBar.style.width = '0%';
                progressTitle.textContent = isArabic ? '⚡ جاري جلب البيانات...' : '⚡ Fetching data...';
                
                const fetchResponse = await fetch('api/fetch_data.php');
                
                // Check response validity
                if (!fetchResponse.ok) {
                    throw new Error('Network response was not ok');
                }
                
                const contentType = fetchResponse.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    throw new Error('Invalid response format');
                }
                
                const fetchResult = await fetchResponse.json();
                
                if (!fetchResult.success) {
                    throw new Error(fetchResult.message || 'Failed to fetch data');
                }
                
                updateStep(1, 'completed');
                progressPercent.textContent = '33%';
                overallBar.style.width = '33%';
                
                await new Promise(r => setTimeout(r, 800));
                
                // Step 2: Run Analysis
                updateStep(2, 'active');
                progressPercent.textContent = '33%';
                progressTitle.textContent = isArabic ? '🧠 جاري تشغيل التحليل...' : '🧠 Running analysis...';
                
                // Fetch with longer timeout for analysis
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 90000); // 90 seconds
                
                let analysisResponse;
                try {
                    analysisResponse = await fetch('api/run_analysis.php', {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json'
                        },
                        signal: controller.signal
                    });
                    clearTimeout(timeoutId);
                } catch (fetchError) {
                    clearTimeout(timeoutId);
                    if (fetchError.name === 'AbortError') {
                        throw new Error(isArabic ? 
                            'انتهت مهلة التحليل (90 ثانية). يرجى المحاولة مرة أخرى.' : 
                            'Analysis timeout (90 seconds). Please try again.'
                        );
                    }
                    throw fetchError;
                }
                
                if (!analysisResponse.ok) {
                    const errorText = await analysisResponse.text();
                    console.error('Analysis API error:', errorText);
                    throw new Error(isArabic ? 
                        `فشل التحليل (${analysisResponse.status}): ${errorText.substring(0, 100)}` : 
                        `Analysis failed (${analysisResponse.status}): ${errorText.substring(0, 100)}`
                    );
                }
                
                const analysisContentType = analysisResponse.headers.get('content-type');
                if (!analysisContentType || !analysisContentType.includes('application/json')) {
                    const rawText = await analysisResponse.text();
                    console.error('Invalid content type:', analysisContentType, 'Response:', rawText);
                    throw new Error(isArabic ? 
                        'تنسيق الاستجابة غير صالح' : 
                        'Invalid response format'
                    );
                }
                
                const analysisResult = await analysisResponse.json();
                
                if (!analysisResult.success) {
                    throw new Error(analysisResult.message || (isArabic ? 'فشل تشغيل التحليل' : 'Failed to run analysis'));
                }
                
                updateStep(2, 'completed');
                progressPercent.textContent = '66%';
                overallBar.style.width = '66%';
                
                await new Promise(r => setTimeout(r, 800));
                
                // Step 3: Refresh Forecast
                updateStep(3, 'active');
                progressPercent.textContent = '66%';
                progressTitle.textContent = isArabic ? '📊 جاري تحديث التوقع...' : '📊 Refreshing forecast...';
                
                await loadMarketForecast();
                await loadAdvancedAnalysis();
                
                updateStep(3, 'completed');
                progressPercent.textContent = '100%';
                overallBar.style.width = '100%';
                progressTitle.innerHTML = isArabic ? 
                    '<span class="text-green-400">✅ اكتمل التحديث بنجاح!</span>' : 
                    '<span class="text-green-400">✅ Update completed!</span>';
                
                if (typeof window.showNotification === 'function') {
                    window.showNotification(
                        isArabic ? '✅ اكتمل التحديث الذكي بنجاح! 🎉' : '✅ Smart update completed successfully! 🎉', 
                        'success'
                    );
                }
                
                // Reload after 3 seconds
                setTimeout(() => window.location.reload(), 3000);
                
            } catch (error) {
                console.error('Smart update error:', error);
                
                // Show error
                progressTitle.innerHTML = isArabic ? 
                    '<span class="text-red-400">❌ حدث خطأ!</span>' : 
                    '<span class="text-red-400">❌ Error occurred!</span>';
                
                if (typeof window.showNotification === 'function') {
                    window.showNotification(
                        '❌ ' + (isArabic ? 'خطأ: ' : 'Error: ') + error.message, 
                        'error'
                    );
                }
                
                // Re-enable button
                setTimeout(() => {
                    smartUpdateBtn.disabled = false;
                    smartUpdateBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                    progressBar.classList.add('hidden');
                }, 3000);
            }
        }
        
        // Refresh sentiment
        function refreshSentiment() {
            if (typeof window.showNotification === 'function') {
                window.showNotification('🔄 <?= $isRTL ? "جاري تحديث معنويات السوق..." : "Refreshing market sentiment..." ?>', 'info');
            }
            setTimeout(() => window.location.reload(), 1000);
        }
        
        // Switch News Tabs
        function switchNewsTab(tab) {
            const recentTab = document.getElementById('recentNewsTab');
            const upcomingTab = document.getElementById('upcomingEventsTab');
            const btnRecent = document.getElementById('tabRecent');
            const btnUpcoming = document.getElementById('tabUpcoming');
            
            if (tab === 'recent') {
                recentTab.classList.remove('hidden');
                upcomingTab.classList.add('hidden');
                btnRecent.classList.add('border-blue-500', 'text-blue-400');
                btnRecent.classList.remove('border-transparent', 'text-gray-400');
                btnUpcoming.classList.remove('border-blue-500', 'text-blue-400');
                btnUpcoming.classList.add('border-transparent', 'text-gray-400');
            } else {
                recentTab.classList.add('hidden');
                upcomingTab.classList.remove('hidden');
                btnUpcoming.classList.add('border-blue-500', 'text-blue-400');
                btnUpcoming.classList.remove('border-transparent', 'text-gray-400');
                btnRecent.classList.remove('border-blue-500', 'text-blue-400');
                btnRecent.classList.add('border-transparent', 'text-gray-400');
                
                // Start countdown timers
                updateCountdowns();
                
                // Trigger translation for events if Arabic
                <?php if ($isRTL): ?>
                window.dispatchEvent(new Event('translationNeeded'));
                <?php endif; ?>
            }
        }
        
        // Update countdown timers
        function updateCountdowns() {
            const timers = document.querySelectorAll('.countdown-timer');
            
            timers.forEach(timer => {
                const target = parseInt(timer.dataset.target);
                const now = Math.floor(Date.now() / 1000);
                const diff = target - now;
                
                if (diff <= 0) {
                    timer.innerHTML = '<?= $isRTL ? "انتهى الحدث" : "Event passed" ?>';
                    return;
                }
                
                const days = Math.floor(diff / 86400);
                const hours = Math.floor((diff % 86400) / 3600);
                const minutes = Math.floor((diff % 3600) / 60);
                const seconds = diff % 60;
                
                let html = '';
                if (days > 0) {
                    html += `<span class="days">${days}</span><?= $isRTL ? ' يوم ' : 'd ' ?>`;
                }
                html += `<span class="hours">${hours}</span><?= $isRTL ? ' س ' : 'h ' ?>`;
                html += `<span class="minutes">${minutes}</span><?= $isRTL ? ' د ' : 'm ' ?>`;
                html += `<span class="seconds">${seconds}</span><?= $isRTL ? ' ث' : 's' ?>`;
                
                timer.innerHTML = html;
            });
        }
        
        // Update countdowns every second
        setInterval(updateCountdowns, 1000);
        
        // Fetch Events
        async function fetchEvents() {
            if (typeof window.showNotification === 'function') {
                window.showNotification('🔄 <?= $isRTL ? "جاري جلب الأحداث القادمة من الأخبار..." : "Fetching upcoming events..." ?>', 'info');
            }
            
            try {
                const response = await fetch('collector/events_scraper.php?run=1');
                const text = await response.text();
                
                console.log('Events fetch result:', text);
                
                if (typeof window.showNotification === 'function') {
                    window.showNotification('✅ <?= $isRTL ? "تم جلب الأحداث بنجاح. جاري تحديث الصفحة..." : "Events fetched successfully. Refreshing..." ?>', 'success');
                }
                
                setTimeout(() => window.location.reload(), 2000);
            } catch (error) {
                console.error('Fetch events error:', error);
                if (typeof window.showNotification === 'function') {
                    window.showNotification('❌ Error: ' + error.message, 'error');
                }
            }
        }
        
        // Translation function
        // Simple translation using MyMemory API
        async function translateToArabic(text) {
            try {
                const response = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|ar`);
                const data = await response.json();
                return data.responseData.translatedText || text;
            } catch (error) {
                return text;
            }
        }
        
        // Simple translation for untranslated items only
        <?php if ($isRTL): ?>
        async function translateNews() {
            const statusEl = document.getElementById('translationStatus');
            
            // Only translate items marked as needing translation
            const items = document.querySelectorAll('[data-needs-translation="1"]:not([data-translated])');
            
            if (items.length === 0) {
                if (statusEl) statusEl.innerHTML = '<i class="fas fa-check text-green-500"></i>';
                return;
            }
            
            if (statusEl) statusEl.innerHTML = '<i class="fas fa-language"></i> ترجمة...';
            
            for (let item of items) {
                const original = item.dataset.original;
                if (original) {
                    const translated = await translateToArabic(original);
                    item.textContent = translated;
                    if (item.classList.contains('news-summary')) item.textContent += '...';
                    item.dataset.translated = 'true';
                    await new Promise(r => setTimeout(r, 200));
                }
            }
            
            if (statusEl) {
                statusEl.innerHTML = '<i class="fas fa-check text-green-500"></i>';
                setTimeout(() => statusEl.innerHTML = '', 2000);
            }
        }
        
        // Simple auto-translation check (background)
        async function checkAndTranslate() {
            try {
                const response = await fetch('cron/auto_translate.php?json=1');
                const result = await response.json();
                
                if (result.success && result.total > 0) {
                    console.log(`✅ Translated: ${result.total} items`);
                    setTimeout(() => location.reload(), 1000);
                }
            } catch (error) {
                console.log('Translation skipped');
            }
        }
        
        // Auto-check on load (silent)
        checkAndTranslate();
        
        // Auto translate on page load (much faster now!)
        setTimeout(translateNews, 500);
        
        // Translate when switching to events tab
        window.addEventListener('translationNeeded', () => {
            setTimeout(translateNews, 300);
        });
        <?php endif; ?>
        
        // Toggle Learning Content Visibility
        function toggleLearningContent() {
            const content = document.getElementById('learningContent');
            const icon = document.getElementById('learningToggleIcon');
            const text = document.getElementById('learningToggleText');
            
            if (content.classList.contains('hidden')) {
                content.classList.remove('hidden');
                icon.className = 'fas fa-eye-slash';
                text.textContent = '<?= $isRTL ? 'إخفاء' : 'Hide' ?>';
            } else {
                content.classList.add('hidden');
                icon.className = 'fas fa-eye';
                text.textContent = '<?= $isRTL ? 'إظهار' : 'Show' ?>';
            }
        }
        
        // Load Advanced Analysis (Volume + Fear & Greed)
        async function loadAdvancedAnalysis() {
            const container = document.getElementById('advanced-analysis-content');
            if (!container) return;
            
            // Show loading
            container.innerHTML = `
                <div class="text-center py-8">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400"></div>
                    <p class="text-gray-400 mt-2"><?= $isRTL ? 'جارٍ تحميل...' : 'Loading...' ?></p>
                </div>
            `;
            
            try {
                const response = await fetch(`api/get_advanced_analysis.php?symbol=<?= $selectedSymbol ?>&lang=<?= $lang ?>`);
                const data = await response.json();
                
                if (!data.success) {
                    throw new Error(data.error || 'Failed to load analysis');
                }
                
                const { volume_analysis, fear_greed_index, liquidity, accumulation } = data;
                
                // Build HTML
                let html = '';
                
                // === Fear & Greed Index Section ===
                if (fear_greed_index) {
                    const fg = fear_greed_index;
                    html += `
                    <div class="bg-black bg-opacity-30 rounded-lg p-4 border-2 border-cyan-600">
                        <h4 class="text-lg font-bold mb-3 flex items-center justify-between">
                            <span>
                                <i class="fas fa-balance-scale text-cyan-400"></i>
                                <?= $isRTL ? 'مؤشر الخوف والطمع' : 'Fear & Greed Index' ?>
                            </span>
                            <span class="text-3xl">${fg.emoji}</span>
                        </h4>
                        
                        <div class="text-center mb-4">
                            <div class="text-6xl font-bold mb-2" style="color: ${fg.color}">${fg.value}</div>
                            <div class="text-sm text-gray-300">${fg.classification}</div>
                        </div>
                        
                        <!-- Gauge-like Progress Bar -->
                        <div class="relative h-4 bg-gray-700 rounded-full overflow-hidden mb-4">
                            <div class="absolute h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 w-full"></div>
                            <div class="absolute h-full bg-black" style="left: ${fg.value}%; width: calc(100% - ${fg.value}%)"></div>
                        </div>
                        
                        <div class="space-y-2 text-sm">
                            <div class="flex items-start gap-2">
                                <i class="fas fa-info-circle text-cyan-400 mt-1"></i>
                                <span class="text-gray-300">${fg.description}</span>
                            </div>
                            <div class="flex items-start gap-2">
                                <i class="fas fa-lightbulb text-yellow-400 mt-1"></i>
                                <span class="text-gray-300"><strong><?= $isRTL ? 'توصية:' : 'Recommendation:' ?></strong> ${fg.recommendation}</span>
                            </div>
                            <div class="flex items-center justify-between bg-gray-800 rounded p-2 mt-3">
                                <span class="text-gray-400"><?= $isRTL ? 'إشارة التداول:' : 'Trading Signal:' ?></span>
                                <span class="font-bold ${fg.signal.includes('buy') ? 'text-green-400' : (fg.signal.includes('sell') ? 'text-red-400' : 'text-gray-400')}">
                                    ${(() => {
                                        const signalMap = {
                                            'strong_buy': <?= $isRTL ? 'true' : 'false' ?> ? 'شراء قوي' : 'STRONG BUY',
                                            'buy': <?= $isRTL ? 'true' : 'false' ?> ? 'شراء' : 'BUY',
                                            'hold': <?= $isRTL ? 'true' : 'false' ?> ? 'انتظار' : 'HOLD',
                                            'consider_sell': <?= $isRTL ? 'true' : 'false' ?> ? 'فكر بالبيع' : 'CONSIDER SELL',
                                            'strong_sell': <?= $isRTL ? 'true' : 'false' ?> ? 'بيع قوي' : 'STRONG SELL'
                                        };
                                        return signalMap[fg.signal] || fg.signal.toUpperCase().replace('_', ' ');
                                    })()}
                                </span>
                            </div>
                        </div>
                    </div>
                    `;
                }
                
                // === Volume Analysis Section ===
                if (volume_analysis) {
                    const va = volume_analysis;
                    const signalColor = va.signal.includes('bullish') ? 'text-green-400' : (va.signal.includes('bearish') ? 'text-red-400' : 'text-gray-400');
                    const signalBg = va.signal.includes('bullish') ? 'bg-green-900' : (va.signal.includes('bearish') ? 'bg-red-900' : 'bg-gray-800');
                    
                    // Translate signal
                    const signalTranslations = {
                        'strong_bullish': <?= $isRTL ? 'true' : 'false' ?> ? 'صاعد بقوة' : 'STRONG BULLISH',
                        'bullish': <?= $isRTL ? 'true' : 'false' ?> ? 'صاعد' : 'BULLISH',
                        'neutral': <?= $isRTL ? 'true' : 'false' ?> ? 'محايد' : 'NEUTRAL',
                        'bearish': <?= $isRTL ? 'true' : 'false' ?> ? 'هابط' : 'BEARISH',
                        'strong_bearish': <?= $isRTL ? 'true' : 'false' ?> ? 'هابط بقوة' : 'STRONG BEARISH'
                    };
                    const signalText = signalTranslations[va.signal] || va.signal.toUpperCase().replace('_', ' ');
                    
                    html += `
                    <div class="bg-black bg-opacity-30 rounded-lg p-4 border-2 border-blue-600">
                        <h4 class="text-lg font-bold mb-3">
                            <i class="fas fa-chart-line text-blue-400"></i>
                            <?= $isRTL ? 'تحليل حجم التداول' : 'Volume Analysis' ?>
                        </h4>
                        
                        <!-- Overall Volume Score -->
                        <div class="text-center mb-4 p-3 ${signalBg} bg-opacity-40 rounded-lg">
                            <div class="text-sm text-gray-400 mb-1"><?= $isRTL ? 'الإشارة الإجمالية' : 'Overall Signal' ?></div>
                            <div class="text-2xl font-bold ${signalColor}">${signalText}</div>
                            <div class="text-lg font-bold mt-2"><?= $isRTL ? 'الدرجة:' : 'Score:' ?> <span class="${va.overall_score > 0 ? 'text-green-400' : 'text-red-400'}">${va.overall_score > 0 ? '+' : ''}${(va.overall_score || 0).toFixed(0)}/100</span></div>
                        </div>
                        
                        <!-- Detailed Metrics -->
                        <div class="space-y-3 text-sm">
                    `;
                    
                    // VWAP
                    if (va.vwap) {
                        const positionText = va.vwap.position === 'above' ? 
                            (<?= $isRTL ? 'true' : 'false' ?> ? 'فوق المتوسط' : 'ABOVE') : 
                            (<?= $isRTL ? 'true' : 'false' ?> ? 'تحت المتوسط' : 'BELOW');
                        html += `
                            <div class="bg-gray-800 rounded p-3">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="font-bold text-gray-300">VWAP <?= $isRTL ? '(متوسط السعر المرجح بالحجم)' : '' ?></span>
                                    <span class="text-xs px-2 py-1 rounded ${va.vwap.position === 'above' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}">${positionText}</span>
                                </div>
                                <div class="text-gray-400"><?= $isRTL ? 'الانحراف:' : 'Deviation:' ?> <span class="${va.vwap.deviation_pct > 0 ? 'text-green-400' : 'text-red-400'}">${va.vwap.deviation_pct > 0 ? '+' : ''}${(va.vwap.deviation_pct || 0).toFixed(2)}%</span></div>
                            </div>
                        `;
                    }
                    
                    // OBV
                    if (va.obv) {
                        const trendText = va.obv.trend === 'accumulation' ? 
                            (<?= $isRTL ? 'true' : 'false' ?> ? 'تراكم' : 'ACCUMULATION') : 
                            (<?= $isRTL ? 'true' : 'false' ?> ? 'توزيع' : 'DISTRIBUTION');
                        html += `
                            <div class="bg-gray-800 rounded p-3">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="font-bold text-gray-300">OBV <?= $isRTL ? '(التراكم/التوزيع)' : '' ?></span>
                                    <span class="text-xs px-2 py-1 rounded ${va.obv.signal === 'bullish' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}">${trendText}</span>
                                </div>
                                <div class="text-gray-400"><?= $isRTL ? 'القوة:' : 'Strength:' ?> <span class="text-blue-400">${((va.obv.strength || 0) * 100).toFixed(0)}%</span></div>
                            </div>
                        `;
                    }
                    
                    // Buy/Sell Pressure
                    if (va.pressure) {
                        const dominanceText = va.pressure.dominance === 'buyers' ? 
                            (<?= $isRTL ? 'true' : 'false' ?> ? 'المشترون' : 'BUYERS') : 
                            (<?= $isRTL ? 'true' : 'false' ?> ? 'البائعون' : 'SELLERS');
                        html += `
                            <div class="bg-gray-800 rounded p-3">
                                <div class="font-bold text-gray-300 mb-2"><?= $isRTL ? 'ضغط الشراء/البيع' : 'Buy/Sell Pressure' ?></div>
                                <div class="flex gap-2 mb-2">
                                    <div class="flex-1">
                                        <div class="text-xs text-green-400 mb-1"><?= $isRTL ? 'شراء' : 'Buy' ?></div>
                                        <div class="h-2 bg-gray-700 rounded-full overflow-hidden">
                                            <div class="h-full bg-green-500" style="width: ${va.pressure.buy_pressure}%"></div>
                                        </div>
                                        <div class="text-xs text-gray-400 mt-1">${(va.pressure.buy_pressure || 0).toFixed(1)}%</div>
                                    </div>
                                    <div class="flex-1">
                                        <div class="text-xs text-red-400 mb-1"><?= $isRTL ? 'بيع' : 'Sell' ?></div>
                                        <div class="h-2 bg-gray-700 rounded-full overflow-hidden">
                                            <div class="h-full bg-red-500" style="width: ${va.pressure.sell_pressure || 0}%"></div>
                                        </div>
                                        <div class="text-xs text-gray-400 mt-1">${(va.pressure.sell_pressure || 0).toFixed(1)}%</div>
                                    </div>
                                </div>
                                <div class="text-xs text-center text-gray-400"><?= $isRTL ? 'السيطرة:' : 'Dominance:' ?> <span class="font-bold ${va.pressure.dominance === 'buyers' ? 'text-green-400' : 'text-red-400'}">${dominanceText}</span></div>
                            </div>
                        `;
                    }
                    
                    // Anomalous Volume
                    if (va.anomaly && va.anomaly.is_anomalous) {
                        html += `
                            <div class="bg-yellow-900 bg-opacity-30 border border-yellow-600 rounded p-3">
                                <div class="flex items-center gap-2 mb-1">
                                    <i class="fas fa-exclamation-triangle text-yellow-400"></i>
                                    <span class="font-bold text-yellow-300"><?= $isRTL ? '🐋 نشاط حيتان محتمل!' : '🐋 Potential Whale Activity!' ?></span>
                                </div>
                                <div class="text-sm text-gray-300"><?= $isRTL ? 'حجم غير طبيعي' : 'Anomalous volume' ?> (${(va.anomaly.multiplier || 0).toFixed(1)}× <?= $isRTL ? 'من المعدل' : 'avg' ?>)</div>
                            </div>
                        `;
                    }
                    
                    html += `
                        </div>
                    </div>
                    `;
                }
                
                // === Liquidity Analysis Section ===
                if (liquidity && liquidity.bitcoin && liquidity.altcoins) {
                    const btc = liquidity.bitcoin;
                    const alt = liquidity.altcoins;
                    const flow = liquidity.money_flow;
                    const market = liquidity.market_overview;
                    
                    // Determine flow arrow and color
                    const flowIcons = {
                        'into_btc': '⬆️ → BTC',
                        'into_altcoins': '⬇️ → ALT',
                        'outflow': '🚪',
                        'neutral': '➡️'
                    };
                    const flowColors = {
                        'into_btc': 'text-orange-400',
                        'into_altcoins': 'text-cyan-400',
                        'outflow': 'text-red-400',
                        'neutral': 'text-gray-400'
                    };
                    
                    html += `
                    <div class="bg-black bg-opacity-30 rounded-lg p-4 border-2 border-purple-600">
                        <h4 class="text-lg font-bold mb-3">
                            <i class="fas fa-water text-purple-400"></i>
                            <?= $isRTL ? 'تحليل السيولة' : 'Liquidity Analysis' ?>
                        </h4>
                        
                        <!-- Market Overview -->
                        <div class="grid grid-cols-2 gap-3 mb-4">
                            <div class="bg-gray-800 rounded p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1"><?= $isRTL ? 'إجمالي القيمة السوقية' : 'Total Market Cap' ?></div>
                                <div class="text-lg font-bold text-cyan-400">$${(market.total_market_cap / 1e12).toFixed(2)}T</div>
                                <div class="text-xs ${market.market_cap_change_24h >= 0 ? 'text-green-400' : 'text-red-400'}">
                                    ${market.market_cap_change_24h >= 0 ? '▲' : '▼'} ${Math.abs(market.market_cap_change_24h).toFixed(2)}%
                                </div>
                            </div>
                            <div class="bg-gray-800 rounded p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1"><?= $isRTL ? 'حجم التداول 24س' : '24h Volume' ?></div>
                                <div class="text-lg font-bold text-blue-400">$${(market.total_volume_24h / 1e9).toFixed(1)}B</div>
                                <div class="text-xs text-gray-400"><?= $isRTL ? 'السيولة:' : 'Liquidity:' ?> ${market.overall_liquidity.toFixed(2)}%</div>
                            </div>
                        </div>
                        
                        <!-- Bitcoin vs Altcoins -->
                        <div class="mb-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-bold text-gray-300"><?= $isRTL ? 'هيمنة السوق' : 'Market Dominance' ?></span>
                                <span class="text-xs ${flowColors[flow.direction]}">${flowIcons[flow.direction] || '➡️'}</span>
                            </div>
                            
                            <!-- Dominance Bar -->
                            <div class="flex h-8 rounded-lg overflow-hidden mb-1">
                                <div class="flex items-center justify-center bg-orange-600 text-white text-xs font-bold transition-all duration-500" style="width: ${btc.dominance}%">
                                    BTC ${btc.dominance}%
                                </div>
                                <div class="flex items-center justify-center bg-cyan-600 text-white text-xs font-bold transition-all duration-500" style="width: ${alt.dominance}%">
                                    ALT ${alt.dominance}%
                                </div>
                            </div>
                            
                            <!-- BTC & ALT Details -->
                            <div class="grid grid-cols-2 gap-3 mt-3">
                                <!-- Bitcoin -->
                                <div class="bg-orange-900 bg-opacity-30 border border-orange-600 rounded p-3">
                                    <div class="text-xs text-orange-400 mb-2 font-bold">
                                        <i class="fab fa-bitcoin"></i> <?= $isRTL ? 'بتكوين' : 'Bitcoin' ?>
                                    </div>
                                    <div class="text-xs text-gray-400 space-y-1">
                                        <div><?= $isRTL ? 'القيمة السوقية:' : 'Market Cap:' ?> <span class="text-white font-bold">$${(btc.market_cap / 1e12).toFixed(2)}T</span></div>
                                        <div><?= $isRTL ? 'الحجم:' : 'Volume:' ?> <span class="text-white font-bold">$${(btc.volume_24h / 1e9).toFixed(1)}B</span></div>
                                        <div class="flex items-center gap-1">
                                            <span><?= $isRTL ? 'السيولة:' : 'Liquidity:' ?></span>
                                            <span class="text-xs px-2 py-0.5 rounded ${
                                                btc.liquidity_level === 'high' ? 'bg-green-700 text-green-200' : 
                                                (btc.liquidity_level === 'medium' ? 'bg-yellow-700 text-yellow-200' : 'bg-red-700 text-red-200')
                                            }">${
                                                btc.liquidity_level === 'high' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'عالية' : 'HIGH') : 
                                                (btc.liquidity_level === 'medium' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'متوسطة' : 'MED') : (<?= $isRTL ? 'true' : 'false' ?> ? 'منخفضة' : 'LOW'))
                                            }</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Altcoins -->
                                <div class="bg-cyan-900 bg-opacity-30 border border-cyan-600 rounded p-3">
                                    <div class="text-xs text-cyan-400 mb-2 font-bold">
                                        <i class="fas fa-coins"></i> <?= $isRTL ? 'العملات البديلة' : 'Altcoins' ?>
                                    </div>
                                    <div class="text-xs text-gray-400 space-y-1">
                                        <div><?= $isRTL ? 'القيمة السوقية:' : 'Market Cap:' ?> <span class="text-white font-bold">$${(alt.market_cap / 1e12).toFixed(2)}T</span></div>
                                        <div><?= $isRTL ? 'الحجم:' : 'Volume:' ?> <span class="text-white font-bold">$${(alt.volume_24h / 1e9).toFixed(1)}B</span></div>
                                        <div class="flex items-center gap-1">
                                            <span><?= $isRTL ? 'السيولة:' : 'Liquidity:' ?></span>
                                            <span class="text-xs px-2 py-0.5 rounded ${
                                                alt.liquidity_level === 'high' ? 'bg-green-700 text-green-200' : 
                                                (alt.liquidity_level === 'medium' ? 'bg-yellow-700 text-yellow-200' : 'bg-red-700 text-red-200')
                                            }">${
                                                alt.liquidity_level === 'high' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'عالية' : 'HIGH') : 
                                                (alt.liquidity_level === 'medium' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'متوسطة' : 'MED') : (<?= $isRTL ? 'true' : 'false' ?> ? 'منخفضة' : 'LOW'))
                                            }</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Money Flow -->
                        <div class="bg-gray-800 rounded p-3 mb-3">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-bold text-gray-300">
                                    <i class="fas fa-exchange-alt"></i> <?= $isRTL ? 'تدفق الأموال' : 'Money Flow' ?>
                                </span>
                                <span class="text-xs px-2 py-1 rounded ${
                                    flow.strength === 'strong' ? 'bg-purple-700 text-purple-200' : 
                                    (flow.strength === 'medium' ? 'bg-blue-700 text-blue-200' : 'bg-gray-700 text-gray-300')
                                }">${
                                    flow.strength === 'strong' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'قوي' : 'STRONG') : 
                                    (flow.strength === 'medium' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'متوسط' : 'MEDIUM') : (<?= $isRTL ? 'true' : 'false' ?> ? 'ضعيف' : 'WEAK'))
                                }</span>
                            </div>
                            <div class="text-center">
                                <div class="text-2xl mb-1">${flowIcons[flow.direction]}</div>
                                <div class="text-sm ${flowColors[flow.direction]}">${
                                    flow.direction === 'into_btc' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'الأموال تتدفق إلى البتكوين' : 'Money flowing into Bitcoin') : 
                                    (flow.direction === 'into_altcoins' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'الأموال تتدفق إلى العملات البديلة' : 'Money flowing into Altcoins') : 
                                    (flow.direction === 'outflow' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'الأموال تغادر السوق' : 'Money leaving the market') : (<?= $isRTL ? 'true' : 'false' ?> ? 'محايد' : 'Neutral')))
                                }</div>
                            </div>
                        </div>
                        
                        <!-- Recommendations -->
                        ${liquidity.recommendations && liquidity.recommendations.length > 0 ? `
                        <div class="space-y-2">
                            ${liquidity.recommendations.map(rec => `
                                <div class="bg-${rec.priority === 'high' ? 'red' : (rec.priority === 'medium' ? 'yellow' : 'blue')}-900 bg-opacity-30 border border-${rec.priority === 'high' ? 'red' : (rec.priority === 'medium' ? 'yellow' : 'blue')}-600 rounded p-2 text-xs">
                                    ${rec.message || rec.message_en}
                                </div>
                            `).join('')}
                        </div>
                        ` : ''}
                    </div>
                    `;
                }
                
                // === Accumulation/Distribution Analysis Section ===
                if (accumulation && accumulation.ad_line) {
                    const acc = accumulation;
                    const overallSignalColors = {
                        'strong_accumulation': 'text-green-500 bg-green-900',
                        'accumulation': 'text-green-400 bg-green-900',
                        'neutral': 'text-gray-400 bg-gray-800',
                        'distribution': 'text-red-400 bg-red-900',
                        'strong_distribution': 'text-red-500 bg-red-900'
                    };
                    
                    const signalText = {
                        'strong_accumulation': <?= $isRTL ? 'true' : 'false' ?> ? 'تراكم قوي 🐋' : 'STRONG ACCUMULATION 🐋',
                        'accumulation': <?= $isRTL ? 'true' : 'false' ?> ? 'تراكم' : 'ACCUMULATION',
                        'neutral': <?= $isRTL ? 'true' : 'false' ?> ? 'محايد' : 'NEUTRAL',
                        'distribution': <?= $isRTL ? 'true' : 'false' ?> ? 'توزيع' : 'DISTRIBUTION',
                        'strong_distribution': <?= $isRTL ? 'true' : 'false' ?> ? 'توزيع قوي ⚠️' : 'STRONG DISTRIBUTION ⚠️'
                    };
                    
                    html += `
                    <div class="bg-black bg-opacity-30 rounded-lg p-4 border-2 border-emerald-600">
                        <h4 class="text-lg font-bold mb-3">
                            <i class="fas fa-chart-area text-emerald-400"></i>
                            <?= $isRTL ? 'تحليل الاستحواذ / التوزيع' : 'Accumulation / Distribution' ?>
                        </h4>
                        
                        <!-- Overall Signal -->
                        <div class="text-center mb-4 p-4 ${overallSignalColors[acc.overall_signal]} bg-opacity-40 rounded-lg border-2 border-current">
                            <div class="text-sm text-gray-400 mb-1"><?= $isRTL ? 'الإشارة الإجمالية' : 'Overall Signal' ?></div>
                            <div class="text-2xl font-bold mb-2">${signalText[acc.overall_signal] || acc.overall_signal}</div>
                            <div class="text-sm"><?= $isRTL ? 'الثقة:' : 'Confidence:' ?> <span class="font-bold">${acc.confidence}%</span></div>
                        </div>
                        
                        <!-- Metrics Grid -->
                        <div class="grid grid-cols-2 gap-3 mb-4">
                            <!-- A/D Line -->
                            <div class="bg-gray-800 rounded p-3">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-bold text-gray-300">A/D Line</span>
                                    <span class="text-xs px-2 py-0.5 rounded ${
                                        acc.ad_line.trend === 'accumulation' ? 'bg-green-700 text-green-200' : 
                                        (acc.ad_line.trend === 'distribution' ? 'bg-red-700 text-red-200' : 'bg-gray-700 text-gray-300')
                                    }">${
                                        acc.ad_line.trend === 'accumulation' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'تراكم' : 'ACCUM') : 
                                        (acc.ad_line.trend === 'distribution' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'توزيع' : 'DIST') : (<?= $isRTL ? 'true' : 'false' ?> ? 'محايد' : 'NEUTRAL'))
                                    }</span>
                                </div>
                                <div class="text-xs text-gray-400"><?= $isRTL ? 'القوة:' : 'Strength:' ?> <span class="text-blue-400">${acc.ad_line.strength}%</span></div>
                            </div>
                            
                            <!-- Whale Activity -->
                            <div class="bg-gray-800 rounded p-3">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-bold text-gray-300">🐋 <?= $isRTL ? 'الحيتان' : 'Whales' ?></span>
                                    <span class="text-xs px-2 py-0.5 rounded ${
                                        acc.whale_activity.is_active ? 'bg-yellow-700 text-yellow-200 animate-pulse' : 'bg-gray-700 text-gray-300'
                                    }">${acc.whale_activity.is_active ? (<?= $isRTL ? 'true' : 'false' ?> ? 'نشط' : 'ACTIVE') : (<?= $isRTL ? 'true' : 'false' ?> ? 'هادئ' : 'QUIET')}</span>
                                </div>
                                <div class="text-xs text-gray-400">
                                    ${acc.whale_activity.is_active ? `
                                        ${<?= $isRTL ? 'true' : 'false' ?> ? 'النشاط:' : 'Activity:'} 
                                        <span class="${
                                            acc.whale_activity.action === 'accumulating' ? 'text-green-400' : 
                                            (acc.whale_activity.action === 'distributing' ? 'text-red-400' : 'text-yellow-400')
                                        } font-bold">
                                            ${
                                                acc.whale_activity.action === 'accumulating' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'شراء' : 'BUYING') : 
                                                (acc.whale_activity.action === 'distributing' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'بيع' : 'SELLING') : (<?= $isRTL ? 'true' : 'false' ?> ? 'نشط' : 'ACTIVE'))
                                            }
                                        </span>
                                        <div class="mt-1"><?= $isRTL ? 'الحجم:' : 'Volume:' ?> ${acc.whale_activity.volume_multiplier}x</div>
                                    ` : `<?= $isRTL ? 'لا نشاط غير عادي' : 'No unusual activity' ?>`}
                                </div>
                            </div>
                        </div>
                        
                        <!-- Exchange Flow & HODLer -->
                        <div class="grid grid-cols-2 gap-3 mb-4">
                            <!-- Exchange Flow -->
                            <div class="bg-gray-800 rounded p-3">
                                <div class="text-xs font-bold text-gray-300 mb-2">
                                    <i class="fas fa-exchange-alt"></i> <?= $isRTL ? 'تدفق المنصات' : 'Exchange Flow' ?>
                                </div>
                                <div class="text-center mb-1">
                                    <div class="text-2xl">${
                                        acc.exchange_flow.direction === 'outflow' ? '📤' : 
                                        (acc.exchange_flow.direction === 'inflow' ? '📥' : '↔️')
                                    }</div>
                                    <div class="text-xs ${
                                        acc.exchange_flow.direction === 'outflow' ? 'text-green-400' : 
                                        (acc.exchange_flow.direction === 'inflow' ? 'text-red-400' : 'text-gray-400')
                                    }">
                                        ${
                                            acc.exchange_flow.direction === 'outflow' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'خارج' : 'OUTFLOW') : 
                                            (acc.exchange_flow.direction === 'inflow' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'داخل' : 'INFLOW') : (<?= $isRTL ? 'true' : 'false' ?> ? 'محايد' : 'NEUTRAL'))
                                        }
                                    </div>
                                </div>
                                <div class="text-xs text-gray-400">${acc.exchange_flow.interpretation}</div>
                            </div>
                            
                            <!-- HODLer Strength -->
                            <div class="bg-gray-800 rounded p-3">
                                <div class="text-xs font-bold text-gray-300 mb-2">
                                    <i class="fas fa-hand-rock"></i> <?= $isRTL ? 'قوة الإمساك' : 'HODLer Strength' ?>
                                </div>
                                <div class="text-center">
                                    <div class="text-3xl font-bold mb-1 ${
                                        acc.hodler_strength.strength === 'strong' ? 'text-green-400' : 
                                        (acc.hodler_strength.strength === 'medium' ? 'text-yellow-400' : 'text-red-400')
                                    }">${acc.hodler_strength.score}</div>
                                    <div class="text-xs px-2 py-1 rounded ${
                                        acc.hodler_strength.strength === 'strong' ? 'bg-green-700 text-green-200' : 
                                        (acc.hodler_strength.strength === 'medium' ? 'bg-yellow-700 text-yellow-200' : 'bg-red-700 text-red-200')
                                    }">
                                        ${
                                            acc.hodler_strength.strength === 'strong' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'قوي' : 'STRONG') : 
                                            (acc.hodler_strength.strength === 'medium' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'متوسط' : 'MEDIUM') : (<?= $isRTL ? 'true' : 'false' ?> ? 'ضعيف' : 'WEAK'))
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Smart Money Indicator -->
                        ${acc.smart_money.is_active ? `
                        <div class="bg-gradient-to-r from-purple-900 to-pink-900 bg-opacity-50 border-2 border-purple-500 rounded p-3 mb-3">
                            <div class="flex items-center gap-2 mb-2">
                                <i class="fas fa-brain text-purple-400 text-xl"></i>
                                <span class="font-bold text-purple-200"><?= $isRTL ? '🧠 الأموال الذكية نشطة!' : '🧠 Smart Money Active!' ?></span>
                            </div>
                            <div class="text-sm text-gray-300">
                                ${<?= $isRTL ? 'true' : 'false' ?> ? 'الاتجاه:' : 'Action:'} 
                                <span class="font-bold ${acc.smart_money.action === 'accumulating' ? 'text-green-400' : 'text-red-400'}">
                                    ${acc.smart_money.action === 'accumulating' ? (<?= $isRTL ? 'true' : 'false' ?> ? 'تراكم' : 'ACCUMULATING') : (<?= $isRTL ? 'true' : 'false' ?> ? 'توزيع' : 'DISTRIBUTING')}
                                </span>
                                (${<?= $isRTL ? 'true' : 'false' ?> ? 'الثقة:' : 'Confidence:'} ${acc.smart_money.confidence}%)
                            </div>
                        </div>
                        ` : ''}
                        
                        <!-- Recommendations -->
                        ${acc.recommendations && acc.recommendations.length > 0 ? `
                        <div class="space-y-2">
                            ${acc.recommendations.map(rec => `
                                <div class="bg-${rec.priority === 'high' ? 'red' : (rec.priority === 'medium' ? 'yellow' : 'blue')}-900 bg-opacity-30 border border-${rec.priority === 'high' ? 'red' : (rec.priority === 'medium' ? 'yellow' : 'blue')}-600 rounded p-2 text-xs">
                                    ${rec.message || rec.message_en}
                                </div>
                            `).join('')}
                        </div>
                        ` : ''}
                    </div>
                    `;
                }
                
                container.innerHTML = html;
                
            } catch (error) {
                container.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-circle text-red-400 text-3xl mb-2"></i>
                        <p class="text-red-400"><?= $isRTL ? 'فشل التحميل' : 'Failed to load' ?></p>
                        <p class="text-xs text-gray-400 mt-1">${error.message}</p>
                    </div>
                `;
            }
        }
        
        // Auto-load on page load
        setTimeout(loadAdvancedAnalysis, 1000);
        
        // Load Market Forecast (Comprehensive)
        async function loadMarketForecast() {
            const container = document.getElementById('market-forecast-content');
            if (!container) return;
            
            const isArabic = <?= $isRTL ? 'true' : 'false' ?>;
            
            // Show loading
            container.innerHTML = `
                <div class="text-center py-8">
                    <div class="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-purple-300"></div>
                    <p class="text-gray-300 mt-2">${isArabic ? 'جارٍ تحليل جميع البيانات...' : 'Analyzing all data...'}</p>
                </div>
            `;
            
            try {
                // Try to get enhanced analysis first (Phase 1 update)
                const enhancedResponse = await fetch('api/get_enhanced_analysis.php?symbol=<?= $selectedSymbol ?>');
                const enhancedData = await enhancedResponse.json();
                
                let result, data, rec, forecast;
                
                if (enhancedData.success && enhancedData.overall_signal) {
                    // Use enhanced analysis (NEW)
                    result = { success: true };
                    rec = enhancedData.recommendation;
                    
                    // Get current price from multiple sources
                    let currentPrice = 0;
                    if (enhancedData.analysis.ai_prediction?.current_price) {
                        currentPrice = parseFloat(enhancedData.analysis.ai_prediction.current_price);
                    }
                    // Fallback to order book best bid/ask average
                    if (!currentPrice && enhancedData.analysis.order_book?.spread) {
                        const bestBid = parseFloat(enhancedData.analysis.order_book.spread.best_bid) || 0;
                        const bestAsk = parseFloat(enhancedData.analysis.order_book.spread.best_ask) || 0;
                        if (bestBid && bestAsk) {
                            currentPrice = (bestBid + bestAsk) / 2;
                        }
                    }
                    
                    // Calculate expected change based on overall signal
                    let expectedChange = 0;
                    if (enhancedData.overall_signal.signal.includes('STRONG_BULLISH')) {
                        expectedChange = Math.abs(enhancedData.recommendation.take_profit_pct) || 5;
                    } else if (enhancedData.overall_signal.signal.includes('BULLISH')) {
                        expectedChange = Math.abs(enhancedData.recommendation.take_profit_pct) || 3;
                    } else if (enhancedData.overall_signal.signal.includes('STRONG_BEARISH')) {
                        expectedChange = -Math.abs(enhancedData.recommendation.take_profit_pct) || -5;
                    } else if (enhancedData.overall_signal.signal.includes('BEARISH')) {
                        expectedChange = -Math.abs(enhancedData.recommendation.take_profit_pct) || -3;
                    }
                    
                    forecast = {
                        direction: enhancedData.overall_signal.signal.includes('BULLISH') ? 'bullish' : 
                                  enhancedData.overall_signal.signal.includes('BEARISH') ? 'bearish' : 'neutral',
                        confidence: enhancedData.overall_signal.confidence,
                        expected_change: expectedChange,
                        timeframe: {
                            label_en: enhancedData.recommendation.timeframe || '24h',
                            label_ar: enhancedData.recommendation.timeframe || '24 ساعة'
                        },
                        current_price: currentPrice,
                        bullish_points: Math.max(0, enhancedData.overall_signal.score * 100),
                        bearish_points: Math.max(0, -enhancedData.overall_signal.score * 100),
                        max_points: 100,
                        supporting_factors: [],
                        risk_factors: []
                    };
                    
                    // Add supporting/risk factors from new analyses
                    
                    // Order Book Analysis
                    if (enhancedData.analysis.order_book_signal?.signal === 'bullish') {
                        const obConfidence = (enhancedData.analysis.order_book_signal.confidence * 100).toFixed(0);
                        forecast.supporting_factors.push({
                            en: `Order Book shows strong buying pressure (${obConfidence}% confidence)`,
                            ar: `دفتر الأوامر يظهر ضغط شراء قوي (ثقة ${obConfidence}%)`
                        });
                    } else if (enhancedData.analysis.order_book_signal?.signal === 'bearish') {
                        const obConfidence = (enhancedData.analysis.order_book_signal.confidence * 100).toFixed(0);
                        forecast.risk_factors.push({
                            en: `Order Book shows strong selling pressure (${obConfidence}% confidence)`,
                            ar: `دفتر الأوامر يظهر ضغط بيع قوي (ثقة ${obConfidence}%)`
                        });
                    }
                    
                    // Multi-Timeframe Analysis
                    if (enhancedData.analysis.multi_timeframe?.confluence?.signal === 'bullish') {
                        const tfStrength = (enhancedData.analysis.multi_timeframe.confluence.strength * 100).toFixed(0);
                        forecast.supporting_factors.push({
                            en: `Multi-timeframe confluence detected (${tfStrength}% alignment)`,
                            ar: `تطابق عبر الأطر الزمنية المتعددة (توافق ${tfStrength}%)`
                        });
                    } else if (enhancedData.analysis.multi_timeframe?.confluence?.signal === 'bearish') {
                        const tfStrength = (enhancedData.analysis.multi_timeframe.confluence.strength * 100).toFixed(0);
                        forecast.risk_factors.push({
                            en: `Multi-timeframe bearish alignment (${tfStrength}%)`,
                            ar: `توافق هبوطي عبر الأطر الزمنية (${tfStrength}%)`
                        });
                    }
                    
                    // Social Media Analysis
                    if (enhancedData.analysis.social_media_signal?.signal === 'bullish') {
                        forecast.supporting_factors.push({
                            en: 'Positive social media sentiment detected',
                            ar: 'معنويات إيجابية على وسائل التواصل'
                        });
                    } else if (enhancedData.analysis.social_media_signal?.signal === 'bearish') {
                        forecast.risk_factors.push({
                            en: 'Negative social media sentiment',
                            ar: 'معنويات سلبية على وسائل التواصل'
                        });
                    }
                    
                    // FUD Detection
                    if (enhancedData.analysis.social_media?.fud_detection?.fud_detected) {
                        forecast.risk_factors.push({
                            en: 'FUD (Fear, Uncertainty, Doubt) detected in social media',
                            ar: 'تم رصد FUD (خوف وشك وعدم يقين) في وسائل التواصل'
                        });
                    }
                    
                    // Whale Walls
                    const buyWalls = enhancedData.analysis.order_book?.whale_walls?.buy_walls_count || 0;
                    const sellWalls = enhancedData.analysis.order_book?.whale_walls?.sell_walls_count || 0;
                    if (buyWalls > sellWalls && buyWalls > 2) {
                        forecast.supporting_factors.push({
                            en: `${buyWalls} large buy walls detected (whale accumulation)`,
                            ar: `${buyWalls} جدار شراء كبير مكتشف (تجميع حيتان)`
                        });
                    } else if (sellWalls > buyWalls && sellWalls > 2) {
                        forecast.risk_factors.push({
                            en: `${sellWalls} large sell walls detected (whale distribution)`,
                            ar: `${sellWalls} جدار بيع كبير مكتشف (توزيع حيتان)`
                        });
                    }
                    
                    // Volume Analysis
                    const volumeSignal = enhancedData.analysis.volume?.signal;
                    const volumeScore = enhancedData.analysis.volume?.overall_score || 0;
                    
                    if (volumeSignal === 'bullish' && volumeScore > 60) {
                        forecast.supporting_factors.push({
                            en: `Strong volume momentum supporting uptrend (score: ${volumeScore.toFixed(0)})`,
                            ar: `زخم حجم تداول قوي يدعم الاتجاه الصاعد (نقاط: ${volumeScore.toFixed(0)})`
                        });
                    } else if (volumeSignal === 'bearish' && volumeScore < 40) {
                        forecast.risk_factors.push({
                            en: `Volume declining, weak momentum (score: ${volumeScore.toFixed(0)})`,
                            ar: `حجم التداول يتراجع، زخم ضعيف (نقاط: ${volumeScore.toFixed(0)})`
                        });
                    }
                    
                    // AI Prediction
                    if (enhancedData.analysis.ai_prediction?.predicted_signal === 'bullish') {
                        const aiConf = (enhancedData.analysis.ai_prediction.confidence_score * 100).toFixed(0);
                        forecast.supporting_factors.push({
                            en: `AI model predicts bullish movement (${aiConf}% confidence)`,
                            ar: `نموذج الذكاء الاصطناعي يتوقع حركة صاعدة (ثقة ${aiConf}%)`
                        });
                    } else if (enhancedData.analysis.ai_prediction?.predicted_signal === 'bearish') {
                        const aiConf = (enhancedData.analysis.ai_prediction.confidence_score * 100).toFixed(0);
                        forecast.risk_factors.push({
                            en: `AI model predicts bearish movement (${aiConf}% confidence)`,
                            ar: `نموذج الذكاء الاصطناعي يتوقع حركة هابطة (ثقة ${aiConf}%)`
                        });
                    }
                    
                    // Format recommendation for display
                    // Translate action title
                    let actionTitle = rec.action;
                    if (isArabic) {
                        const actionTranslations = {
                            'BUY': 'شراء',
                            'SELL': 'بيع',
                            'WAIT': 'انتظار',
                            'HOLD': 'احتفاظ'
                        };
                        actionTitle = actionTranslations[rec.action] || rec.action;
                    }
                    
                    rec.title = actionTitle;
                    rec.action_color = rec.action === 'BUY' ? 'green' : (rec.action === 'SELL' ? 'red' : 'gray');
                    
                    // Calculate target and stop loss
                    let targetPrice = 0;
                    let stopLossPrice = 0;
                    
                    if (currentPrice > 0) {
                        const takeProfitPct = Math.abs(rec.take_profit_pct) || 0;
                        const stopLossPct = Math.abs(rec.stop_loss_pct) || 0;
                        
                        if (rec.action === 'BUY') {
                            targetPrice = currentPrice * (1 + takeProfitPct / 100);
                            stopLossPrice = currentPrice * (1 - stopLossPct / 100);
                        } else if (rec.action === 'SELL') {
                            targetPrice = currentPrice * (1 - takeProfitPct / 100);
                            stopLossPrice = currentPrice * (1 + stopLossPct / 100);
                        } else {
                            targetPrice = currentPrice;
                            stopLossPrice = currentPrice;
                        }
                    }
                    
                    // Translate description to Arabic if needed
                    let translatedDescription = rec.description;
                    if (isArabic) {
                        const descTranslations = {
                            'Strong bullish signals across all indicators. Good entry opportunity.': 'إشارات صعودية قوية عبر جميع المؤشرات. فرصة دخول جيدة.',
                            'Moderate bullish signals. Consider cautious entry.': 'إشارات صعودية معتدلة. فكر بدخول حذر.',
                            'Strong bearish signals. Consider exiting positions or shorting.': 'إشارات هبوطية قوية. فكر بالخروج أو البيع على المكشوف.',
                            'Moderate bearish signals. Reduce exposure or wait.': 'إشارات هبوطية معتدلة. قلّل التعرض أو انتظر.',
                            'No clear direction. Wait for stronger signals before entering positions.': 'لا يوجد اتجاه واضح. انتظر إشارات أقوى قبل الدخول.',
                            'Very strong buying opportunity detected. Multiple indicators align.': 'فرصة شراء قوية جداً. المؤشرات متطابقة.',
                            'Positive market sentiment with good entry potential.': 'معنويات السوق إيجابية مع إمكانية دخول جيدة.',
                            'Market is consolidating. No clear direction yet.': 'السوق في مرحلة تماسك. لا يوجد اتجاه واضح بعد.',
                            'Negative market sentiment. Consider reducing exposure.': 'معنويات السوق سلبية. فكر بتقليل التعرض.',
                            'Very strong selling pressure detected. High risk of decline.': 'ضغط بيع قوي جداً. خطر انخفاض مرتفع.'
                        };
                        translatedDescription = descTranslations[rec.description] || rec.description;
                    }
                    
                    rec.translatedDescription = translatedDescription;
                    rec.risk_management = {
                        target: targetPrice.toFixed(2),
                        stop_loss: stopLossPrice.toFixed(2),
                        advice: translatedDescription
                    };
                } else {
                    // Fallback to old API
                    const oldResponse = await fetch(`api/get_market_forecast.php?symbol=<?= $selectedSymbol ?>`);
                    result = await oldResponse.json();
                
                if (!result.success || !result.data) {
                    throw new Error(result.error || (isArabic ? 'لا توجد بيانات. قم بتشغيل التحليل أولاً.' : 'No data. Run analysis first.'));
                }
                
                    data = result.data;
                    rec = data.recommendation;
                    forecast = data;
                }
                
                // Validate data before using
                if (!forecast || typeof forecast.confidence === 'undefined') {
                    throw new Error(isArabic ? 'بيانات التوقع غير مكتملة. قم بتشغيل التحليل أولاً.' : 'Incomplete forecast data. Run analysis first.');
                }
                
                // Build HTML
                let html = `
                    <!-- Main Forecast -->
                    <div class="bg-black bg-opacity-40 rounded-xl p-6 border-2 border-${rec.action_color === 'green' ? 'green' : (rec.action_color === 'red' ? 'red' : 'gray')}-500">
                        <div class="text-center mb-4">
                            <div class="text-6xl font-black my-4" style="color: ${rec.action_color === 'green' ? '#10b981' : (rec.action_color === 'red' ? '#ef4444' : '#6b7280')}">
                                ${rec.title}
                            </div>
                            <p class="text-lg text-gray-200 mt-4">${rec.translatedDescription || rec.description}</p>
                        </div>
                        
                        <!-- Key Metrics -->
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                            <div class="bg-gray-900 bg-opacity-60 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${isArabic ? 'الاتجاه' : 'Direction'}</div>
                                <div class="text-xl font-bold ${forecast.direction === 'bullish' ? 'text-green-400' : (forecast.direction === 'bearish' ? 'text-red-400' : 'text-gray-400')}">
                                    ${isArabic ? 
                                        (forecast.direction === 'bullish' ? '📈 صاعد' : (forecast.direction === 'bearish' ? '📉 هابط' : '➡️ جانبي')) :
                                        ('📊 ' + forecast.direction.toUpperCase())
                                    }
                                </div>
                            </div>
                            
                            <div class="bg-gray-900 bg-opacity-60 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${isArabic ? 'الثقة' : 'Confidence'}</div>
                                <div class="text-xl font-bold text-blue-400">
                                    ${((forecast.confidence || 0) * 100).toFixed(1)}%
                                </div>
                            </div>
                            
                            <div class="bg-gray-900 bg-opacity-60 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${isArabic ? 'التغير المتوقع' : 'Expected Change'}</div>
                                <div class="text-xl font-bold ${forecast.expected_change > 0 ? 'text-green-400' : 'text-red-400'}">
                                    ${forecast.expected_change > 0 ? '+' : ''}${forecast.expected_change}%
                                </div>
                            </div>
                            
                            <div class="bg-gray-900 bg-opacity-60 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${isArabic ? 'الإطار الزمني' : 'Timeframe'}</div>
                                <div class="text-xl font-bold text-purple-400">
                                    ${forecast.timeframe[isArabic ? 'label_ar' : 'label_en']}
                                </div>
                            </div>
                        </div>
                `;
                
                // Risk Management
                if (rec.risk_management && rec.action !== 'WAIT' && forecast.current_price > 0) {
                    html += `
                        <div class="mt-6 bg-yellow-900 bg-opacity-30 border border-yellow-600 rounded-lg p-4">
                            <div class="flex items-center gap-2 mb-2">
                                <i class="fas fa-shield-alt text-yellow-400"></i>
                                <span class="font-bold text-yellow-300">${isArabic ? 'إدارة المخاطر' : 'Risk Management'}</span>
                            </div>
                            <div class="grid grid-cols-2 gap-3 text-sm">
                                <div>
                                    <span class="text-gray-400">${isArabic ? 'السعر الحالي:' : 'Current:'}</span>
                                    <span class="font-bold text-white ml-2">$${(forecast.current_price || 0).toFixed(2)}</span>
                                </div>
                                <div>
                                    <span class="text-gray-400">${isArabic ? 'الهدف:' : 'Target:'}</span>
                                    <span class="font-bold text-green-400 ml-2">$${rec.risk_management.target}</span>
                                </div>
                                <div class="col-span-2">
                                    <span class="text-gray-400">${isArabic ? 'وقف الخسارة:' : 'Stop Loss:'}</span>
                                    <span class="font-bold text-red-400 ml-2">$${rec.risk_management.stop_loss}</span>
                                </div>
                            </div>
                            <p class="text-xs text-gray-300 mt-2">${rec.risk_management.advice}</p>
                        </div>
                    `;
                } else if (rec.action === 'WAIT') {
                    // For WAIT action, show different message
                    html += `
                        <div class="mt-6 bg-gray-900 bg-opacity-30 border border-gray-600 rounded-lg p-4 text-center">
                            <i class="fas fa-pause-circle text-gray-400 text-3xl mb-2"></i>
                            <p class="text-gray-300">${isArabic ? 'لا يوجد توصية محددة في الوقت الحالي' : 'No specific trade recommendation at this time'}</p>
                            <p class="text-xs text-gray-400 mt-2">${isArabic ? 'راقب السوق وانتظر إشارات أقوى' : 'Monitor the market and wait for stronger signals'}</p>
                        </div>
                    `;
                }
                
                html += `</div>`; // Close main forecast div
                
                // Supporting Factors
                if (forecast.supporting_factors && forecast.supporting_factors.length > 0) {
                    html += `
                        <div class="bg-green-900 bg-opacity-20 border border-green-600 rounded-lg p-4">
                            <div class="font-bold text-green-300 mb-2 flex items-center gap-2">
                                <i class="fas fa-check-circle"></i>
                                <span>${isArabic ? 'عوامل داعمة' : 'Supporting Factors'}</span>
                            </div>
                            <ul class="text-sm space-y-1">
                                ${forecast.supporting_factors.slice(0, 5).map(f => `
                                    <li class="text-gray-300">• ${isArabic ? f.ar : f.en}</li>
                                `).join('')}
                            </ul>
                        </div>
                    `;
                }
                
                // Risk Factors
                if (forecast.risk_factors && forecast.risk_factors.length > 0) {
                    html += `
                        <div class="bg-red-900 bg-opacity-20 border border-red-600 rounded-lg p-4">
                            <div class="font-bold text-red-300 mb-2 flex items-center gap-2">
                                <i class="fas fa-exclamation-triangle"></i>
                                <span>${isArabic ? 'عوامل مخاطرة' : 'Risk Factors'}</span>
                            </div>
                            <ul class="text-sm space-y-1">
                                ${forecast.risk_factors.slice(0, 5).map(f => `
                                    <li class="text-gray-300">• ${isArabic ? f.ar : f.en}</li>
                                `).join('')}
                            </ul>
                        </div>
                    `;
                }
                
                // Score Breakdown
                html += `
                    <div class="bg-gray-900 bg-opacity-40 rounded-lg p-4">
                        <div class="font-bold text-gray-300 mb-3 text-center">${isArabic ? 'تفصيل النقاط' : 'Score Breakdown'}</div>
                        <div class="flex items-center justify-between gap-4">
                            <div class="flex-1">
                                <div class="text-xs text-green-400 mb-1">${isArabic ? 'نقاط الصعود' : 'Bullish Points'}</div>
                                <div class="h-6 bg-gray-700 rounded-full overflow-hidden">
                                    <div class="h-full bg-green-500" style="width: ${((forecast.bullish_points || 0) / (forecast.max_points || 1)) * 100}%"></div>
                                </div>
                                <div class="text-xs text-gray-400 mt-1">${(forecast.bullish_points || 0).toFixed(1)} / ${forecast.max_points || 100}</div>
                            </div>
                            <div class="text-2xl font-bold text-gray-400">VS</div>
                            <div class="flex-1">
                                <div class="text-xs text-red-400 mb-1">${isArabic ? 'نقاط الهبوط' : 'Bearish Points'}</div>
                                <div class="h-6 bg-gray-700 rounded-full overflow-hidden">
                                    <div class="h-full bg-red-500" style="width: ${((forecast.bearish_points || 0) / (forecast.max_points || 1)) * 100}%"></div>
                                </div>
                                <div class="text-xs text-gray-400 mt-1">${(forecast.bearish_points || 0).toFixed(1)} / ${forecast.max_points || 100}</div>
                            </div>
                        </div>
                    </div>
                `;
                
                container.innerHTML = html;
                
            } catch (error) {
                container.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-circle text-red-400 text-4xl mb-3"></i>
                        <p class="text-red-400 font-bold">${isArabic ? 'فشل التحميل' : 'Failed to load'}</p>
                        <p class="text-xs text-gray-400 mt-2">${error.message}</p>
                        <p class="text-xs text-gray-500 mt-3">${isArabic ? 'تأكد من تشغيل "تشغيل التحليل" أولاً' : 'Make sure to run "Run Analysis" first'}</p>
                    </div>
                `;
            }
        }
        
        // Auto-load market forecast on page load
        setTimeout(loadMarketForecast, 1500);
        
        // Price Chart Data
        const priceHistory = <?= json_encode(array_reverse($priceHistory)) ?>;
        
        // Initialize Price Chart
        const ctx = document.getElementById('priceChart').getContext('2d');
        const priceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: priceHistory.map(p => new Date(p.timestamp).toLocaleDateString()),
                datasets: [{
                    label: '<?= $selectedSymbol ?> Price',
                    data: priceHistory.map(p => p.close),
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: '#374151' }
                    },
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: '#374151' }
                    }
                }
            }
        });
        
        // ============================================
        // Phase 1 Enhancements - JavaScript Functions
        // ============================================
        
        // Define isRTL for JavaScript
        const isRTL = <?= json_encode($isRTL) ?>;
        
        // Translation helper function
        function t(enText, arText) {
            return isRTL ? arText : enText;
        }
        
        // Translate signal names
        function translateSignal(signal) {
            const translations = {
                'bullish': isRTL ? 'صاعد' : 'BULLISH',
                'bearish': isRTL ? 'هابط' : 'BEARISH',
                'neutral': isRTL ? 'محايد' : 'NEUTRAL',
                'strong_bullish': isRTL ? 'صاعد قوي' : 'STRONG BULLISH',
                'strong_bearish': isRTL ? 'هابط قوي' : 'STRONG BEARISH',
                'STRONG_BULLISH': isRTL ? 'صاعد قوي' : 'STRONG BULLISH',
                'STRONG_BEARISH': isRTL ? 'هابط قوي' : 'STRONG BEARISH',
                'BULLISH': isRTL ? 'صاعد' : 'BULLISH',
                'BEARISH': isRTL ? 'هابط' : 'BEARISH',
                'NEUTRAL': isRTL ? 'محايد' : 'NEUTRAL',
                'BUY': isRTL ? 'شراء' : 'BUY',
                'SELL': isRTL ? 'بيع' : 'SELL',
                'WAIT': isRTL ? 'انتظار' : 'WAIT',
                'HOLD': isRTL ? 'احتفاظ' : 'HOLD',
                'tight': isRTL ? 'ضيق' : 'tight',
                'wide': isRTL ? 'واسع' : 'wide',
                'normal': isRTL ? 'عادي' : 'normal',
                'buying': isRTL ? 'شراء' : 'buying',
                'selling': isRTL ? 'بيع' : 'selling',
                'strong': isRTL ? 'قوي' : 'strong',
                'moderate': isRTL ? 'متوسط' : 'moderate',
                'weak': isRTL ? 'ضعيف' : 'weak',
                'high': isRTL ? 'مرتفع' : 'high',
                'medium': isRTL ? 'متوسط' : 'medium',
                'low': isRTL ? 'منخفض' : 'low',
                'HIGH': isRTL ? 'مرتفع' : 'HIGH',
                'MEDIUM': isRTL ? 'متوسط' : 'MEDIUM',
                'LOW': isRTL ? 'منخفض' : 'LOW',
                'MEDIUM-HIGH': isRTL ? 'متوسط-مرتفع' : 'MEDIUM-HIGH',
                'short_term': isRTL ? 'قصير المدى' : 'short term',
                'medium_term': isRTL ? 'متوسط المدى' : 'medium term',
                'long_term': isRTL ? 'طويل المدى' : 'long term'
            };
            return translations[signal] || signal;
        }
        
        // Load Order Book Analysis
        async function loadOrderBookAnalysis() {
            const container = document.getElementById('orderbook-content');
            if (!container) return;
            
            container.innerHTML = `
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-400"></div>
                    <p class="text-gray-400 mt-2">${isRTL ? 'جارٍ التحليل...' : 'Loading...'}</p>
                </div>
            `;
            
            try {
                const response = await fetch('api/get_enhanced_analysis.php?symbol=BTC');
                const data = await response.json();
                
                if (data.success && data.analysis.order_book) {
                    const ob = data.analysis.order_book;
                    const signal = data.analysis.order_book_signal;
                    
                    const signalColor = signal.signal === 'bullish' ? 'green' : signal.signal === 'bearish' ? 'red' : 'gray';
                    const signalEmoji = signal.signal === 'bullish' ? '🟢' : signal.signal === 'bearish' ? '🔴' : '⚪';
                    
                    container.innerHTML = `
                        <div class="bg-${signalColor}-800 bg-opacity-40 rounded-lg p-4 text-center">
                            <div class="text-3xl font-bold text-${signalColor}-400">
                                ${signalEmoji} ${translateSignal(signal.signal)}
                            </div>
                            <div class="text-sm text-gray-300 mt-2">
                                ${t('Confidence', 'الثقة')}: <span class="font-bold">${(signal.confidence * 100).toFixed(1)}%</span>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400">${t('Spread', 'السبريد')}</span>
                                <span class="font-bold text-green-400">${translateSignal(ob.spread.signal)}</span>
                            </div>
                            <div class="text-sm text-gray-500 mt-1">${ob.spread.spread_pct}%</div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400">${t('Imbalance', 'التوازن')}</span>
                                <span class="font-bold ${ob.imbalance.imbalance_pct > 0 ? 'text-green-400' : 'text-red-400'}">
                                    ${ob.imbalance.imbalance_pct.toFixed(2)}%
                                </span>
                            </div>
                            <div class="text-sm text-gray-500 mt-1">${t('pressure', 'ضغط')}: ${translateSignal(ob.imbalance.pressure)}</div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="text-sm text-gray-400 mb-2">${t('Whale Walls', 'جدران الحيتان')}</div>
                            <div class="flex justify-between">
                                <div>
                                    <span class="text-green-400">🐋 ${t('Buy', 'شراء')}</span>
                                    <div class="font-bold text-xl">${ob.whale_walls.buy_walls_count}</div>
                                </div>
                                <div>
                                    <span class="text-red-400">🐋 ${t('Sell', 'بيع')}</span>
                                    <div class="font-bold text-xl">${ob.whale_walls.sell_walls_count}</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="text-sm text-gray-400 mb-2">${t('Market Depth', 'عمق السوق')}</div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-300">${t('Bid', 'الشراء')}: <span class="text-green-400">${ob.depth.bid_ratio}%</span></span>
                                <span class="text-gray-300">${t('Ask', 'البيع')}: <span class="text-red-400">${ob.depth.ask_ratio}%</span></span>
                            </div>
                        </div>
                    `;
                } else {
                    throw new Error('No data available');
                }
            } catch (error) {
                container.innerHTML = `
                    <div class="bg-red-900 bg-opacity-30 rounded-lg p-4 text-center">
                        <i class="fas fa-exclamation-triangle text-red-400 text-2xl"></i>
                        <p class="text-gray-300 mt-2">${isRTL ? 'فشل تحميل البيانات' : 'Failed to load data'}</p>
                    </div>
                `;
            }
        }
        
        // Load Social Media Analysis
        async function loadSocialMediaAnalysis() {
            const container = document.getElementById('social-media-content');
            if (!container) return;
            
            container.innerHTML = `
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
                    <p class="text-gray-400 mt-2">${isRTL ? 'جارٍ التحليل...' : 'Loading...'}</p>
                </div>
            `;
            
            try {
                const response = await fetch('api/get_enhanced_analysis.php?symbol=BTC');
                const data = await response.json();
                
                if (data.success && data.analysis.social_media) {
                    const sm = data.analysis.social_media;
                    const signal = data.analysis.social_media_signal;
                    
                    const signalColor = signal.signal === 'bullish' ? 'green' : signal.signal === 'bearish' ? 'red' : 'gray';
                    const signalEmoji = signal.signal === 'bullish' ? '🟢' : signal.signal === 'bearish' ? '🔴' : '⚪';
                    
                    container.innerHTML = `
                        <div class="bg-${signalColor}-800 bg-opacity-40 rounded-lg p-4 text-center">
                            <div class="text-3xl font-bold text-${signalColor}-400">
                                ${signalEmoji} ${translateSignal(signal.signal)}
                            </div>
                            <div class="text-sm text-gray-300 mt-2">
                                ${t('Confidence', 'الثقة')}: <span class="font-bold">${(signal.confidence * 100).toFixed(1)}%</span>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-400"><i class="fab fa-twitter text-blue-400"></i> Twitter</span>
                                <span class="font-bold text-${sm.twitter_sentiment.signal === 'bullish' ? 'green' : sm.twitter_sentiment.signal === 'bearish' ? 'red' : 'gray'}-400">
                                    ${translateSignal(sm.twitter_sentiment.signal)}
                                </span>
                            </div>
                            <div class="text-sm text-gray-500">
                                ${t('Positive', 'إيجابية')}: ${sm.twitter_sentiment.positive_pct}%
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <span class="text-gray-400">${t('FUD Detection', 'كشف FUD')}</span>
                                <span class="font-bold ${sm.fud_detection.fud_detected ? 'text-red-400' : 'text-green-400'}">
                                    ${sm.fud_detection.fud_detected ? '⚠️ ' + t('Detected', 'مكتشف') : '✅ ' + t('Clean', 'نظيف')}
                                </span>
                            </div>
                            ${sm.fud_detection.fud_detected ? `<div class="text-sm text-gray-500 mt-1">${t('Severity', 'الخطورة')}: ${translateSignal(sm.fud_detection.severity)}</div>` : ''}
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <span class="text-gray-400">${t('Viral', 'انتشار فيروسي')}</span>
                                <span class="font-bold ${sm.viral_signals.is_viral ? 'text-orange-400' : 'text-gray-400'}">
                                    ${sm.viral_signals.is_viral ? '🔥 ' + t('Yes', 'نعم') : t('No', 'لا')}
                                </span>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <span class="text-gray-400">${t('Influencer Mentions', 'إشارات المؤثرين')}</span>
                                <span class="font-bold text-purple-400">${sm.influencer_signals.mentions_count}</span>
                            </div>
                        </div>
                    `;
                } else {
                    throw new Error('No data available');
                }
            } catch (error) {
                container.innerHTML = `
                    <div class="bg-red-900 bg-opacity-30 rounded-lg p-4 text-center">
                        <i class="fas fa-exclamation-triangle text-red-400 text-2xl"></i>
                        <p class="text-gray-300 mt-2">${isRTL ? 'فشل تحميل البيانات' : 'Failed to load data'}</p>
                    </div>
                `;
            }
        }
        
        // Load Multi-Timeframe Analysis
        async function loadMultiTimeframeAnalysis() {
            const container = document.getElementById('multitimeframe-content');
            if (!container) return;
            
            container.innerHTML = `
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-orange-400"></div>
                    <p class="text-gray-400 mt-2">${isRTL ? 'جارٍ التحليل...' : 'Loading...'}</p>
                </div>
            `;
            
            try {
                const response = await fetch('api/get_enhanced_analysis.php?symbol=BTC');
                const data = await response.json();
                
                if (data.success && data.analysis.multi_timeframe) {
                    const mtf = data.analysis.multi_timeframe;
                    const confluence = mtf.confluence;
                    
                    const signalColor = confluence.signal === 'bullish' ? 'green' : confluence.signal === 'bearish' ? 'red' : 'gray';
                    const signalEmoji = confluence.signal === 'bullish' ? '🟢' : confluence.signal === 'bearish' ? '🔴' : '⚪';
                    
                    container.innerHTML = `
                        <div class="bg-${signalColor}-800 bg-opacity-40 rounded-lg p-4 text-center">
                            <div class="text-3xl font-bold text-${signalColor}-400">
                                ${signalEmoji} ${translateSignal(confluence.signal)}
                            </div>
                            <div class="text-sm text-gray-300 mt-2">
                                ${t('Confluence Strength', 'قوة التطابق')}: <span class="font-bold">${(confluence.strength * 100).toFixed(1)}%</span>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400">${t('Alignment', 'التوافق')}</span>
                                <span class="font-bold text-${confluence.alignment === 'strong' ? 'green' : confluence.alignment === 'moderate' ? 'yellow' : 'gray'}-400">
                                    ${translateSignal(confluence.alignment)}
                                </span>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="text-sm text-gray-400 mb-3">${t('Timeframe Breakdown', 'توزيع الأطر الزمنية')}</div>
                            <div class="flex justify-between">
                                <div class="text-center">
                                    <div class="text-green-400 text-2xl font-bold">${confluence.bullish_count}</div>
                                    <div class="text-xs text-gray-500">${t('Bullish', 'صاعدة')}</div>
                                </div>
                                <div class="text-center">
                                    <div class="text-red-400 text-2xl font-bold">${confluence.bearish_count}</div>
                                    <div class="text-xs text-gray-500">${t('Bearish', 'هابطة')}</div>
                                </div>
                                <div class="text-center">
                                    <div class="text-gray-400 text-2xl font-bold">${confluence.neutral_count}</div>
                                    <div class="text-xs text-gray-500">${t('Neutral', 'محايدة')}</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="text-sm text-gray-400 mb-2">${t('Overall Trend', 'الاتجاه العام')}</div>
                            <div class="grid grid-cols-3 gap-2 text-center text-xs">
                                <div>
                                    <div class="text-gray-500">${t('Short', 'قصير')}</div>
                                    <div class="font-bold ${mtf.overall_trend.short_term === 'bullish' ? 'text-green-400' : mtf.overall_trend.short_term === 'bearish' ? 'text-red-400' : 'text-gray-400'}">
                                        ${translateSignal(mtf.overall_trend.short_term)}
                                    </div>
                                </div>
                                <div>
                                    <div class="text-gray-500">${t('Medium', 'متوسط')}</div>
                                    <div class="font-bold ${mtf.overall_trend.medium_term === 'bullish' ? 'text-green-400' : mtf.overall_trend.medium_term === 'bearish' ? 'text-red-400' : 'text-gray-400'}">
                                        ${translateSignal(mtf.overall_trend.medium_term)}
                                    </div>
                                </div>
                                <div>
                                    <div class="text-gray-500">${t('Long', 'طويل')}</div>
                                    <div class="font-bold ${mtf.overall_trend.long_term === 'bullish' ? 'text-green-400' : mtf.overall_trend.long_term === 'bearish' ? 'text-red-400' : 'text-gray-400'}">
                                        ${translateSignal(mtf.overall_trend.long_term)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                } else {
                    throw new Error('No data available');
                }
            } catch (error) {
                container.innerHTML = `
                    <div class="bg-red-900 bg-opacity-30 rounded-lg p-4 text-center">
                        <i class="fas fa-exclamation-triangle text-red-400 text-2xl"></i>
                        <p class="text-gray-300 mt-2">${isRTL ? 'فشل تحميل البيانات' : 'Failed to load data'}</p>
                    </div>
                `;
            }
        }
        
        // Load Enhanced Overall Signal
        async function loadEnhancedAnalysis() {
            const container = document.getElementById('enhanced-signal-content');
            if (!container) return;
            
            container.innerHTML = `
                <div class="text-center py-4">
                    <div class="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-blue-400"></div>
                    <p class="text-gray-300 mt-2">${isRTL ? 'جارٍ التحليل الشامل...' : 'Loading comprehensive analysis...'}</p>
                </div>
            `;
            
            try {
                const response = await fetch('api/get_enhanced_analysis.php?symbol=BTC');
                const data = await response.json();
                
                if (data.success) {
                    const signal = data.overall_signal;
                    const recommendation = data.recommendation;
                    
                    let signalColor, signalBg, signalEmoji;
                    if (signal.signal === 'STRONG_BULLISH' || signal.signal === 'BULLISH') {
                        signalColor = 'text-green-400';
                        signalBg = 'bg-green-900';
                        signalEmoji = '🚀';
                    } else if (signal.signal === 'STRONG_BEARISH' || signal.signal === 'BEARISH') {
                        signalColor = 'text-red-400';
                        signalBg = 'bg-red-900';
                        signalEmoji = '⚠️';
                    } else {
                        signalColor = 'text-gray-400';
                        signalBg = 'bg-gray-900';
                        signalEmoji = '⏸️';
                    }
                    
                    // Translate description
                    let translatedDesc = recommendation.description;
                    if (isRTL) {
                        const descTranslations = {
                            'Strong bullish signals across all indicators. Good entry opportunity.': 'إشارات صعودية قوية عبر جميع المؤشرات. فرصة دخول جيدة.',
                            'Moderate bullish signals. Consider cautious entry.': 'إشارات صعودية معتدلة. فكر بدخول حذر.',
                            'Strong bearish signals. Consider exiting positions or shorting.': 'إشارات هبوطية قوية. فكر بالخروج أو البيع على المكشوف.',
                            'Moderate bearish signals. Reduce exposure or wait.': 'إشارات هبوطية معتدلة. قلّل التعرض أو انتظر.',
                            'No clear direction. Wait for stronger signals before entering positions.': 'لا يوجد اتجاه واضح. انتظر إشارات أقوى قبل الدخول.',
                            'Very strong buying opportunity detected. Multiple indicators align.': 'فرصة شراء قوية جداً. المؤشرات متطابقة.',
                            'Positive market sentiment with good entry potential.': 'معنويات السوق إيجابية مع إمكانية دخول جيدة.',
                            'Market is consolidating. No clear direction yet.': 'السوق في مرحلة تماسك. لا يوجد اتجاه واضح بعد.',
                            'Negative market sentiment. Consider reducing exposure.': 'معنويات السوق سلبية. فكر بتقليل التعرض.',
                            'Very strong selling pressure detected. High risk of decline.': 'ضغط بيع قوي جداً. خطر انخفاض مرتفع.'
                        };
                        translatedDesc = descTranslations[recommendation.description] || recommendation.description;
                    }
                    
                    container.innerHTML = `
                        <div class="${signalBg} bg-opacity-50 rounded-xl p-6 text-center border-2 border-current ${signalColor}">
                            <div class="text-5xl mb-3">${signalEmoji}</div>
                            <div class="text-3xl font-bold ${signalColor} mb-2">
                                ${translateSignal(signal.signal)}
                            </div>
                            <div class="text-lg text-gray-300">
                                ${t('Confidence', 'الثقة')}: <span class="font-bold">${(signal.confidence * 100).toFixed(1)}%</span>
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 rounded-lg p-4">
                            <div class="text-center mb-3">
                                <span class="text-2xl font-bold ${recommendation.action === 'BUY' ? 'text-green-400' : recommendation.action === 'SELL' ? 'text-red-400' : 'text-gray-400'}">
                                    ${translateSignal(recommendation.action)}
                                </span>
                            </div>
                            <p class="text-sm text-gray-300 text-center">${translatedDesc}</p>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-3">
                            <div class="bg-gray-800 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${t('Risk Level', 'مستوى المخاطرة')}</div>
                                <div class="font-bold ${recommendation.risk_level === 'LOW' ? 'text-green-400' : recommendation.risk_level === 'HIGH' ? 'text-red-400' : 'text-yellow-400'}">
                                    ${translateSignal(recommendation.risk_level)}
                                </div>
                            </div>
                            
                            <div class="bg-gray-800 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${t('Position Size', 'حجم المركز')}</div>
                                <div class="font-bold text-blue-400">${recommendation.suggested_position_size}</div>
                            </div>
                            
                            <div class="bg-gray-800 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${t('Stop Loss', 'وقف الخسارة')}</div>
                                <div class="font-bold text-red-400">${recommendation.stop_loss_pct}%</div>
                            </div>
                            
                            <div class="bg-gray-800 rounded-lg p-3 text-center">
                                <div class="text-xs text-gray-400 mb-1">${t('Take Profit', 'جني الأرباح')}</div>
                                <div class="font-bold text-green-400">+${recommendation.take_profit_pct}%</div>
                            </div>
                        </div>
                    `;
                    
                    // Also update other sections
                    loadOrderBookAnalysis();
                    loadSocialMediaAnalysis();
                    loadMultiTimeframeAnalysis();
                    
                } else {
                    throw new Error(data.error || 'Failed to load analysis');
                }
            } catch (error) {
                container.innerHTML = `
                    <div class="bg-red-900 bg-opacity-30 rounded-lg p-6 text-center">
                        <i class="fas fa-exclamation-triangle text-red-400 text-3xl mb-3"></i>
                        <p class="text-gray-300 mb-2">${isRTL ? 'فشل تحميل التحليل' : 'Failed to load analysis'}</p>
                        <p class="text-sm text-gray-400">${error.message}</p>
                    </div>
                `;
            }
        }
        
        // Auto-load Enhanced Analysis on page load
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                loadEnhancedAnalysis();
            }, 2000); // Load after 2 seconds
        });
    </script>
</body>
</html>

