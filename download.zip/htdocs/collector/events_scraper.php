<?php
/**
 * Events Scraper - Fetch Real Upcoming Events
 * Sources: CoinMarketCal, CryptoCompare Events, Economic Calendar
 */

require_once __DIR__ . '/../config/database.php';

class EventsScraper {
    
    /**
     * Fetch events from CoinMarketCal API
     */
    public function fetchFromCoinMarketCal() {
        $events = [];
        
        // CoinMarketCal Public API (no key needed for basic data)
        $url = "https://api.coinmarketcal.com/v1/events";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);
        
        if ($response) {
            $data = json_decode($response, true);
            if ($data && isset($data['body'])) {
                foreach ($data['body'] as $event) {
                    $events[] = [
                        'title' => $event['title']['en'] ?? 'Event',
                        'description' => $event['description']['en'] ?? '',
                        'date' => $event['date_event'] ?? null,
                        'type' => $this->categorizeEventType($event['title']['en'] ?? ''),
                        'importance' => 'medium',
                        'source' => 'CoinMarketCal'
                    ];
                }
            }
        }
        
        return $events;
    }
    
    /**
     * Fetch critical market decisions and events
     */
    public function fetchCriticalDecisions() {
        $events = [];
        
        // 1. Economic & Central Bank Decisions
        $economicEvents = [
            [
                'title' => 'US Federal Reserve FOMC Meeting - Interest Rate Decision',
                'description' => 'قرار اللجنة الفيدرالية للسوق المفتوحة بشأن أسعار الفائدة - يؤثر بشدة على الأسواق',
                'type' => 'fed_decision',
                'importance' => 'critical',
                'impact' => 'mixed',
                'frequency' => '+6 weeks'
            ],
            [
                'title' => 'US CPI Inflation Data Release',
                'description' => 'بيانات التضخم الأمريكية - مؤشر أسعار المستهلك الشهري',
                'type' => 'cpi_data',
                'importance' => 'critical',
                'impact' => 'mixed',
                'frequency' => '+1 month'
            ],
            [
                'title' => 'US Non-Farm Payrolls (NFP)',
                'description' => 'بيانات الوظائف الأمريكية الشهرية - تؤثر على قرارات الفيدرالي',
                'type' => 'other',
                'importance' => 'high',
                'impact' => 'mixed',
                'frequency' => '+1 month'
            ],
            [
                'title' => 'European Central Bank (ECB) Meeting',
                'description' => 'اجتماع البنك المركزي الأوروبي - قرارات السياسة النقدية',
                'type' => 'fed_decision',
                'importance' => 'high',
                'impact' => 'mixed',
                'frequency' => '+6 weeks'
            ]
        ];
        
        foreach ($economicEvents as $event) {
            $existing = fetchOne(
                "SELECT id FROM upcoming_events WHERE event_title = ? AND event_date > NOW() LIMIT 1",
                [$event['title']]
            );
            
            if (!$existing) {
                $events[] = [
                    'title' => $event['title'],
                    'description' => $event['description'],
                    'date' => date('Y-m-d H:i:s', strtotime($event['frequency'])),
                    'type' => $event['type'],
                    'importance' => $event['importance'],
                    'impact' => $event['impact'],
                    'source' => 'Economic Calendar'
                ];
            }
        }
        
        return $events;
    }
    
    /**
     * Extract regulatory and policy decisions from news
     */
    public function extractRegulatoryDecisions() {
        $events = [];
        
        // Keywords for different decision types
        $decisionPatterns = [
            // Regulatory & Legal
            'regulation' => [
                'keywords' => ['sec approval', 'sec decision', 'regulatory approval', 'regulation', 'ban crypto', 
                               'legal framework', 'compliance', 'license', 'sec lawsuit', 'regulatory clarity'],
                'type' => 'regulation',
                'importance' => 'critical'
            ],
            // Exchange Listings
            'listing' => [
                'keywords' => ['binance listing', 'coinbase listing', 'new listing', 'delist', 'trading pair'],
                'type' => 'other',
                'importance' => 'high'
            ],
            // Government Decisions
            'government' => [
                'keywords' => ['government approval', 'legal tender', 'crypto tax', 'mining ban', 
                               'cbdc launch', 'central bank digital', 'el salvador', 'country adopt'],
                'type' => 'regulation',
                'importance' => 'critical'
            ],
            // Corporate Decisions
            'corporate' => [
                'keywords' => ['tesla buys', 'microstrategy', 'paypal accepts', 'visa crypto', 
                               'mastercard', 'blackrock', 'institutional investment', 'corporate treasury'],
                'type' => 'other',
                'importance' => 'high'
            ],
            // Technical Decisions
            'technical' => [
                'keywords' => ['hard fork', 'network upgrade', 'merge', 'burn tokens', 'dao vote',
                               'governance proposal', 'protocol update'],
                'type' => 'upgrade',
                'importance' => 'medium'
            ]
        ];
        
        // Get recent news
        $sql = "SELECT id, title, summary, date, sentiment FROM news_events 
                WHERE date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                ORDER BY date DESC LIMIT 100";
        
        $newsArticles = fetchAll($sql);
        
        foreach ($newsArticles as $news) {
            $text = strtolower($news['title'] . ' ' . $news['summary']);
            
            foreach ($decisionPatterns as $category => $pattern) {
                foreach ($pattern['keywords'] as $keyword) {
                    if (strpos($text, $keyword) !== false) {
                        
                        // Try to extract date from news
                        $eventDate = $this->extractFutureDate($text, $news['date']);
                        
                        if ($eventDate) {
                            // Determine impact based on sentiment
                            $impact = 'neutral';
                            if ($news['sentiment'] === 'positive') $impact = 'bullish';
                            elseif ($news['sentiment'] === 'negative') $impact = 'bearish';
                            
                            $events[] = [
                                'title' => $news['title'],
                                'description' => substr($news['summary'], 0, 200),
                                'date' => $eventDate,
                                'type' => $pattern['type'],
                                'importance' => $pattern['importance'],
                                'impact' => $impact,
                                'source' => 'News Analysis: ' . ucfirst($category)
                            ];
                            break 2;
                        }
                    }
                }
            }
        }
        
        return $events;
    }
    
    /**
     * Extract events from news articles
     */
    public function extractEventsFromNews() {
        $events = [];
        
        // Get recent news
        $sql = "SELECT title, summary, date FROM news_events 
                WHERE date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                ORDER BY date DESC LIMIT 50";
        
        $newsArticles = fetchAll($sql);
        
        // Keywords for event detection
        $eventKeywords = [
            'upgrade' => ['upgrade', 'fork', 'hardfork', 'merge', 'update'],
            'conference' => ['conference', 'summit', 'event', 'meetup'],
            'halving' => ['halving', 'halvening'],
            'earnings' => ['earnings', 'quarterly report'],
            'regulation' => ['sec decision', 'approval', 'regulation decision']
        ];
        
        foreach ($newsArticles as $news) {
            $text = strtolower($news['title'] . ' ' . $news['summary']);
            
            // Check for date mentions (simplified)
            if (preg_match('/\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}\b/i', $text, $matches)) {
                
                foreach ($eventKeywords as $type => $keywords) {
                    foreach ($keywords as $keyword) {
                        if (strpos($text, $keyword) !== false) {
                            // Found potential event
                            $events[] = [
                                'title' => $news['title'],
                                'description' => substr($news['summary'], 0, 200),
                                'date' => $this->extractDate($text),
                                'type' => $type,
                                'importance' => 'medium',
                                'impact' => 'neutral',
                                'source' => 'News Analysis'
                            ];
                            break 2;
                        }
                    }
                }
            }
        }
        
        return $events;
    }
    
    /**
     * Save events to database with auto-translation
     */
    public function saveEvents($events) {
        $saved = 0;
        $needsTranslation = [];
        
        foreach ($events as $event) {
            if (!isset($event['date']) || !$event['date']) continue;
            
            // Check if event already exists
            $existing = fetchOne(
                "SELECT id FROM upcoming_events 
                 WHERE event_title = ? AND ABS(TIMESTAMPDIFF(HOUR, event_date, ?)) < 24",
                [$event['title'], $event['date']]
            );
            
            if ($existing) continue;
            
            try {
                $sql = "INSERT INTO upcoming_events 
                        (event_title, event_description, event_type, event_date, importance, expected_impact, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                executeQuery($sql, [
                    $event['title'],
                    $event['description'] ?? '',
                    $event['type'] ?? 'other',
                    $event['date'],
                    $event['importance'] ?? 'medium',
                    $event['impact'] ?? 'neutral',
                    $event['source'] ?? 'Unknown'
                ]);
                
                // Get the inserted ID for translation
                $eventId = getDatabaseConnection()->lastInsertId();
                if ($eventId) {
                    $needsTranslation[] = $eventId;
                }
                
                $saved++;
            } catch (Exception $e) {
                // Skip duplicates
            }
        }
        
        // Auto-translate new events (simple & fast)
        if (!empty($needsTranslation) && file_exists(__DIR__ . '/../modules/simple_translator.php')) {
            require_once __DIR__ . '/../modules/simple_translator.php';
            try {
                SimpleTranslator::autoTranslateEvents();
            } catch (Exception $e) {
                // Silent fail
            }
        }
        
        return $saved;
    }
    
    /**
     * Mark passed events
     */
    public function markPassedEvents() {
        $sql = "UPDATE upcoming_events 
                SET is_passed = TRUE 
                WHERE event_date < NOW() AND is_passed = FALSE";
        
        executeQuery($sql);
    }
    
    /**
     * Categorize event type
     */
    private function categorizeEventType($text) {
        $text = strtolower($text);
        
        if (strpos($text, 'upgrade') !== false || strpos($text, 'fork') !== false) return 'upgrade';
        if (strpos($text, 'halving') !== false) return 'halving';
        if (strpos($text, 'conference') !== false || strpos($text, 'summit') !== false) return 'conference';
        if (strpos($text, 'sec') !== false || strpos($text, 'regulation') !== false) return 'regulation';
        if (strpos($text, 'fed') !== false || strpos($text, 'fomc') !== false) return 'fed_decision';
        if (strpos($text, 'cpi') !== false || strpos($text, 'inflation') !== false) return 'cpi_data';
        
        return 'other';
    }
    
    /**
     * Extract date from text (simplified)
     */
    private function extractDate($text) {
        // Try to find date pattern
        if (preg_match('/\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2}),?\s+(\d{4})?\b/i', $text, $matches)) {
            $month = $matches[1];
            $day = $matches[2];
            $year = isset($matches[3]) ? $matches[3] : date('Y');
            
            return date('Y-m-d H:i:s', strtotime("$month $day, $year"));
        }
        
        // Default to 30 days from now
        return date('Y-m-d H:i:s', strtotime('+30 days'));
    }
    
    /**
     * Extract future date from text (advanced)
     */
    private function extractFutureDate($text, $fallbackDate) {
        $now = time();
        
        // Patterns for date extraction
        $patterns = [
            '/(\d{4})-(\d{2})-(\d{2})/' => function($m) {
                return strtotime("{$m[1]}-{$m[2]}-{$m[3]}");
            },
            '/(\d{1,2})\s+(january|february|march|april|may|june|july|august|september|october|november|december)/i' => function($m) {
                return strtotime("{$m[1]} {$m[2]} " . date('Y'));
            },
            '/next\s+week/i' => function($m) {
                return strtotime('+1 week');
            },
            '/next\s+month/i' => function($m) {
                return strtotime('+1 month');
            },
            '/in\s+(\d+)\s+(day|week|month)s?/i' => function($m) {
                return strtotime("+{$m[1]} {$m[2]}");
            },
            '/coming\s+week/i' => function($m) {
                return strtotime('+1 week');
            },
            '/this\s+month/i' => function($m) {
                return strtotime('+2 weeks');
            }
        ];
        
        foreach ($patterns as $pattern => $callback) {
            if (preg_match($pattern, $text, $matches)) {
                $timestamp = $callback($matches);
                if ($timestamp > $now) {
                    return date('Y-m-d H:i:s', $timestamp);
                }
            }
        }
        
        // If no future date found, default to 1 week from fallback
        $timestamp = strtotime($fallbackDate . ' +1 week');
        if ($timestamp > $now) {
            return date('Y-m-d H:i:s', $timestamp);
        }
        
        return null;
    }
    
    /**
     * Run complete scraping process
     */
    public function run() {
        echo "=== مجمع الأحداث المؤثرة على السوق ===\n";
        echo "=== Market Decision Collector ===\n\n";
        
        $allEvents = [];
        $breakdown = [
            'api' => 0,
            'critical_decisions' => 0,
            'regulatory' => 0,
            'news' => 0
        ];
        
        // 1. Fetch from CoinMarketCal API
        echo "📡 جلب الأحداث من CoinMarketCal...\n";
        echo "📡 Fetching from CoinMarketCal API...\n";
        $apiEvents = $this->fetchFromCoinMarketCal();
        echo "✅ وجد " . count($apiEvents) . " حدث\n";
        echo "✅ Found " . count($apiEvents) . " events\n\n";
        $allEvents = array_merge($allEvents, $apiEvents);
        $breakdown['api'] = count($apiEvents);
        
        // 2. Critical Economic & Central Bank Decisions
        echo "🏦 جلب القرارات الاقتصادية والبنوك المركزية...\n";
        echo "🏦 Fetching critical economic & central bank decisions...\n";
        $criticalEvents = $this->fetchCriticalDecisions();
        echo "✅ أضيف " . count($criticalEvents) . " قرار حرج\n";
        echo "✅ Added " . count($criticalEvents) . " critical decisions\n\n";
        $allEvents = array_merge($allEvents, $criticalEvents);
        $breakdown['critical_decisions'] = count($criticalEvents);
        
        // 3. Extract Regulatory & Policy Decisions from News
        echo "⚖️ تحليل القرارات التنظيمية والحكومية من الأخبار...\n";
        echo "⚖️ Extracting regulatory & policy decisions from news...\n";
        $regulatoryEvents = $this->extractRegulatoryDecisions();
        echo "✅ وجد " . count($regulatoryEvents) . " قرار تنظيمي/سياسي\n";
        echo "✅ Found " . count($regulatoryEvents) . " regulatory/policy decisions\n\n";
        $allEvents = array_merge($allEvents, $regulatoryEvents);
        $breakdown['regulatory'] = count($regulatoryEvents);
        
        // 4. Extract General Events from News
        echo "📰 استخراج الأحداث من الأخبار...\n";
        echo "📰 Extracting general events from news...\n";
        $newsEvents = $this->extractEventsFromNews();
        echo "✅ وجد " . count($newsEvents) . " حدث من الأخبار\n";
        echo "✅ Found " . count($newsEvents) . " events from news\n\n";
        $allEvents = array_merge($allEvents, $newsEvents);
        $breakdown['news'] = count($newsEvents);
        
        // 5. Remove duplicates
        echo "🔄 إزالة التكرار...\n";
        echo "🔄 Removing duplicates...\n";
        $uniqueEvents = [];
        $titles = [];
        foreach ($allEvents as $event) {
            $titleKey = strtolower(trim($event['title']));
            if (!in_array($titleKey, $titles)) {
                $uniqueEvents[] = $event;
                $titles[] = $titleKey;
            }
        }
        echo "✅ " . (count($allEvents) - count($uniqueEvents)) . " تكرارات تم إزالتها\n";
        echo "✅ " . (count($allEvents) - count($uniqueEvents)) . " duplicates removed\n\n";
        
        // 6. Save to database
        echo "💾 حفظ الأحداث في قاعدة البيانات...\n";
        echo "💾 Saving events to database...\n";
        $saved = $this->saveEvents($uniqueEvents);
        echo "✅ تم حفظ {$saved} حدث جديد\n";
        echo "✅ Saved {$saved} new events\n\n";
        
        // 7. Mark passed events
        echo "🕒 تحديث الأحداث المنتهية...\n";
        echo "🕒 Updating passed events...\n";
        $this->markPassedEvents();
        echo "✅ تم تحديث الأحداث المنتهية\n";
        echo "✅ Passed events updated\n\n";
        
        return [
            'total_found' => count($uniqueEvents),
            'saved' => $saved,
            'breakdown' => $breakdown
        ];
    }
    
    /**
     * Static method for API calls
     */
    public static function fetchAndStoreEvents() {
        $scraper = new self();
        return $scraper->run();
    }
}

// CLI Execution
if (php_sapi_name() === 'cli' || !empty($_GET['run'])) {
    if (php_sapi_name() !== 'cli') {
        header('Content-Type: text/plain; charset=utf-8');
    }
    
    $scraper = new EventsScraper();
    $result = $scraper->run();
    
    echo "\n=== الملخص / Summary ===\n";
    echo "إجمالي الأحداث: {$result['total_found']}\n";
    echo "Total events found: {$result['total_found']}\n";
    echo "الأحداث المحفوظة: {$result['saved']}\n";
    echo "New events saved: {$result['saved']}\n\n";
    
    echo "=== التفصيل / Breakdown ===\n";
    echo "📡 API Events: {$result['breakdown']['api']}\n";
    echo "🏦 Critical Decisions: {$result['breakdown']['critical_decisions']}\n";
    echo "⚖️ Regulatory Decisions: {$result['breakdown']['regulatory']}\n";
    echo "📰 News Events: {$result['breakdown']['news']}\n";
}
?>

