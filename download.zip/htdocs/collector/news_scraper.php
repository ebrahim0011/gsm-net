<?php
/**
 * Enhanced News Scraper Module
 * 
 * Scrapes REAL cryptocurrency news from BEST sources (NO API):
 * - Cointelegraph (RSS + Scraping)
 * - Coindesk (RSS + Scraping)
 * - Bitcoin.com (RSS)
 * - CryptoSlate (RSS)
 * - Decrypt (RSS)
 * - The Block (RSS)
 * - CoinMarketCap News (RSS)
 * - CryptoPanic (Public Feed)
 * - Reddit Crypto (RSS)
 * 
 * Multi-source approach with fallback mechanisms
 */

require_once __DIR__ . '/../config/database.php';

class NewsScraper {
    
    // Silent mode (no console output) - for API calls
    private $silent = false;
    
    // Professional-grade news sources (Priority: 1 = Critical, 2 = Important, 3 = Supplementary)
    private $sources = [
        // TIER 1: Institutional & Professional Sources (Most trusted by analysts & traders)
        'cointelegraph_markets' => [
            'rss' => 'https://cointelegraph.com/rss/tag/markets',
            'url' => 'https://cointelegraph.com/tags/markets',
            'priority' => 1,
            'credibility' => 9.5,
            'impact_level' => 'high',
            'description' => 'Cointelegraph Markets - Professional market analysis'
        ],
        'coindesk_markets' => [
            'rss' => 'https://www.coindesk.com/arc/outboundfeeds/rss/',
            'url' => 'https://www.coindesk.com/markets/',
            'priority' => 1,
            'credibility' => 9.8,
            'impact_level' => 'high',
            'description' => 'CoinDesk - Leading crypto news (owned by Bullish)'
        ],
        'theblock' => [
            'rss' => 'https://www.theblock.co/rss.xml',
            'url' => 'https://www.theblock.co/',
            'priority' => 1,
            'credibility' => 9.7,
            'impact_level' => 'high',
            'description' => 'The Block - Institutional-grade research & news'
        ],
        'decrypt' => [
            'rss' => 'https://decrypt.co/feed',
            'url' => 'https://decrypt.co/news',
            'priority' => 1,
            'credibility' => 9.0,
            'impact_level' => 'high',
            'description' => 'Decrypt - High-quality crypto journalism'
        ],
        'cryptoslate' => [
            'rss' => 'https://cryptoslate.com/feed/',
            'url' => 'https://cryptoslate.com/news/',
            'priority' => 1,
            'credibility' => 8.8,
            'impact_level' => 'high',
            'description' => 'CryptoSlate - Data-driven crypto news'
        ],
        
        // TIER 2: Market Analysis & On-chain Data
        'bitcoinist' => [
            'rss' => 'https://bitcoinist.com/feed/',
            'url' => 'https://bitcoinist.com/',
            'priority' => 2,
            'credibility' => 8.5,
            'impact_level' => 'medium',
            'description' => 'Bitcoinist - Bitcoin & crypto news'
        ],
        'newsbtc' => [
            'rss' => 'https://www.newsbtc.com/feed/',
            'url' => 'https://www.newsbtc.com/',
            'priority' => 2,
            'credibility' => 8.3,
            'impact_level' => 'medium',
            'description' => 'NewsBTC - Technical analysis & market news'
        ],
        'bitcoin_magazine' => [
            'rss' => 'https://bitcoinmagazine.com/.rss/full/',
            'url' => 'https://bitcoinmagazine.com/',
            'priority' => 2,
            'credibility' => 9.0,
            'impact_level' => 'medium',
            'description' => 'Bitcoin Magazine - Oldest Bitcoin publication'
        ],
        'crypto_briefing' => [
            'rss' => 'https://cryptobriefing.com/feed/',
            'url' => 'https://cryptobriefing.com/',
            'priority' => 2,
            'credibility' => 8.7,
            'impact_level' => 'medium',
            'description' => 'Crypto Briefing - Research & analysis'
        ],
        
        // TIER 3: Community & Real-time Sentiment
        'coinmarketcap' => [
            'rss' => 'https://coinmarketcap.com/headlines/rss/',
            'url' => 'https://coinmarketcap.com/headlines/',
            'priority' => 3,
            'credibility' => 8.0,
            'impact_level' => 'medium',
            'description' => 'CoinMarketCap - Aggregated crypto news'
        ],
        'coingecko_news' => [
            'rss' => 'https://www.coingecko.com/en/news/rss',
            'url' => 'https://www.coingecko.com/en/news',
            'priority' => 3,
            'credibility' => 7.8,
            'impact_level' => 'low',
            'description' => 'CoinGecko - Market data & news aggregation'
        ],
        
        // Traditional Finance Crypto Coverage (Highly Trusted)
        'reuters_crypto' => [
            'rss' => 'https://www.reuters.com/technology/crypto-currency',
            'url' => 'https://www.reuters.com/technology/crypto-currency/',
            'priority' => 1,
            'credibility' => 10.0,
            'impact_level' => 'critical',
            'description' => 'Reuters - Major financial news agency'
        ],
        'bloomberg_crypto' => [
            'rss' => 'https://www.bloomberg.com/crypto',
            'url' => 'https://www.bloomberg.com/crypto',
            'priority' => 1,
            'credibility' => 10.0,
            'impact_level' => 'critical',
            'description' => 'Bloomberg - Premier financial & market data'
        ]
    ];
    
    /**
     * Enable/Disable console output
     */
    public function setSilentMode($silent = true) {
        $this->silent = $silent;
    }
    
    /**
     * Output helper - only print if not in silent mode
     */
    private function output($message) {
        if (!$this->silent) {
            echo $message;
        }
    }
    
    /**
     * Fetch news from all sources with priority (Professional-grade sources only)
     */
    public function fetchAllNews() {
        $this->output("════════════════════════════════════════════════════\n");
        $this->output("  🔥 FETCHING PRO-GRADE CRYPTO NEWS\n");
        $this->output("════════════════════════════════════════════════════\n\n");
        
        $allNews = [];
        $totalFetched = 0;
        $successCount = 0;
        $criticalNews = 0;
        $highImpact = 0;
        
        // Sort sources by priority (1 = highest)
        uasort($this->sources, function($a, $b) {
            // Sort by priority first, then by credibility
            if ($a['priority'] == $b['priority']) {
                return $b['credibility'] <=> $a['credibility'];
            }
            return $a['priority'] <=> $b['priority'];
        });
        
        foreach ($this->sources as $sourceName => $sourceData) {
            $credScore = $sourceData['credibility'];
            $impact = strtoupper($sourceData['impact_level']);
            $priority = $sourceData['priority'];
            
            $this->output("📰 {$sourceName}\n");
            $this->output("   Priority: {$priority} | Credibility: {$credScore}/10 | Impact: {$impact}\n");
            
            try {
                // Fetch RSS feed with source metadata
                $rssNews = $this->fetchRSSFeed(
                    $sourceData['rss'], 
                    $sourceName, 
                    $credScore, 
                    $sourceData['impact_level']
                );
                
                if (!empty($rssNews)) {
                    $allNews = array_merge($allNews, $rssNews);
                    $count = count($rssNews);
                    $totalFetched += $count;
                    $successCount++;
                    
                    // Count critical and high-impact news
                    if ($sourceData['impact_level'] === 'critical') {
                        $criticalNews += $count;
                    } elseif ($sourceData['impact_level'] === 'high') {
                        $highImpact += $count;
                    }
                    
                    $this->output("   ✅ Fetched {$count} articles\n\n");
                } else {
                    $this->output("   ⚠️ No articles fetched\n\n");
                }
                
            } catch (Exception $e) {
                $this->output("   ❌ Error: " . $e->getMessage() . "\n\n");
            }
            
            // Sleep to avoid rate limiting (be respectful to servers)
            sleep(1);
        }
        
        $this->output("════════════════════════════════════════════════════\n");
        $this->output("📊 SUMMARY:\n");
        $this->output("════════════════════════════════════════════════════\n");
        $this->output("  Sources Tried:      " . count($this->sources) . "\n");
        $this->output("  ✅ Successful:      {$successCount}\n");
        $this->output("  📰 Total Articles:  {$totalFetched}\n");
        $this->output("  🔴 Critical Impact: {$criticalNews}\n");
        $this->output("  🟠 High Impact:     {$highImpact}\n");
        
        // Remove duplicates based on link
        $uniqueNews = $this->removeDuplicates($allNews);
        $this->output("  ✨ Unique Articles: " . count($uniqueNews) . "\n");
        
        // Filter market-moving news (credibility >= 8.5)
        $marketMovingNews = array_filter($uniqueNews, function($article) {
            return isset($article['credibility']) && $article['credibility'] >= 8.5;
        });
        $this->output("  🎯 Market-Moving:   " . count($marketMovingNews) . " (Credibility ≥ 8.5)\n");
        
        // Save to database
        $saved = $this->saveNewsToDatabase($uniqueNews);
        $this->output("  💾 Saved to DB:     {$saved}\n");
        $this->output("════════════════════════════════════════════════════\n\n");
        
        return $uniqueNews;
    }
    
    /**
     * Remove duplicate news based on link
     */
    private function removeDuplicates($newsArray) {
        $seen = [];
        $unique = [];
        
        foreach ($newsArray as $article) {
            $link = $article['link'];
            if (!isset($seen[$link])) {
                $seen[$link] = true;
                $unique[] = $article;
            }
        }
        
        return $unique;
    }
    
    /**
     * Enhanced RSS feed fetcher with source credibility tracking
     */
    private function fetchRSSFeed($url, $source, $credibility = 8.0, $impactLevel = 'medium') {
        $news = [];
        
        try {
            $context = stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'timeout' => 20,
                    'follow_location' => 1,
                    'max_redirects' => 3
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ]);
            
            $content = @file_get_contents($url, false, $context);
            
            if ($content === false) {
                return $news;
            }
            
            // Parse XML with error suppression
            libxml_use_internal_errors(true);
            $xml = simplexml_load_string($content);
            libxml_clear_errors();
            
            if ($xml === false) {
                return $news;
            }
            
            // Try standard RSS/Atom format
            $items = [];
            
            // Standard RSS 2.0
            if (isset($xml->channel->item)) {
                $items = $xml->channel->item;
            }
            // Atom feed
            elseif (isset($xml->entry)) {
                $items = $xml->entry;
            }
            // Alternative RSS structure
            elseif (isset($xml->item)) {
                $items = $xml->item;
            }
            
            foreach ($items as $item) {
                // Extract title (different formats)
                $title = (string)($item->title ?? $item->children('http://www.w3.org/2005/Atom')->title ?? '');
                
                if (empty($title)) {
                    continue;
                }
                
                // Extract link (different formats)
                $link = (string)($item->link ?? '');
                if (empty($link) && isset($item->children('http://www.w3.org/2005/Atom')->link)) {
                    $link = (string)$item->children('http://www.w3.org/2005/Atom')->link['href'];
                }
                
                // Extract description/content
                $description = (string)($item->description ?? $item->summary ?? $item->content ?? '');
                if (isset($item->children('http://purl.org/rss/1.0/modules/content/')->encoded)) {
                    $description = (string)$item->children('http://purl.org/rss/1.0/modules/content/')->encoded;
                }
                
                // Clean description
                $summary = strip_tags($description);
                $summary = html_entity_decode($summary, ENT_QUOTES, 'UTF-8');
                $summary = preg_replace('/\s+/', ' ', $summary);
                $summary = trim(substr($summary, 0, 500));
                
                // Extract date (different formats)
                $pubDate = (string)($item->pubDate ?? $item->published ?? $item->updated ?? date('r'));
                
                // Parse date
                $timestamp = strtotime($pubDate);
                if ($timestamp === false) {
                    $timestamp = time();
                }
                $date = date('Y-m-d H:i:s', $timestamp);
                
                // Only add if we have title and link
                if (!empty($title) && !empty($link)) {
                    $news[] = [
                        'title' => trim($title),
                        'link' => trim($link),
                        'summary' => $summary,
                        'content' => $summary,
                        'source' => $source,
                        'date' => $date,
                        'credibility' => $credibility,      // Source credibility score (0-10)
                        'impact_level' => $impactLevel      // critical/high/medium/low
                    ];
                }
            }
            
        } catch (Exception $e) {
            // Silent fail - will try next source
        }
        
        return $news;
    }
    
    /**
     * Scrape article content from URL
     */
    public function scrapeArticleContent($url) {
        try {
            $context = stream_context_create([
                'http' => [
                    'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'timeout' => 10
                ]
            ]);
            
            $html = @file_get_contents($url, false, $context);
            
            if ($html === false) {
                return '';
            }
            
            // Extract text content (simple approach)
            $text = strip_tags($html);
            $text = preg_replace('/\s+/', ' ', $text);
            $text = trim($text);
            
            return $text;
            
        } catch (Exception $e) {
            return '';
        }
    }
    
    /**
     * Save news to database with credibility tracking and auto-translation
     */
    private function saveNewsToDatabase($newsArray) {
        $saved = 0;
        $needsTranslation = [];
        
        foreach ($newsArray as $article) {
            try {
                $sql = "INSERT INTO news_events 
                        (title, summary, content, link, source, date, credibility, impact_level) 
                        VALUES 
                        (:title, :summary, :content, :link, :source, :date, :credibility, :impact_level)
                        ON DUPLICATE KEY UPDATE 
                        title = VALUES(title),
                        summary = VALUES(summary),
                        content = VALUES(content),
                        credibility = VALUES(credibility),
                        impact_level = VALUES(impact_level)";
                
                executeQuery($sql, [
                    ':title' => $article['title'],
                    ':summary' => $article['summary'],
                    ':content' => $article['content'],
                    ':link' => $article['link'],
                    ':source' => $article['source'],
                    ':date' => $article['date'],
                    ':credibility' => $article['credibility'] ?? 8.0,
                    ':impact_level' => $article['impact_level'] ?? 'medium'
                ]);
                
                // Get the inserted ID for translation
                $newsId = getDatabaseConnection()->lastInsertId();
                if ($newsId) {
                    $needsTranslation[] = $newsId;
                }
                
                $saved++;
                
            } catch (Exception $e) {
                // Skip duplicates or errors
                continue;
            }
        }
        
        // Auto-translate new articles (simple & fast)
        if (!empty($needsTranslation) && file_exists(__DIR__ . '/../modules/simple_translator.php')) {
            require_once __DIR__ . '/../modules/simple_translator.php';
            try {
                SimpleTranslator::autoTranslateNews();
            } catch (Exception $e) {
                // Silent fail
            }
        }
        
        return $saved;
    }
    
    /**
     * Get recent news from database
     */
    public function getRecentNews($limit = 50, $hours = 48) {
        $sql = "SELECT * FROM news_events 
                WHERE date >= DATE_SUB(NOW(), INTERVAL :hours HOUR)
                ORDER BY date DESC 
                LIMIT :limit";
        
        $stmt = getDatabaseConnection()->prepare($sql);
        $stmt->bindValue(':hours', $hours, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}

// CLI Execution
if (php_sapi_name() === 'cli') {
    echo "=== Crypto News Scraper ===\n\n";
    $scraper = new NewsScraper();
    $scraper->fetchAllNews();
}
?>

