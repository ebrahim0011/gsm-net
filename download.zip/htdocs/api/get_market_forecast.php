<?php
/**
 * API: Get Market Forecast
 * Returns comprehensive market direction forecast for next period
 */

// Start output buffering
ob_start();

// Suppress errors/warnings from being printed
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/market_forecast.php';

// Clear any output from includes
ob_end_clean();

// Start fresh output buffer
ob_start();

try {
    $symbol = $_GET['symbol'] ?? 'BTC';
    
    $forecast = new MarketForecast();
    $result = $forecast->getMarketForecast($symbol);
    
    // Clear any output before JSON
    ob_end_clean();
    
    echo json_encode([
        'success' => true,
        'data' => $result
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // Clear any output before JSON
    ob_end_clean();
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

exit;

