<?php
/**
 * API Endpoint: Fetch Data
 * 
 * Fetches news and prices from online sources
 */

// Start output buffering to catch any unwanted output
ob_start();

// Suppress errors/warnings from being printed
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../collector/news_scraper.php';
require_once __DIR__ . '/../collector/price_scraper.php';

// Clear any output from includes
ob_end_clean();

// Start fresh output buffer
ob_start();

try {
    $response = [
        'success' => false,
        'message' => '',
        'data' => []
    ];
    
    // Fetch news (Silent mode - no console output)
    $newsScraper = new NewsScraper();
    $newsScraper->setSilentMode(true); // ✅ Disable echo for API calls
    $news = $newsScraper->fetchAllNews();
    
    // Fetch prices (Silent mode - no console output)
    $priceScraper = new PriceScraper();
    $priceScraper->setSilentMode(true); // ✅ Disable echo for API calls
    $prices = $priceScraper->fetchAllPrices();
    
    $response['success'] = true;
    $response['message'] = 'Data fetched successfully from Binance & News sources';
    $response['data'] = [
        'news_count' => count($news),
        'price_count' => count($prices),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
}

// Clear any output before JSON
ob_end_clean();

// Output only clean JSON
echo json_encode($response);
exit;
