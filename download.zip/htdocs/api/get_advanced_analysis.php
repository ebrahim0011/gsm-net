<?php
/**
 * API: Get Advanced Analysis
 * Returns Volume Analysis + Fear & Greed Index
 */

// Start output buffering
ob_start();

// Suppress errors/warnings from being printed
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/volume_analyzer.php';
require_once __DIR__ . '/../modules/fear_greed_index.php';
require_once __DIR__ . '/../modules/liquidity_analyzer.php';
require_once __DIR__ . '/../modules/accumulation_analyzer.php';

// Clear any output from includes
ob_end_clean();

// Start fresh output buffer
ob_start();

try {
    $symbol = $_GET['symbol'] ?? 'BTC';
    $lang = $_GET['lang'] ?? 'ar'; // Default Arabic
    
    // Get Volume Analysis
    $volumeAnalyzer = new VolumeAnalyzer();
    $volumeAnalysis = $volumeAnalyzer->getComprehensiveAnalysis($symbol);
    
    // Get Fear & Greed Index
    $fearGreedIndex = new FearGreedIndex();
    $fearGreed = $fearGreedIndex->getCurrentIndex();
    
    // Get Liquidity Analysis
    $liquidityAnalyzer = new LiquidityAnalyzer();
    $liquidity = $liquidityAnalyzer->getComprehensiveLiquidity();
    
    // Get Accumulation Analysis
    $accumulationAnalyzer = new AccumulationAnalyzer();
    $accumulation = $accumulationAnalyzer->getAccumulationAnalysis($symbol);
    
    // Add localized text based on language
    if (isset($fearGreed['description']) && is_array($fearGreed['description'])) {
        $fearGreed['description'] = $fearGreed['description'][$lang] ?? $fearGreed['description']['en'];
    }
    if (isset($fearGreed['recommendation']) && is_array($fearGreed['recommendation'])) {
        $fearGreed['recommendation'] = $fearGreed['recommendation'][$lang] ?? $fearGreed['recommendation']['en'];
    }
    
    // Localize liquidity recommendations
    if (isset($liquidity['recommendations']) && is_array($liquidity['recommendations'])) {
        foreach ($liquidity['recommendations'] as &$rec) {
            if (is_array($rec)) {
                $rec['message'] = $lang === 'ar' ? ($rec['message_ar'] ?? $rec['message_en']) : ($rec['message_en'] ?? '');
            }
        }
    }
    
    // Localize accumulation recommendations
    if (isset($accumulation['recommendations']) && is_array($accumulation['recommendations'])) {
        foreach ($accumulation['recommendations'] as &$rec) {
            if (is_array($rec)) {
                $rec['message'] = $lang === 'ar' ? ($rec['message_ar'] ?? $rec['message_en']) : ($rec['message_en'] ?? '');
            }
        }
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'symbol' => $symbol,
        'lang' => $lang,
        'timestamp' => date('Y-m-d H:i:s'),
        'volume_analysis' => $volumeAnalysis,
        'fear_greed_index' => $fearGreed,
        'liquidity' => $liquidity,
        'accumulation' => $accumulation
    ];
    
    // Clear any output before JSON
    ob_end_clean();
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // Clear any output before JSON
    ob_end_clean();
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

exit;
?>

