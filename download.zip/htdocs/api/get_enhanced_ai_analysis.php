<?php
/**
 * Enhanced AI Analysis API Endpoint
 * 
 * Provides access to all enhanced AI analysis features:
 * - Enhanced technical indicators
 * - Advanced sentiment analysis
 * - Multi-timeframe analysis
 * - News impact analysis
 * - Enhanced AI predictions
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/enhanced_ai_engine.php';
require_once __DIR__ . '/../modules/enhanced_sentiment_analyzer.php';
require_once __DIR__ . '/../modules/enhanced_multitimeframe_analyzer.php';
require_once __DIR__ . '/../modules/news_impact_analyzer.php';
require_once __DIR__ . '/../modules/technical_indicators.php';

try {
    $symbol = $_GET['symbol'] ?? 'BTC';
    $analysis_type = $_GET['type'] ?? 'comprehensive';
    
    $response = [
        'success' => true,
        'symbol' => $symbol,
        'analysis_type' => $analysis_type,
        'timestamp' => date('Y-m-d H:i:s'),
        'data' => []
    ];
    
    switch ($analysis_type) {
        case 'comprehensive':
            $response['data'] = getComprehensiveAnalysis($symbol);
            break;
            
        case 'ai_prediction':
            $response['data'] = getEnhancedAIPrediction($symbol);
            break;
            
        case 'sentiment':
            $response['data'] = getEnhancedSentimentAnalysis();
            break;
            
        case 'multitimeframe':
            $response['data'] = getMultiTimeframeAnalysis($symbol);
            break;
            
        case 'news_impact':
            $hours = $_GET['hours'] ?? 24;
            $response['data'] = getNewsImpactAnalysis($hours);
            break;
            
        case 'technical_enhanced':
            $response['data'] = getEnhancedTechnicalAnalysis($symbol);
            break;
            
        default:
            throw new Exception('Invalid analysis type');
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
}

/**
 * Get comprehensive analysis combining all enhanced features
 */
function getComprehensiveAnalysis($symbol) {
    $analysis = [];
    
    try {
        // Enhanced AI Prediction
        $aiEngine = new EnhancedAIEngine();
        $aiEngine->setSilentMode(true);
        $analysis['ai_prediction'] = $aiEngine->predictEnhanced($symbol);
    } catch (Exception $e) {
        $analysis['ai_prediction'] = ['error' => $e->getMessage()];
    }
    
    try {
        // Enhanced Sentiment Analysis
        $sentimentAnalyzer = new EnhancedSentimentAnalyzer();
        $analysis['sentiment'] = $sentimentAnalyzer->getRealTimeMarketSentiment(24);
    } catch (Exception $e) {
        $analysis['sentiment'] = ['error' => $e->getMessage()];
    }
    
    try {
        // Multi-timeframe Analysis
        $multiTimeframe = new EnhancedMultiTimeframeAnalyzer();
        $analysis['multitimeframe'] = $multiTimeframe->analyzeMultiTimeframe($symbol);
    } catch (Exception $e) {
        $analysis['multitimeframe'] = ['error' => $e->getMessage()];
    }
    
    try {
        // News Impact Analysis
        $newsAnalyzer = new NewsImpactAnalyzer();
        $analysis['news_impact'] = $newsAnalyzer->analyzeNewsImpact(null, 24);
    } catch (Exception $e) {
        $analysis['news_impact'] = ['error' => $e->getMessage()];
    }
    
    try {
        // Enhanced Technical Indicators
        $technical = new TechnicalIndicators();
        $technical->setSilentMode(true);
        $analysis['technical'] = $technical->getLatestIndicators($symbol);
    } catch (Exception $e) {
        $analysis['technical'] = ['error' => $e->getMessage()];
    }
    
    // Generate overall market assessment
    $analysis['overall_assessment'] = generateOverallAssessment($analysis);
    
    return $analysis;
}

/**
 * Get enhanced AI prediction
 */
function getEnhancedAIPrediction($symbol) {
    $aiEngine = new EnhancedAIEngine();
    $aiEngine->setSilentMode(true);
    return $aiEngine->predictEnhanced($symbol);
}

/**
 * Get enhanced sentiment analysis
 */
function getEnhancedSentimentAnalysis() {
    $sentimentAnalyzer = new EnhancedSentimentAnalyzer();
    return $sentimentAnalyzer->getRealTimeMarketSentiment(24);
}

/**
 * Get multi-timeframe analysis
 */
function getMultiTimeframeAnalysis($symbol) {
    $multiTimeframe = new EnhancedMultiTimeframeAnalyzer();
    return $multiTimeframe->analyzeMultiTimeframe($symbol);
}

/**
 * Get news impact analysis
 */
function getNewsImpactAnalysis($hours) {
    $newsAnalyzer = new NewsImpactAnalyzer();
    return $newsAnalyzer->analyzeNewsImpact(null, $hours);
}

/**
 * Get enhanced technical analysis
 */
function getEnhancedTechnicalAnalysis($symbol) {
    $technical = new TechnicalIndicators();
    $technical->setSilentMode(true);
    
    $indicators = $technical->getLatestIndicators($symbol);
    
    // Add enhanced analysis
    if ($indicators) {
        $indicators['enhanced_signals'] = analyzeEnhancedSignals($indicators);
        $indicators['risk_assessment'] = assessTechnicalRisk($indicators);
        $indicators['confluence_score'] = calculateConfluenceScore($indicators);
    }
    
    return $indicators;
}

/**
 * Generate overall market assessment
 */
function generateOverallAssessment($analysis) {
    $assessment = [
        'overall_signal' => 'neutral',
        'confidence' => 0.5,
        'risk_level' => 'medium',
        'key_factors' => [],
        'recommendations' => []
    ];
    
    $bullishFactors = 0;
    $bearishFactors = 0;
    $confidenceSum = 0;
    $factorCount = 0;
    
    // Analyze AI prediction
    if (isset($analysis['ai_prediction']['signal'])) {
        $signal = $analysis['ai_prediction']['signal'];
        $confidence = $analysis['ai_prediction']['confidence'] ?? 0.5;
        
        if ($signal === 'bullish') {
            $bullishFactors += $confidence * 2; // AI gets double weight
            $assessment['key_factors'][] = 'AI prediction: Bullish (' . round($confidence * 100) . '% confidence)';
        } elseif ($signal === 'bearish') {
            $bearishFactors += $confidence * 2;
            $assessment['key_factors'][] = 'AI prediction: Bearish (' . round($confidence * 100) . '% confidence)';
        }
        
        $confidenceSum += $confidence;
        $factorCount++;
    }
    
    // Analyze sentiment
    if (isset($analysis['sentiment']['summary'])) {
        $sentiment = $analysis['sentiment']['summary'];
        
        if ($sentiment['positive_percentage'] > 60) {
            $bullishFactors += 1;
            $assessment['key_factors'][] = 'Positive sentiment: ' . round($sentiment['positive_percentage']) . '%';
        } elseif ($sentiment['negative_percentage'] > 60) {
            $bearishFactors += 1;
            $assessment['key_factors'][] = 'Negative sentiment: ' . round($sentiment['negative_percentage']) . '%';
        }
        
        $confidenceSum += $sentiment['confidence'] ?? 0.5;
        $factorCount++;
    }
    
    // Analyze multi-timeframe
    if (isset($analysis['multitimeframe']['overall_signal'])) {
        $mtSignal = $analysis['multitimeframe']['overall_signal'];
        
        if ($mtSignal['signal'] === 'bullish') {
            $bullishFactors += $mtSignal['strength'];
            $assessment['key_factors'][] = 'Multi-timeframe: Bullish alignment';
        } elseif ($mtSignal['signal'] === 'bearish') {
            $bearishFactors += $mtSignal['strength'];
            $assessment['key_factors'][] = 'Multi-timeframe: Bearish alignment';
        }
        
        $confidenceSum += $mtSignal['confidence'];
        $factorCount++;
    }
    
    // Analyze news impact
    if (isset($analysis['news_impact']['market_direction'])) {
        $newsDirection = $analysis['news_impact']['market_direction'];
        
        if ($newsDirection === 'bullish') {
            $bullishFactors += 0.5;
            $assessment['key_factors'][] = 'News sentiment: Positive impact expected';
        } elseif ($newsDirection === 'bearish') {
            $bearishFactors += 0.5;
            $assessment['key_factors'][] = 'News sentiment: Negative impact expected';
        }
    }
    
    // Calculate overall signal
    $totalFactors = $bullishFactors + $bearishFactors;
    if ($totalFactors > 0) {
        $bullishRatio = $bullishFactors / $totalFactors;
        
        if ($bullishRatio > 0.65) {
            $assessment['overall_signal'] = 'bullish';
        } elseif ($bullishRatio < 0.35) {
            $assessment['overall_signal'] = 'bearish';
        }
    }
    
    // Calculate confidence
    if ($factorCount > 0) {
        $assessment['confidence'] = min(0.95, $confidenceSum / $factorCount);
    }
    
    // Assess risk level
    $riskFactors = 0;
    
    if (isset($analysis['ai_prediction']['risk_assessment']['level'])) {
        $aiRisk = $analysis['ai_prediction']['risk_assessment']['level'];
        if ($aiRisk === 'high') $riskFactors += 2;
        elseif ($aiRisk === 'medium') $riskFactors += 1;
    }
    
    if (isset($analysis['multitimeframe']['divergences']) && !empty($analysis['multitimeframe']['divergences'])) {
        $riskFactors += count($analysis['multitimeframe']['divergences']);
    }
    
    if ($riskFactors >= 3) {
        $assessment['risk_level'] = 'high';
    } elseif ($riskFactors >= 1) {
        $assessment['risk_level'] = 'medium';
    } else {
        $assessment['risk_level'] = 'low';
    }
    
    // Generate recommendations
    $assessment['recommendations'] = generateRecommendations(
        $assessment['overall_signal'],
        $assessment['confidence'],
        $assessment['risk_level']
    );
    
    return $assessment;
}

/**
 * Analyze enhanced signals from technical indicators
 */
function analyzeEnhancedSignals($indicators) {
    $signals = [];
    
    // RSI enhanced analysis
    $rsi = (float)$indicators['rsi'];
    if ($rsi <= 25) {
        $signals['rsi'] = ['signal' => 'strong_buy', 'reason' => 'Extremely oversold'];
    } elseif ($rsi <= 30) {
        $signals['rsi'] = ['signal' => 'buy', 'reason' => 'Oversold'];
    } elseif ($rsi >= 75) {
        $signals['rsi'] = ['signal' => 'strong_sell', 'reason' => 'Extremely overbought'];
    } elseif ($rsi >= 70) {
        $signals['rsi'] = ['signal' => 'sell', 'reason' => 'Overbought'];
    } else {
        $signals['rsi'] = ['signal' => 'neutral', 'reason' => 'Normal range'];
    }
    
    // MACD enhanced analysis
    $macd = (float)$indicators['macd'];
    $macdSignal = (float)$indicators['macd_signal'];
    $macdHist = (float)$indicators['macd_histogram'];
    
    if ($macd > $macdSignal && $macdHist > 0.001) {
        $signals['macd'] = ['signal' => 'bullish', 'reason' => 'Bullish crossover with positive momentum'];
    } elseif ($macd < $macdSignal && $macdHist < -0.001) {
        $signals['macd'] = ['signal' => 'bearish', 'reason' => 'Bearish crossover with negative momentum'];
    } else {
        $signals['macd'] = ['signal' => 'neutral', 'reason' => 'No clear momentum'];
    }
    
    return $signals;
}

/**
 * Assess technical risk
 */
function assessTechnicalRisk($indicators) {
    $riskScore = 0;
    $riskFactors = [];
    
    // Volatility risk
    $volatility = (float)($indicators['volatility'] ?? 0);
    if ($volatility > 0.05) {
        $riskScore += 2;
        $riskFactors[] = 'High volatility detected';
    }
    
    // RSI extreme levels
    $rsi = (float)$indicators['rsi'];
    if ($rsi > 80 || $rsi < 20) {
        $riskScore += 1;
        $riskFactors[] = 'RSI at extreme levels';
    }
    
    return [
        'score' => $riskScore,
        'level' => $riskScore >= 3 ? 'high' : ($riskScore >= 1 ? 'medium' : 'low'),
        'factors' => $riskFactors
    ];
}

/**
 * Calculate confluence score
 */
function calculateConfluenceScore($indicators) {
    $bullishSignals = 0;
    $bearishSignals = 0;
    $totalSignals = 0;
    
    // RSI
    $rsi = (float)$indicators['rsi'];
    if ($rsi <= 30) $bullishSignals++;
    elseif ($rsi >= 70) $bearishSignals++;
    $totalSignals++;
    
    // MACD
    $macd = (float)$indicators['macd'];
    $macdSignal = (float)$indicators['macd_signal'];
    if ($macd > $macdSignal) $bullishSignals++;
    else $bearishSignals++;
    $totalSignals++;
    
    // Calculate confluence
    $maxSignals = max($bullishSignals, $bearishSignals);
    $confluenceScore = $totalSignals > 0 ? ($maxSignals / $totalSignals) : 0;
    
    return [
        'score' => $confluenceScore,
        'bullish_signals' => $bullishSignals,
        'bearish_signals' => $bearishSignals,
        'total_signals' => $totalSignals,
        'dominant_direction' => $bullishSignals > $bearishSignals ? 'bullish' : 'bearish'
    ];
}

/**
 * Generate trading recommendations
 */
function generateRecommendations($signal, $confidence, $riskLevel) {
    $recommendations = [];
    
    if ($riskLevel === 'high') {
        $recommendations[] = 'High risk detected - consider waiting for better entry';
        $recommendations[] = 'Use smaller position sizes if trading';
        $recommendations[] = 'Set tight stop losses';
    }
    
    if ($signal === 'bullish' && $confidence > 0.7) {
        $recommendations[] = 'Strong bullish signal - consider long positions';
        $recommendations[] = 'Look for pullbacks as entry opportunities';
    } elseif ($signal === 'bearish' && $confidence > 0.7) {
        $recommendations[] = 'Strong bearish signal - consider short positions';
        $recommendations[] = 'Wait for bounces to enter short positions';
    } else {
        $recommendations[] = 'Mixed signals - consider waiting for clearer direction';
        $recommendations[] = 'Focus on risk management over position size';
    }
    
    if ($confidence < 0.5) {
        $recommendations[] = 'Low confidence - avoid large positions';
    }
    
    return $recommendations;
}
?>

