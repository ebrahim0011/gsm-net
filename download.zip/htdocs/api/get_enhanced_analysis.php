<?php
/**
 * Enhanced Analysis API Endpoint
 * يوفر تحليل شامل محسّن مع جميع الوحدات الجديدة
 * 
 * Usage: /api/get_enhanced_analysis.php?symbol=BTC
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/cache.php';
require_once __DIR__ . '/../modules/orderbook_analyzer.php';
require_once __DIR__ . '/../modules/social_media_analyzer.php';
require_once __DIR__ . '/../modules/multitimeframe_analyzer.php';
require_once __DIR__ . '/../modules/ai_engine.php';
require_once __DIR__ . '/../modules/volume_analyzer.php';
require_once __DIR__ . '/../modules/fear_greed_index.php';

try {
    $symbol = $_GET['symbol'] ?? 'BTC';
    
    $response = [
        'success' => true,
        'symbol' => $symbol,
        'timestamp' => date('Y-m-d H:i:s'),
        'analysis' => []
    ];
    
    // 1. Order Book Analysis
    $orderBookAnalyzer = new OrderBookAnalyzer();
    $response['analysis']['order_book'] = $orderBookAnalyzer->getComprehensiveAnalysis($symbol);
    $response['analysis']['order_book_signal'] = $orderBookAnalyzer->getOverallSignal($symbol);
    
    // 2. Social Media Analysis
    $socialMediaAnalyzer = new SocialMediaAnalyzer();
    $response['analysis']['social_media'] = $socialMediaAnalyzer->getComprehensiveAnalysis($symbol);
    $response['analysis']['social_media_signal'] = $socialMediaAnalyzer->getOverallSignal($symbol);
    
    // 3. Multi-Timeframe Analysis
    $multiTimeframeAnalyzer = new MultiTimeframeAnalyzer();
    $response['analysis']['multi_timeframe'] = $multiTimeframeAnalyzer->getComprehensiveAnalysis($symbol);
    
    // 4. AI Prediction (existing)
    $aiEngine = new AIEngine();
    $aiEngine->setSilentMode(true);
    $response['analysis']['ai_prediction'] = $aiEngine->getLatestPrediction($symbol);
    
    // 5. Volume Analysis (existing)
    $volumeAnalyzer = new VolumeAnalyzer();
    $response['analysis']['volume'] = $volumeAnalyzer->getComprehensiveAnalysis($symbol);
    
    // 6. Fear & Greed Index (existing)
    $fearGreed = new FearGreedIndex();
    $response['analysis']['fear_greed'] = $fearGreed->getCurrentIndex();
    
    // 7. Calculate Enhanced Overall Signal
    $response['overall_signal'] = calculateEnhancedOverallSignal($response['analysis']);
    
    // 8. Generate Trading Recommendation
    $response['recommendation'] = generateTradingRecommendation($response['overall_signal'], $symbol);
    
    // 9. Cache statistics
    $cache = $GLOBALS['cache'];
    $response['cache_stats'] = $cache->getStats();
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ], JSON_PRETTY_PRINT);
}

/**
 * Calculate enhanced overall signal from all analyses
 */
function calculateEnhancedOverallSignal($analysis) {
    $scores = [];
    $weights = [
        'ai_prediction' => 0.20,
        'order_book' => 0.20,
        'social_media' => 0.15,
        'multi_timeframe' => 0.25,
        'volume' => 0.15,
        'fear_greed' => 0.05
    ];
    
    // AI Prediction
    if (isset($analysis['ai_prediction']['predicted_signal'])) {
        $signal = $analysis['ai_prediction']['predicted_signal'];
        $confidence = (float)($analysis['ai_prediction']['confidence_score'] ?? 0.5);
        $scores['ai_prediction'] = [
            'score' => $signal === 'bullish' ? $confidence : ($signal === 'bearish' ? -$confidence : 0),
            'weight' => $weights['ai_prediction']
        ];
    }
    
    // Order Book
    if (isset($analysis['order_book_signal']['signal'])) {
        $signal = $analysis['order_book_signal']['signal'];
        $confidence = (float)($analysis['order_book_signal']['confidence'] ?? 0.5);
        $scores['order_book'] = [
            'score' => $signal === 'bullish' ? $confidence : ($signal === 'bearish' ? -$confidence : 0),
            'weight' => $weights['order_book']
        ];
    }
    
    // Social Media
    if (isset($analysis['social_media_signal']['signal'])) {
        $signal = $analysis['social_media_signal']['signal'];
        $confidence = (float)($analysis['social_media_signal']['confidence'] ?? 0.5);
        $scores['social_media'] = [
            'score' => $signal === 'bullish' ? $confidence : ($signal === 'bearish' ? -$confidence : 0),
            'weight' => $weights['social_media']
        ];
    }
    
    // Multi-Timeframe
    if (isset($analysis['multi_timeframe']['confluence']['signal'])) {
        $signal = $analysis['multi_timeframe']['confluence']['signal'];
        $confidence = (float)($analysis['multi_timeframe']['confluence']['confidence'] ?? 0.5);
        $scores['multi_timeframe'] = [
            'score' => $signal === 'bullish' ? $confidence : ($signal === 'bearish' ? -$confidence : 0),
            'weight' => $weights['multi_timeframe']
        ];
    }
    
    // Volume
    if (isset($analysis['volume']['signal'])) {
        $signal = $analysis['volume']['signal'];
        $volumeScore = (float)($analysis['volume']['overall_score'] ?? 0);
        $scores['volume'] = [
            'score' => $volumeScore / 100,
            'weight' => $weights['volume']
        ];
    }
    
    // Fear & Greed (contrarian)
    if (isset($analysis['fear_greed']['value'])) {
        $value = (float)$analysis['fear_greed']['value'];
        // Extreme fear = bullish, extreme greed = bearish
        $fgScore = ($value - 50) / 50; // -1 to 1
        $scores['fear_greed'] = [
            'score' => -$fgScore, // Inverted (contrarian)
            'weight' => $weights['fear_greed']
        ];
    }
    
    // Calculate weighted average
    $totalScore = 0;
    $totalWeight = 0;
    
    foreach ($scores as $key => $data) {
        $totalScore += $data['score'] * $data['weight'];
        $totalWeight += $data['weight'];
    }
    
    $finalScore = $totalWeight > 0 ? $totalScore / $totalWeight : 0;
    
    // Determine signal
    if ($finalScore > 0.3) {
        $signal = 'STRONG_BULLISH';
    } elseif ($finalScore > 0.1) {
        $signal = 'BULLISH';
    } elseif ($finalScore < -0.3) {
        $signal = 'STRONG_BEARISH';
    } elseif ($finalScore < -0.1) {
        $signal = 'BEARISH';
    } else {
        $signal = 'NEUTRAL';
    }
    
    return [
        'signal' => $signal,
        'score' => round($finalScore, 4),
        'confidence' => round(abs($finalScore), 4),
        'breakdown' => $scores,
        'interpretation' => interpretSignal($signal, $finalScore)
    ];
}

/**
 * Generate trading recommendation
 */
function generateTradingRecommendation($overallSignal, $symbol) {
    $signal = $overallSignal['signal'];
    $confidence = $overallSignal['confidence'];
    
    $recommendation = [
        'action' => 'WAIT',
        'confidence' => $confidence,
        'risk_level' => 'MEDIUM',
        'suggested_position_size' => '0%',
        'stop_loss_pct' => 0,
        'take_profit_pct' => 0,
        'timeframe' => '24h',
        'description' => ''
    ];
    
    switch ($signal) {
        case 'STRONG_BULLISH':
            $recommendation['action'] = 'BUY';
            $recommendation['risk_level'] = 'MEDIUM';
            $recommendation['suggested_position_size'] = '50-75%';
            $recommendation['stop_loss_pct'] = -3;
            $recommendation['take_profit_pct'] = 5;
            $recommendation['description'] = "Strong bullish signals across all indicators. Good entry opportunity.";
            break;
            
        case 'BULLISH':
            $recommendation['action'] = 'BUY';
            $recommendation['risk_level'] = 'MEDIUM-HIGH';
            $recommendation['suggested_position_size'] = '25-50%';
            $recommendation['stop_loss_pct'] = -2;
            $recommendation['take_profit_pct'] = 3;
            $recommendation['description'] = "Moderate bullish signals. Consider cautious entry.";
            break;
            
        case 'STRONG_BEARISH':
            $recommendation['action'] = 'SELL';
            $recommendation['risk_level'] = 'HIGH';
            $recommendation['suggested_position_size'] = '0%';
            $recommendation['stop_loss_pct'] = 3;
            $recommendation['take_profit_pct'] = -5;
            $recommendation['description'] = "Strong bearish signals. Consider exiting positions or shorting.";
            break;
            
        case 'BEARISH':
            $recommendation['action'] = 'SELL';
            $recommendation['risk_level'] = 'MEDIUM-HIGH';
            $recommendation['suggested_position_size'] = '0%';
            $recommendation['stop_loss_pct'] = 2;
            $recommendation['take_profit_pct'] = -3;
            $recommendation['description'] = "Moderate bearish signals. Reduce exposure or wait.";
            break;
            
        default:
            $recommendation['description'] = "No clear direction. Wait for stronger signals before entering positions.";
    }
    
    return $recommendation;
}

/**
 * Interpret signal
 */
function interpretSignal($signal, $score) {
    $interpretations = [
        'STRONG_BULLISH' => "Very strong buying opportunity detected. Multiple indicators align.",
        'BULLISH' => "Positive market sentiment with good entry potential.",
        'NEUTRAL' => "Market is consolidating. No clear direction yet.",
        'BEARISH' => "Negative market sentiment. Consider reducing exposure.",
        'STRONG_BEARISH' => "Very strong selling pressure detected. High risk of decline."
    ];
    
    return $interpretations[$signal] ?? "Unknown signal";
}
?>

