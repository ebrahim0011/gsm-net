<?php
/**
 * API Endpoint: Run Analysis
 * 
 * Runs sentiment analysis, technical indicators, and AI predictions
 */

// Start output buffering to catch any unwanted output
ob_start();

// Suppress errors/warnings from being printed
error_reporting(0);
ini_set('display_errors', 0);

// Increase execution time and memory limit for heavy analysis
set_time_limit(120); // 2 minutes
ini_set('memory_limit', '256M');

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/sentiment_analyzer.php';
require_once __DIR__ . '/../modules/technical_indicators.php';
require_once __DIR__ . '/../modules/ai_engine.php';

// Clear any output from includes
ob_end_clean();

// Start fresh output buffer
ob_start();

try {
    $response = [
        'success' => false,
        'message' => '',
        'data' => []
    ];
    
    $results = [];
    
    // 1. Sentiment Analysis (limit to 50 news for faster processing)
    $sentiment = new SentimentAnalyzer();
    $sentimentCount = $sentiment->analyzeNewsInDatabase(50);
    $results['sentiment_analyzed'] = $sentimentCount;
    
    // 2. Technical Indicators (Silent mode)
    $technical = new TechnicalIndicators();
    $technical->setSilentMode(true); // ✅ Disable echo for API calls
    
    // Use only top 3 symbols for faster processing on free hosting
    $symbols = ['BTC', 'ETH', 'BNB'];
    
    $indicatorsCount = 0;
    foreach ($symbols as $symbol) {
        $result = $technical->calculateAll($symbol);
        if ($result) {
            $indicatorsCount++;
        }
    }
    $results['indicators_calculated'] = $indicatorsCount;
    
    // 3. AI Predictions (Silent mode)
    $ai = new AIEngine();
    $ai->setSilentMode(true); // ✅ Disable echo for API calls
    $predictions = [];
    
    foreach ($symbols as $symbol) {
        $prediction = $ai->predict($symbol);
        if ($prediction) {
            $predictions[$symbol] = $prediction;
        }
    }
    $results['predictions_generated'] = count($predictions);
    
    $response['success'] = true;
    $response['message'] = "Analysis completed! Generated {$results['predictions_generated']} predictions for {$indicatorsCount} symbols. Run evaluation after 24-48 hours.";
    $response['data'] = $results;
    $response['next_step'] = 'Wait 24-48 hours, then run "Evaluate Predictions" to check accuracy.';
    
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = 'Error: ' . $e->getMessage();
    $response['error_details'] = [
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ];
}

// Clear any output before JSON
ob_end_clean();

// Set appropriate status code
if (!$response['success']) {
    http_response_code(500);
}

// Output only clean JSON
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
