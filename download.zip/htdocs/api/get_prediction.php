<?php
/**
 * API Endpoint: Get Prediction
 * 
 * Returns AI prediction for a symbol
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/ai_engine.php';

try {
    $symbol = $_GET['symbol'] ?? 'BTC';
    
    $ai = new AIEngine();
    $prediction = $ai->getLatestPrediction($symbol);
    
    if ($prediction) {
        // Decode JSON fields
        if ($prediction['top_factors']) {
            $prediction['top_factors'] = json_decode($prediction['top_factors'], true);
        }
        
        echo json_encode([
            'success' => true,
            'data' => $prediction
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No prediction found for ' . $symbol
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>

