<?php
/**
 * API: Get Historical Learning Data
 * 
 * Returns AI learning insights based on historical patterns
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/ai_learning.php';
require_once __DIR__ . '/../modules/pattern_matcher.php';

try {
    $symbol = $_GET['symbol'] ?? 'BTC';
    $newsId = $_GET['news_id'] ?? null;
    
    $patternMatcher = new PatternMatcher();
    $aiLearning = new AILearning();
    
    $response = [
        'success' => true,
        'symbol' => $symbol,
        'timestamp' => date('Y-m-d H:i:s'),
        'data' => []
    ];
    
    // Get learning summary
    $summary = $patternMatcher->getLearningSum($symbol, $newsId);
    
    if ($summary) {
        $response['data'] = [
            'has_patterns' => true,
            'pattern_count' => $summary['pattern_count'],
            'predicted_direction' => $summary['predicted_direction'],
            'predicted_change' => $summary['predicted_change'],
            'confidence' => $summary['confidence'],
            'recommendation' => $summary['recommendation'],
            'similar_patterns' => array_map(function($match) {
                $pattern = $match['pattern'];
                return [
                    'date' => date('M d, Y', strtotime($pattern['pattern_date'])),
                    'event_type' => $pattern['event_type'],
                    'event_description' => substr($pattern['event_description'], 0, 100) . '...',
                    'price_change_24h' => round($pattern['price_change_24h'], 2),
                    'market_direction' => $pattern['market_direction'],
                    'similarity' => round($match['similarity']['overall'] * 100, 1),
                    'confidence' => round($match['confidence'] * 100, 1)
                ];
            }, array_slice($summary['similar_patterns'], 0, 5))
        ];
    } else {
        $response['data'] = [
            'has_patterns' => false,
            'message' => 'No historical patterns found yet. System is still learning.'
        ];
    }
    
    // Get historical learning summary
    $historicalSummary = $aiLearning->getHistoricalLearningSummary($symbol);
    
    $response['data']['historical_summary'] = [
        'total_patterns' => count($historicalSummary['common_patterns']),
        'common_event_types' => array_map(function($pattern) {
            return [
                'type' => $pattern['event_type'],
                'count' => $pattern['occurrence_count'],
                'avg_change' => round($pattern['avg_price_change'], 2),
                'last_occurrence' => date('M d, Y', strtotime($pattern['last_occurrence']))
            ];
        }, $historicalSummary['common_patterns']),
        'prediction_performance' => $historicalSummary['prediction_performance']
    ];
    
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ], JSON_PRETTY_PRINT);
}
?>

