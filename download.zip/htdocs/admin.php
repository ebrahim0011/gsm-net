<!DOCTYPE html>
<?php
// Language switcher
$lang = $_GET['lang'] ?? $_COOKIE['lang'] ?? 'ar';
setcookie('lang', $lang, time() + (86400 * 30), '/');
$isRTL = ($lang === 'ar');
?>
<html lang="<?= $lang ?>" dir="<?= $isRTL ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $isRTL ? 'لوحة الإدارة - تحليل سوق العملات بالذكاء الاصطناعي' : 'Admin Dashboard - Crypto Market AI' ?></title>
    <!-- Arabic Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        body[dir="rtl"] { font-family: 'Cairo', sans-serif; }
        .rtl-flip { transform: scaleX(-1); }
        [dir="rtl"] .chart-container { direction: ltr; }
        
        /* Dark/Light Mode Support */
        .theme-transition * {
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease !important;
        }
        
        .dark-mode-toggle {
            transition: all 0.3s ease !important;
        }
        
        .dark-mode-toggle:hover {
            transform: rotate(15deg) scale(1.1);
        }
        
        /* Light Mode Overrides */
        [data-theme="light"] .bg-gray-900 { background-color: #f9fafb !important; }
        [data-theme="light"] .bg-gray-800 { background-color: #ffffff !important; border: 1px solid #e5e7eb !important; }
        [data-theme="light"] .bg-gray-700 { background-color: #f3f4f6 !important; }
        [data-theme="light"] .text-gray-100 { color: #111827 !important; }
        [data-theme="light"] .text-gray-400 { color: #6b7280 !important; }
    </style>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-900 text-gray-100 theme-transition">
    
    <?php
    require_once __DIR__ . '/config/database.php';
    require_once __DIR__ . '/modules/ai_learning.php';
    
    // Get system statistics
    $stats = [
        'total_news' => fetchOne("SELECT COUNT(*) as count FROM news_events")['count'],
        'total_prices' => fetchOne("SELECT COUNT(*) as count FROM market_prices")['count'],
        'total_predictions' => fetchOne("SELECT COUNT(*) as count FROM ai_predictions")['count'],
        'avg_accuracy' => fetchOne("SELECT AVG(accuracy_score) as avg FROM ai_predictions WHERE accuracy_score IS NOT NULL")['avg']
    ];
    
    // Get recent predictions
    $recentPredictions = fetchAll("SELECT * FROM ai_predictions ORDER BY prediction_timestamp DESC LIMIT 10");
    
    // Get model performance
    $learning = new AILearning();
    $performance = $learning->getPerformanceStats(30);
    
    // Translations
    $t = [
        'admin_dashboard' => $isRTL ? 'لوحة الإدارة' : 'Admin Dashboard',
        'back_home' => $isRTL ? 'عودة للرئيسية' : 'Back to Home',
        'total_news' => $isRTL ? 'إجمالي الأخبار' : 'Total News',
        'total_prices' => $isRTL ? 'إجمالي الأسعار' : 'Total Prices',
        'predictions' => $isRTL ? 'التنبؤات' : 'Predictions',
        'avg_accuracy' => $isRTL ? 'متوسط الدقة' : 'Avg Accuracy',
        'fetch_news' => $isRTL ? 'جلب الأخبار' : 'Fetch News',
        'fetch_prices' => $isRTL ? 'جلب الأسعار' : 'Fetch Prices',
        'run_analysis' => $isRTL ? 'تشغيل التحليل' : 'Run Analysis',
        'evaluate' => $isRTL ? 'تقييم النموذج' : 'Evaluate Model',
        'recent_predictions' => $isRTL ? 'آخر التنبؤات' : 'Recent Predictions',
        'model_performance' => $isRTL ? 'أداء النموذج' : 'Model Performance',
        'model_performance_subtitle' => $isRTL ? '(آخر 30 يوم)' : '(Last 30 Days)',
        'symbol' => $isRTL ? 'الرمز' : 'Symbol',
        'signal' => $isRTL ? 'الإشارة' : 'Signal',
        'confidence' => $isRTL ? 'الثقة' : 'Confidence',
        'time' => $isRTL ? 'الوقت' : 'Time',
        'bullish' => $isRTL ? 'صاعد' : 'Bullish',
        'bearish' => $isRTL ? 'هابط' : 'Bearish',
        'sideways' => $isRTL ? 'جانبي' : 'Sideways',
        'total_predictions' => $isRTL ? 'إجمالي التنبؤات:' : 'Total Predictions:',
        'correct' => $isRTL ? 'الصحيحة:' : 'Correct:',
        'accuracy' => $isRTL ? 'الدقة:' : 'Accuracy:',
        'no_performance_data' => $isRTL ? 'لا توجد بيانات أداء حتى الآن.' : 'No performance data available yet.'
    ];
    ?>
    
    <header class="bg-gray-800 shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <h1 class="text-2xl font-bold">
                    <i class="fas fa-cog text-blue-500"></i> <?= $t['admin_dashboard'] ?>
                </h1>
                <div class="flex items-center gap-3">
                    <a href="?lang=<?= $isRTL ? 'en' : 'ar' ?>" class="px-3 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition">
                        <i class="fas fa-language"></i> <?= $isRTL ? 'EN' : 'ع' ?>
                    </a>
                    <button id="darkModeToggle" class="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 dark-mode-toggle" title="Toggle Dark/Light Mode">
                        <i class="fas fa-moon text-blue-400"></i>
                    </button>
                    <a href="index.php" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg">
                        <i class="fas fa-arrow-left"></i> <?= $t['back_home'] ?>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <main class="container mx-auto px-4 py-6">
        
        <!-- Statistics Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-gray-800 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-400 text-sm"><?= $t['total_news'] ?></p>
                        <p class="text-3xl font-bold mt-1"><?= number_format($stats['total_news']) ?></p>
                    </div>
                    <i class="fas fa-newspaper text-blue-500 text-3xl"></i>
                </div>
            </div>
            
            <div class="bg-gray-800 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-400 text-sm"><?= $t['total_prices'] ?></p>
                        <p class="text-3xl font-bold mt-1"><?= number_format($stats['total_prices']) ?></p>
                    </div>
                    <i class="fas fa-chart-line text-green-500 text-3xl"></i>
                </div>
            </div>
            
            <div class="bg-gray-800 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-400 text-sm"><?= $t['predictions'] ?></p>
                        <p class="text-3xl font-bold mt-1"><?= number_format($stats['total_predictions']) ?></p>
                    </div>
                    <i class="fas fa-robot text-purple-500 text-3xl"></i>
                </div>
            </div>
            
            <div class="bg-gray-800 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-400 text-sm"><?= $t['avg_accuracy'] ?></p>
                        <p class="text-3xl font-bold mt-1"><?= number_format($stats['avg_accuracy'] * 100, 1) ?>%</p>
                    </div>
                    <i class="fas fa-brain text-yellow-500 text-3xl"></i>
                </div>
            </div>
        </div>
        
        <!-- Actions Panel -->
        <div class="bg-gray-800 rounded-xl p-6 mb-8">
            <h2 class="text-xl font-bold mb-4">
                <i class="fas fa-tasks text-blue-500"></i> <?= $isRTL ? 'إجراءات النظام' : 'System Actions' ?>
            </h2>
            
            <!-- Workflow Guide -->
            <div class="mb-4 p-4 bg-blue-900 bg-opacity-30 border border-blue-700 rounded-lg text-sm">
                <div class="flex items-start gap-2">
                    <i class="fas fa-info-circle text-blue-400 mt-1"></i>
                    <div>
                        <strong><?= $isRTL ? 'سير العمل الموصى به:' : 'Recommended Workflow:' ?></strong>
                        <ol class="<?= $isRTL ? 'mr-4' : 'ml-4' ?> mt-2 space-y-1">
                            <li>1️⃣ <?= $isRTL ? 'جلب أحدث البيانات (يومياً)' : 'Fetch Latest Data (Daily)' ?></li>
                            <li>2️⃣ <?= $isRTL ? 'تشغيل التحليل لإنشاء تنبؤات' : 'Run Analysis to generate predictions' ?></li>
                            <li>3️⃣ <?= $isRTL ? 'انتظر 24-48 ساعة' : 'Wait 24-48 hours' ?></li>
                            <li>4️⃣ <?= $isRTL ? 'تقييم التنبؤات لقياس الدقة' : 'Evaluate Predictions to measure accuracy' ?></li>
                        </ol>
                    </div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button onclick="runAction('fetch')" class="px-6 py-4 bg-blue-600 hover:bg-blue-700 rounded-lg transition">
                    <i class="fas fa-download"></i> <?= $isRTL ? 'جلب أحدث البيانات' : 'Fetch Latest Data' ?>
                    <div class="text-xs opacity-75 mt-1"><?= $isRTL ? 'الخطوة 1' : 'Step 1' ?></div>
                </button>
                <button onclick="runAction('analyze')" class="px-6 py-4 bg-green-600 hover:bg-green-700 rounded-lg transition">
                    <i class="fas fa-chart-bar"></i> <?= $t['run_analysis'] ?>
                    <div class="text-xs opacity-75 mt-1"><?= $isRTL ? 'الخطوة 2' : 'Step 2' ?></div>
                </button>
                <button onclick="runAction('evaluate')" class="px-6 py-4 bg-purple-600 hover:bg-purple-700 rounded-lg transition">
                    <i class="fas fa-check-circle"></i> <?= $isRTL ? 'تقييم التنبؤات' : 'Evaluate Predictions' ?>
                    <div class="text-xs opacity-75 mt-1"><?= $isRTL ? 'الخطوة 4' : 'Step 4' ?></div>
                </button>
            </div>
            
            <div id="actionResult" class="mt-4"></div>
        </div>
        
        <!-- Historical Data Import (NEW) -->
        <div class="bg-gradient-to-r from-purple-900 to-indigo-900 rounded-xl p-6 mb-8 border-2 border-purple-500">
            <div class="flex items-start gap-4">
                <div class="flex-shrink-0">
                    <i class="fas fa-database text-purple-400 text-4xl"></i>
                </div>
                <div class="flex-grow">
                    <h2 class="text-xl font-bold mb-2">
                        <?= $isRTL ? '📊 استيراد بيانات تاريخية (سنة كاملة)' : '📊 Import 1 Year Historical Data' ?>
                        <span class="<?= $isRTL ? 'mr-2' : 'ml-2' ?> px-2 py-1 text-xs bg-purple-600 rounded-full animate-pulse">
                            <?= $isRTL ? 'جديد' : 'NEW' ?>
                        </span>
                    </h2>
                    <p class="text-sm text-gray-300 mb-4">
                        <?= $isRTL ? 
                            'استيراد 365 يوم من البيانات التاريخية لـ BTC, ETH, BNB لتحسين دقة التوقعات بنسبة +10%' : 
                            'Import 365 days of historical data for BTC, ETH, BNB to improve prediction accuracy by +10%' 
                        ?>
                    </p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div class="bg-black bg-opacity-30 rounded p-3">
                            <div class="text-xs text-gray-400"><?= $isRTL ? 'البيانات' : 'Data Points' ?></div>
                            <div class="text-2xl font-bold text-purple-400">~1095</div>
                            <div class="text-xs text-gray-500"><?= $isRTL ? 'سجل سعر' : 'price records' ?></div>
                        </div>
                        <div class="bg-black bg-opacity-30 rounded p-3">
                            <div class="text-xs text-gray-400"><?= $isRTL ? 'المدة' : 'Duration' ?></div>
                            <div class="text-2xl font-bold text-blue-400">365</div>
                            <div class="text-xs text-gray-500"><?= $isRTL ? 'يوم' : 'days' ?></div>
                        </div>
                        <div class="bg-black bg-opacity-30 rounded p-3">
                            <div class="text-xs text-gray-400"><?= $isRTL ? 'التحسين المتوقع' : 'Expected Boost' ?></div>
                            <div class="text-2xl font-bold text-green-400">+10%</div>
                            <div class="text-xs text-gray-500"><?= $isRTL ? 'في الدقة' : 'accuracy' ?></div>
                        </div>
                    </div>
                    
                    <button onclick="importHistoricalData()" id="importBtn" class="w-full px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition font-bold">
                        <i class="fas fa-cloud-download-alt"></i> 
                        <?= $isRTL ? '🚀 ابدأ الاستيراد (3-5 دقائق)' : '🚀 Start Import (3-5 min)' ?>
                    </button>
                    
                    <div class="mt-3 text-xs text-gray-400 flex items-center gap-2">
                        <i class="fas fa-info-circle"></i>
                        <?= $isRTL ? 
                            'سيتم فتح نافذة جديدة. لا تغلقها حتى تظهر رسالة "IMPORT COMPLETED"' : 
                            'A new window will open. Don\'t close it until "IMPORT COMPLETED" appears' 
                        ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Predictions -->
        <div class="bg-gray-800 rounded-xl p-6 mb-8">
            <h2 class="text-xl font-bold mb-4">
                <i class="fas fa-history text-blue-500"></i> <?= $t['recent_predictions'] ?>
            </h2>
            
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="border-b border-gray-700">
                            <th class="text-<?= $isRTL ? 'right' : 'left' ?> py-3 px-4"><?= $t['symbol'] ?></th>
                            <th class="text-<?= $isRTL ? 'right' : 'left' ?> py-3 px-4"><?= $t['signal'] ?></th>
                            <th class="text-<?= $isRTL ? 'right' : 'left' ?> py-3 px-4"><?= $t['confidence'] ?></th>
                            <th class="text-<?= $isRTL ? 'right' : 'left' ?> py-3 px-4"><?= $isRTL ? 'الدقة' : 'Accuracy' ?></th>
                            <th class="text-<?= $isRTL ? 'right' : 'left' ?> py-3 px-4"><?= $t['time'] ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentPredictions as $pred): ?>
                            <tr class="border-b border-gray-700 hover:bg-gray-700">
                                <td class="py-3 px-4 font-bold"><?= $pred['symbol'] ?></td>
                                <td class="py-3 px-4">
                                    <span class="px-3 py-1 rounded-full text-sm <?= 
                                        $pred['predicted_signal'] === 'bullish' ? 'bg-green-900 text-green-300' : 
                                        ($pred['predicted_signal'] === 'bearish' ? 'bg-red-900 text-red-300' : 'bg-gray-700 text-gray-300') 
                                    ?>">
                                        <?= $pred['predicted_signal'] === 'bullish' ? $t['bullish'] : ($pred['predicted_signal'] === 'bearish' ? $t['bearish'] : $t['sideways']) ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4"><?= number_format($pred['confidence_score'] * 100, 1) ?>%</td>
                                <td class="py-3 px-4">
                                    <?= $pred['accuracy_score'] ? number_format($pred['accuracy_score'] * 100, 1) . '%' : '-' ?>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-400">
                                    <?= date('M d, H:i', strtotime($pred['prediction_timestamp'])) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Model Performance -->
        <div class="bg-gray-800 rounded-xl p-6">
            <h2 class="text-xl font-bold mb-4">
                <i class="fas fa-chart-pie text-blue-500"></i> <?= $t['model_performance'] ?> <?= $t['model_performance_subtitle'] ?>
            </h2>
            
            <?php if (!empty($performance)): ?>
                <?php foreach ($performance as $perf): ?>
                    <div class="bg-gray-700 rounded-lg p-4 mb-4">
                        <div class="flex items-center justify-between mb-2">
                            <h3 class="font-bold"><?= $perf['model_version'] ?></h3>
                            <span class="text-sm text-gray-400">
                                <?= date('M d', strtotime($perf['first_eval'])) ?> - <?= date('M d', strtotime($perf['last_eval'])) ?>
                            </span>
                        </div>
                        <div class="grid grid-cols-3 gap-4 text-sm">
                            <div>
                                <span class="text-gray-400"><?= $t['total_predictions'] ?></span>
                                <span class="font-bold <?= $isRTL ? 'mr-2' : 'ml-2' ?>"><?= $perf['total'] ?></span>
                            </div>
                            <div>
                                <span class="text-gray-400"><?= $t['correct'] ?></span>
                                <span class="font-bold <?= $isRTL ? 'mr-2' : 'ml-2' ?> text-green-500"><?= $perf['correct'] ?></span>
                            </div>
                            <div>
                                <span class="text-gray-400"><?= $t['accuracy'] ?></span>
                                <span class="font-bold <?= $isRTL ? 'mr-2' : 'ml-2' ?> text-blue-500"><?= number_format($perf['avg_accuracy'] * 100, 1) ?>%</span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-gray-400 text-center"><?= $t['no_performance_data'] ?></p>
            <?php endif; ?>
        </div>
    </main>
    
    <script src="assets/js/main.js"></script>
    <script>
        // Import 1 Year Historical Data
        function importHistoricalData() {
            const btn = document.getElementById('importBtn');
            const isRTL = <?= $isRTL ? 'true' : 'false' ?>;
            
            // Confirm action
            if (!confirm(isRTL ? 
                '⚠️ هذا سيستغرق 3-5 دقائق\n\nسيتم استيراد 365 يوم من البيانات لـ BTC, ETH, BNB\n\nهل تريد المتابعة؟' : 
                '⚠️ This will take 3-5 minutes\n\nWill import 365 days of data for BTC, ETH, BNB\n\nContinue?'
            )) {
                return;
            }
            
            // Disable button
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + 
                (isRTL ? 'جاري الفتح...' : 'Opening...');
            
            // Open in new window
            const importWindow = window.open(
                'cron/import_1year_data.php', 
                'HistoricalDataImport',
                'width=900,height=700,scrollbars=yes'
            );
            
            // Show message
            setTimeout(() => {
                btn.innerHTML = '<i class="fas fa-external-link-alt"></i> ' + 
                    (isRTL ? '✅ نافذة الاستيراد مفتوحة' : '✅ Import window opened');
                
                setTimeout(() => {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-cloud-download-alt"></i> ' + 
                        (isRTL ? '🚀 ابدأ الاستيراد (3-5 دقائق)' : '🚀 Start Import (3-5 min)');
                }, 3000);
            }, 500);
            
            // Check if window was blocked
            if (!importWindow || importWindow.closed || typeof importWindow.closed === 'undefined') {
                alert(isRTL ? 
                    '❌ تم حظر النافذة المنبثقة!\n\nيرجى السماح بالنوافذ المنبثقة لهذا الموقع.' : 
                    '❌ Popup was blocked!\n\nPlease allow popups for this site.'
                );
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-cloud-download-alt"></i> ' + 
                    (isRTL ? '🚀 ابدأ الاستيراد (3-5 دقائق)' : '🚀 Start Import (3-5 min)');
            }
        }
        
        async function runAction(action) {
            const resultDiv = document.getElementById('actionResult');
            
            // Special handling for evaluate - open in new window
            if (action === 'evaluate') {
                resultDiv.innerHTML = '<?= $isRTL ? "<div class=\"bg-blue-900 text-blue-200 p-4 rounded-lg\"><i class=\"fas fa-external-link-alt\"></i> جاري فتح نافذة التقييم...</div>" : "<div class=\"bg-blue-900 text-blue-200 p-4 rounded-lg\"><i class=\"fas fa-external-link-alt\"></i> Opening evaluation window...</div>" ?>';
                window.open('cron/evaluate_predictions.php', '_blank', 'width=800,height=600');
                setTimeout(() => {
                    resultDiv.innerHTML = '<?= $isRTL ? "<div class=\"bg-green-900 text-green-200 p-4 rounded-lg\"><i class=\"fas fa-check-circle\"></i> تم فتح نافذة التقييم. سيتم تحديث الصفحة بعد 3 ثواني...</div>" : "<div class=\"bg-green-900 text-green-200 p-4 rounded-lg\"><i class=\"fas fa-check-circle\"></i> Evaluation window opened. Page will reload in 3 seconds...</div>" ?>';
                    setTimeout(() => location.reload(), 3000);
                }, 500);
                return;
            }
            
            resultDiv.innerHTML = '<?= $isRTL ? "<div class=\"bg-blue-900 text-blue-200 p-4 rounded-lg\"><i class=\"fas fa-spinner fa-spin\"></i> جاري التنفيذ...</div>" : "<div class=\"bg-blue-900 text-blue-200 p-4 rounded-lg\"><i class=\"fas fa-spinner fa-spin\"></i> Running action...</div>" ?>';
            
            try {
                let url;
                switch(action) {
                    case 'fetch':
                        url = 'api/fetch_data.php';
                        break;
                    case 'analyze':
                        url = 'api/run_analysis.php';
                        break;
                }
                
                const response = await fetch(url);
                const result = await response.json();
                
                if (result.success) {
                    resultDiv.innerHTML = `<div class="bg-green-900 text-green-200 p-4 rounded-lg"><i class="fas fa-check-circle"></i> ${result.message || '<?= $isRTL ? "تمت العملية بنجاح" : "Success" ?>'}</div>`;
                    
                    // Reload after 2 seconds
                    setTimeout(() => location.reload(), 2000);
                } else {
                    resultDiv.innerHTML = `<div class="bg-red-900 text-red-200 p-4 rounded-lg"><i class="fas fa-exclamation-circle"></i> ${result.message || result.error || '<?= $isRTL ? "حدث خطأ" : "Error occurred" ?>'}</div>`;
                }
            } catch (error) {
                resultDiv.innerHTML = `<div class="bg-red-900 text-red-200 p-4 rounded-lg"><i class="fas fa-exclamation-circle"></i> <?= $isRTL ? "خطأ" : "Error" ?>: ${error.message}</div>`;
            }
        }
        
        // Dark Mode Toggle for Admin Panel
        function toggleDarkMode() {
            const body = document.body;
            const toggleBtn = document.getElementById('darkModeToggle');
            const isDark = body.classList.contains('bg-gray-900');
            
            if (isDark) {
                // Switch to Light Mode
                document.documentElement.setAttribute('data-theme', 'light');
                localStorage.setItem('theme', 'light');
                
                if (toggleBtn) {
                    toggleBtn.innerHTML = '<i class="fas fa-sun text-yellow-500"></i>';
                    toggleBtn.className = 'p-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition dark-mode-toggle';
                }
            } else {
                // Switch to Dark Mode
                document.documentElement.removeAttribute('data-theme');
                localStorage.setItem('theme', 'dark');
                
                if (toggleBtn) {
                    toggleBtn.innerHTML = '<i class="fas fa-moon text-blue-400"></i>';
                    toggleBtn.className = 'p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition dark-mode-toggle';
                }
            }
        }
        
        // Initialize dark mode
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme');
            const toggleBtn = document.getElementById('darkModeToggle');
            
            if (toggleBtn) {
                toggleBtn.addEventListener('click', toggleDarkMode);
                
                if (savedTheme === 'light') {
                    toggleDarkMode();
                }
            }
        });
    </script>
</body>
</html>

